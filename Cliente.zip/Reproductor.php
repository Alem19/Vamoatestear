<?php
  header("Cache-Control: no-store, no-cache, must-revalidate");
  header("Cache-Control: post-check=0, pre-check=0", false);
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
  header("Pragma: no-cache");
  clearstatcache();
  $redirect=false;
  require_once("bitacora.php");
  require_once("manejo_bd.php");
	$dirVideo=$_GET['dirVideo'];
  $modo=$_GET['modo'];
  $modoSap=$_GET['modoSap'];

    define ("TIPO_GUIA_A7_NAC",        0x01);
    define ("TIPO_GUIA_A7_DF",         0x02);
    define ("TIPO_GUIA_A13_NAC",       0x03);
    define ("TIPO_GUIA_A13_DF",        0x04);
    define ("TIPO_GUIA_AAE_NAC",       0x05);
    define ("TIPO_GUIA_AAP_NAC",       0x06);
    define ("TIPO_GUIA_5MIN_DF",       0x07);
    define ("TIPO_GUIA_1MIN_DF",       0x08);
    define ("TIPO_GUIA_AAP_LA",        0x09);
    define ("TIPO_GUIA_5MIN_PAC",      0x0a);
    define ("TIPO_GUIA_A7_LOC",        0x0b);
    define ("TIPO_GUIA_A13_LOC",       0x0c);
    define ("TIPO_GUIA_A7_X5",         0x0d);
    define ("TIPO_GUIA_A13_X5",        0x0e);
    define ("TIPO_GUIA_X1",            0x0F);
    define ("TIPO_GUIA_P40_X5",        0x10);
    define ("TIPO_GUIA_LA_X5",         0x11);
    define ("TIPO_GUIA_A7DF_X5",       0x12);
    define ("TIPO_GUIA_A13DF_X5",      0x13);
    define ("TIPO_GUIA_AAE_X5",        0x14);
    define ("TIPO_GUIA_AAO_X5",        0x15);
    define ("TIPO_GUIA_A7_NAC_X5",     0x16);
    define ("TIPO_GUIA_A13_NAC_X5",    0x17);

    function guarda_datos($datos){
      ?>
        <script>
          var datos=" <?php echo sanitize($datos);?>";
          var info=datos.split("*");
          totalElementos=(isNaN(info[0]))?1:info[0];
          duracionVideo=(isNaN(info[1]))?1:info[1];
          inicioPrograma=(isNaN(info[2]))?1:info[2];
          fechaPrograma1=(isNaN(info[3]))?"010115":info[3];
          TipoGuia=(isNaN(info[4]))?1:info[4];
          inicioVideo1=(isNaN(info[5]))?1:info[5];
        </script>
      <?php
    }
    function obtiene_tam_video($TGuia){
      switch($TGuia){
        case TIPO_GUIA_A7_NAC:
        case TIPO_GUIA_A7_DF:
        case TIPO_GUIA_A13_NAC:
        case TIPO_GUIA_A13_DF:
        case TIPO_GUIA_AAE_NAC:
        case TIPO_GUIA_AAP_NAC:
        case TIPO_GUIA_5MIN_DF:
        case TIPO_GUIA_AAP_LA:
        case TIPO_GUIA_5MIN_PAC:
        case TIPO_GUIA_A7_X5:
        case TIPO_GUIA_A13_X5:
        case TIPO_GUIA_P40_X5:
        case TIPO_GUIA_LA_X5:
        case TIPO_GUIA_A7DF_X5:
        case TIPO_GUIA_A13DF_X5:
        case TIPO_GUIA_AAE_X5:
        case TIPO_GUIA_AAO_X5:
        case TIPO_GUIA_A7_NAC_X5:
        case TIPO_GUIA_A13_NAC_X5:
          $tam_Video = 5;
        break;
        case TIPO_GUIA_1MIN_DF:
        case TIPO_GUIA_A7_LOC:
        case TIPO_GUIA_A13_LOC:
        case TIPO_GUIA_X1:
          $tam_Video = 1;
        break;
        default:
          $tam_Video = 1;
        break;
      }
      return $tam_Video;
    }
//-------------------------MODO SAP---------------------------------------------
  function consulta($id_tst){
    $conexion=null;
    $cursor=null;
    $error="";
    $fila=null;
    $query='SELECT NOMBRE_TESTIGO,DIRECCION_SERVIDOR, NOMBRE_USUARIO, CLAVE_USUARIO,'
          .' RUTA_VIDEOS, RUTA_VIDEOS2, GRUPO_TESTIGOS,TIPO_GUIA'
          .' FROM LISTA_TESTIGOS where ID_TESTIGO = '.$id_tst;
    $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$error);
    if($conexion!==false)
    {
      $cursor=parse_bd($conexion,$query,$error);
      if($cursor!==false)
      {
        $fila=ejecuta_select($cursor,$error);
      }
    }
    if(is_array($fila))
    {
      if(isset($fila[0]['RUTA_VIDEOS'])===false) {
        $texto="Error al obtener datos testigo ".$id_tst." : Código ".$fila[0].": ".$fila[1];
        Bitacora($texto,0);
      }else{
        $fila=$fila[0];
      }
    }else{
      $texto="Error al obtener datos testigo ".$id_tst.": ".$fila;
      Bitacora($texto,0);
    }
    libera_bd($conexion,$cursor);
    return $fila;
  }
  function obtieneAlias($alias, $rutaVideo)
  {
    $carpeta="";
    if($alias!="" && $rutaVideo!="")
    {
      $datos1 = explode('\\',$rutaVideo);
      $indice= count($datos1)-2;
      $carpeta = $datos1[$indice];
    }
    return $alias."/".$carpeta;
  }
  function obtiene_ruta_sap($id_tst)
  {
    $resConsulta = consulta($id_tst);
    $alias1A = $resConsulta['NOMBRE_USUARIO'];
    $rutaVideos1 = $resConsulta['RUTA_VIDEOS'];
    $alias1 = obtieneAlias($alias1A, $rutaVideos1);
    $dirServidor = $resConsulta['DIRECCION_SERVIDOR'];
    $ruta="http://".$dirServidor."/".$alias1."/";
    return $ruta;
  }
  function imprime_espejo($totalVideos,$videoActual,&$ruta,$idsap)
  {
    if($ruta==1)
    {
      $ruta=obtiene_ruta_sap($idsap);
    }
    $vid=substr($videoActual,strrpos($videoActual,"/")+1);
    $nomVideo=obt_id_cad($idsap).substr($vid,4);
    $fecha=substr($vid,4,2)."_".substr($vid,6,2)."_".(2000+substr($vid,8,2));
    $source=$ruta.$fecha."/".$nomVideo;
    Bitacora($source,0);
    if($totalVideos==0)
		{
		  echo '<video id="mivideoS'.$totalVideos.'" class="videos" preload="auto" ';
		}else{
		  echo '<video id="mivideoS'.$totalVideos.'" class="videos" preload="none" style="visibility:hidden;"';
		}
		if(strpos($videoActual,".mov")!=false){
		  echo ' src="'.sanitize($source).'" type="video/mp4">';
		}else{
		  echo ' src="'.sanitize($source).'" type="video/mp4; codecs=\'avc1.42E01E, mp4a.40.2\'">';
		}
		echo '"Your browser does not support HTML5 video."';
		echo '</video>';
  }
//------------------------------------------------------------------------------
?>

<!DOCTYPE html>
<html>
	<head>
		<!--<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<title>Reproductor de video</title>
		<link rel="stylesheet" type="text/css" href="css/estiloRep.css" />
		<script language="javascript" type="text/javascript" >
      var totalElementos=0;
      var duracionVideo=0;
      var inicioPrograma=0;
      var fechaPrograma1="";
      var TipoGuia=1;
      var inicioVideo1=0;
		</script>
  <?php
    if($modoSap)
		  echo '<script language="javascript" type="text/javascript" src="js/libRepSap.js"></script>';
    else
      echo '<script language="javascript" type="text/javascript" src="js/libRep.js"></script>';
  ?>
	</head>
	<body class="principal" onload="despuesCarga()">
		<div class="divEtiqueta" id="divFecha"><span id="etiquetaFecha">Fecha</span></div>
		<div class="divEtiqueta" id="divHora"><span id="etiquetaHora">Hora</span></div>
		<div id="divVideo" onclick="reproduce1()">
			<?php
        $TipoGuia=0;
        $frame=29.97;
        $frame5min=8991;
        $frame1min=1798.2;
        if($modo==1)
        {
          $frame=30;
          $frame5min=9000;
          $frame1min=1800;
          $TipoGuia=1;
        }
				$totalVideos=0;
				$duracion=0;
				$inicioPrograma=0;
				$videoAnterior="";
				$video = explode("]",$dirVideo);
				$datos0 = explode("*",$video[0]);
				$horaInicial = $datos0[0];
				$rutas0 = explode(",",$datos0[1]);
				$rutaInicial = $rutas0[0];
        $id_transmisor = ltrim(substr($rutaInicial,strlen($rutaInicial)-22,4),"0");
        if(strpos($id_transmisor,"/")!=false){
          $id_transmisor = substr($id_transmisor,strpos($id_transmisor,"/")+1,2);
        }
        $TGuia = $datos0[2];
        $tamVideo = obtiene_tam_video($TGuia);
        $rutaFinal="";
				if(count($video)>=2){
					$datos1 = explode("*",$video[1]);
					$rutas1 = explode(",",$datos1[1]);
					$rutaFinal = $rutas1[1];
				}else{
          if(count($rutas0)>1)
					  $rutaFinal = $rutas0[1];
				}
				$inicioPrograma=$datos0[0]/$frame;		//	Hora de inicio evento en segundos
				$eventoInicio = ltrim(substr($rutaInicial,strlen($rutaInicial)-12,8),"0") - 32;
				$eventoFin = ltrim(substr($rutaFinal,strlen($rutaFinal)-12,8),"0");
				if($eventoFin==""){
					$eventoFin = $eventoInicio + 32;
				}
				$videoActual =$rutaInicial;
				do{
					if(($tamVideo == 5 && $eventoInicio >= 9216) || ($tamVideo == 1 && $eventoInicio >= 46080)){
						$eventoInicio = 0;
						$videoActual = $rutaFinal;
					}
					$eventoInicio = $eventoInicio + 32;
					$videoActual = substr_replace($videoActual,str_pad($eventoInicio,8,"0",STR_PAD_LEFT),-12,8);
					if($videoActual != $videoAnterior)
					{
            if($modoSap){
              $ruta="1";
              imprime_espejo($totalVideos,$videoActual,$ruta,$modoSap);
            }
						if($totalVideos==0)
						{
							$noEvento = (ltrim(substr($videoActual,strlen($videoActual)-12,8),"0")/32) -1;
              if($tamVideo == 5){
                $inicioVideo = $noEvento * $frame5min;		// hora de inicio video en segundos
              }else if($tamVideo == 1){
                $inicioVideo = $noEvento * $frame1min;		// hora de inicio video en segundos
              }
							$difInicio = ($horaInicial - $inicioVideo)/$frame;          // se cambio $inicioPrograma por $horaInicial
							$fecha = substr($videoActual,strlen($videoActual)-18,6);
							echo '<video id="mivideo'.$totalVideos.'" class="videos" preload="auto"';
						}else{
							echo '<video id="mivideo'.$totalVideos.'" class="videos" preload="none" style="visibility:hidden;"';
						}
						if(strpos($videoActual,".mov")!=false){
							echo ' src="'.sanitize($videoActual).'" type="video/mp4">';
						}else{
							echo ' src="'.sanitize($videoActual).'" type="video/mp4; codecs=\'avc1.42E01E, mp4a.40.2\'">';
						}
						echo '"Your browser does not support HTML5 video."';
						echo '</video>';
						$totalVideos = $totalVideos + 1;
					}
				}while($eventoInicio != $eventoFin);
				$videoAnterior = "";
        if(count($datos0)>3)
				  $duracion = $datos0[3]/$frame;  //cambio 30 100915
        else
          $duracion= 0;
        $datos=Trim($totalVideos."*".$duracion."*".$inicioPrograma."*".$fecha."*"
                    .$TipoGuia."*".$difInicio);
        guarda_datos($datos);
			?>
		</div>
		<div id="divDatos">
			Datos del video <br><br>
			Duración:
			<div class="datos">
				<span id="totalHr"></span>
			</div>
			Hora del día:
			<div class="datos">
				<span id="horaHr"></span>
			</div>
			posición:
			<div class="datos">
				  <span id="posicionHr"></span>
			</div>
			<br>
			<button id="btnDesactFecha" class="botonGde" onclick="desactFecha()">Oculta Fecha</button>
			<br>
			<button id="btnDesactHora" class="botonGde" onclick="desactHora()">Oculta Hora</button>
			<br><br>
  <?php
    if($modoSap)
      echo'<input type="checkbox" id="sap" name="sap"  onclick="silencio()" value="0" checked> Audio SAP<br><br>';
  ?>
			Selección <br><br>
			<button id="btnCapturaEntrada" class="botonGde" onclick="capturaEntrada()">Entrada</button>
			Entrada:
			<div class="datos">
				<span id="entrada">00:00:00:00</span>
			</div>
			<button id="btnCapturaSalida" class="botonGde" onclick="capturaSalida()">Salida</button>
			Salida:
			<div class="datos">
				<span id="salida">00:00:00:00</span>
			</div>
			Duración:
			<div class="datos">
				<span id="duracion">00:00:00:00</span>
			</div>
			<!--button id="btnDesactFecha" class="botonGde" onclick="desactFecha()">Reproduce Sel</button>
			<br-->
			<button id="btnExportaSel" class="botonGde" onclick="exportaSel()">Exporta Selección</button>
		</div>
		<div id="divControles">
			<center>
			<div id="barraPos">
				<center>
					<input id="posicion" type="range" min="0" max="1000" step="1" value="0" onmousedown="actualizaHora()" onmouseup="remueveEventoRango()"/>
				</center>
			</div>
			<div id="controlRep">
					<div id="muestraVel" class="elemControl">
						<img src="img/btnRebobina.jpg" class="imgcontrol" onclick="Rebobina()" title="Rebobina" style="width: 30px; height:30px;"/>
						<img src="img/RegCuad.jpg" class="imgcontrol" onclick="RegresaCuadro()" title="Regresa cuadro" style="width: 30px; height:30px;"/>
						<img src="img/btnPLay.jpg" class="imgcontrol" onclick="reproduce1()" title="Reproduce / Pausa" style="width: 30px; height:30px;"/>
						<img src="img/AvanceCuad.jpg" class="imgcontrol" onclick="AvanzaCuadro()" title="Avanza cuadro" style="width: 30px; height:30px;"/>
						<img src="img/btnAvanzaFin.jpg" class="imgcontrol" onclick="irAlFinal()" title="Avanza al final" style="width: 30px; height:30px;"/>
					</div>
					<div id="controlVel" class="elemControl">
						<div id="botonesVel" class="elemControl">
							<img src="img/btnMenosVel.jpg" class="imgcontrol" onclick="DecVel()" title="Disminuye velocidad" style="width: 30px; height:30px;"/>
							<img src="img/btn1x.jpg" class="imgcontrol" onclick="VelNormal()" title="Velocidad normal" style="width: 30px; height:30px;"/>
							<img src="img/IncVel.jpg" class="imgcontrol" onclick="IncVel()" title="Aumenta velocidad" style="width: 30px; height:30px;"/>
						</div>
						<div class="elemControl">
							Velocidad: <br> <span id="speedDisplay"></span> X
						</div>
					</div>

					<div id="divVolumen" class="elemControl">
						<center>
							Vol: <span id="vol"></span> <br>
							<input id="volumen" type="range" min="0" max="100" step="1" value="50" oninput="controlaVol()"/>
						</center>
					</div>
					<!--div class="elemControl">
						<img src="img/IncVel.jpg" class="imgcontrol" onclick="pantallaCompleta()" title="Pantalla completa" style="width: 30px; height:30px;"/>
					</div-->
			</div>
			</center>
		</div>
	</body>
</html>
<?php
