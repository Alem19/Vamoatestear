<?php
  require_once("bitacora.php");
  require_once("utilerias.php");
  require_once("manejo_bd.php");
  if(isset($_POST['id_corte']) && isset($_POST['name']))
  {
    $estado=3;
    $id_corte=(is_numeric($_POST['id_corte']))?$_POST['id_corte']:0;
    $nombre=sanitize($_POST['name']);
    if($id_corte!==0)
    {
      $cursor=null;
      $conexion=null;
      $error="";
      $fila=null;
      $query="SELECT ESTADO FROM CORTES_TESTIGO_WEB WHERE ID=".$id_corte;
      $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$error);
      if($conexion!==false)
      {
        $cursor=parse_bd($conexion,$query,$error);
        if($cursor!==false)
        {
          $fila=ejecuta_select($cursor,$error);
        }
      }
      if(is_array($fila))
      {
        if(count($fila)==2){
          $texto="Error al obtener estado peticion : Codigo ".$fila[0].": ".$fila[1]['message'];
          Bitacora($texto,0);
        }else{
          if(isset($fila[0]['ESTADO']) || $fila[0]['ESTADO']!=="")
          {
            $estado=$fila[0]['ESTADO'];
            if($estado==2){
              $texto="Se ha realizado una exportacion con nombre:".$nombre;
              Bitacora($texto,0);
            }else if($estado==3){
              $texto="Error al exportar video con nombre:".$nombre;
              Bitacora($texto,0);
            }
          }
        }
      }else{
        $texto="Error al obtener estado exportacion ".$query;
        Bitacora($texto,0);
      }
      libera_bd($conexion,$cursor);
    }
    echo $estado;
  }
?>