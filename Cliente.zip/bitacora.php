<?php
require_once("utilerias.php");
  $texto1="";
  if(isset($_POST['texto']))
  {
    $texto1=$_POST['texto'];
    Bitacora($texto1,0);
  }
  function Bitacora($texto,$error)
  {
    $ip= ObtenerIP();
    $manejador1 = null;
    $add = null;
    $texto1="";
    date_default_timezone_set('America/Mexico_City');
    //$directorio="/home/testigosweb/Bitacora/TestigosBit";
    //$directorio="E:/Bitacoras";
    $directorio="C:/Bitacoras";
    $archivo=$directorio."/ClienteSAP_".date("d_m_Y").".bit";
    if(!file_exists ($directorio))
    {
      if(!mkdir($directorio,0777))
      {
        $archivo="ClienteSAP_".date("d_m_Y").".bit";
      }
    }
    if($error)
      $texto1="<<ERROR DE ACCESO>>\r\n";
    else
      $texto1="<HOST:> ".gethostbyaddr($_SERVER['REMOTE_ADDR']);
    $add=$texto1." <IP:> ".$ip."\t".$texto."\t".date("H:i:s")."\t".date("d-m-Y")."\r\n";
    $manejador1=fopen($archivo,"a");
    if($manejador1)
    {
      fwrite($manejador1,$add);
      fclose($manejador1);
      $ok=1;
    }
  }
?>