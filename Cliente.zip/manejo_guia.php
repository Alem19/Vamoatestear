<?php
    define ("ESTADO_TESTIGO_NO_EXISTE",        0x01);
    define ("ESTADO_TESTIGO_LISTO",            0x02);
    define ("ESTADO_TESTIGO_NACIONAL",         0x04);
    define ("ESTADO_TESTIGO_NO_LISTO",         0x08);
    define ("ESTADO_TESTIGO_LOCAL",            0x10);
    define ("ESTADO_TESTIGO_ERROR",            0x20);
    define ("ESTADO_TESTIGO_NO_VBI",           0x40);
    define ("ESTADO_TESTIGO_LISTO_NAC",        0x80);
    define ("EDO_ANALISIS_VERIFICADO",               1);
    define ("EDO_ANALISIS_VIVO",                     6);
    define ("EDO_ANALISIS_NO_RECONOCIDO",           10);
    define ("EDO_ANALISIS_BLOQ_NO_AIRE",            11);
    define ("EDO_ANALISIS_BLOQ_TX",                  9);
    define ("EDO_ANALISIS_BLOQ_PENDIENTE_VID",       8);
    define ("EDO_ANALISIS_BLOQ_PENDIENTE_HUELLA",   19);
    define ("EDO_ANALISIS_BLOQ_PENDIENTE_VID_CABS", 20);
    define ("EDO_ANALISIS_BLOQ_PENDIENTE_ASRUN",    21);
    define ("EDO_ANALISIS_NAL_PENDIENTE_VID",        7);
    define ("EDO_ANALISIS_NAL_PENDIENTE_HUELLA",    18);
    define ("EDO_ANALISIS_VERIFICADO_ASR",          12);
    define ("EDO_ANALISIS_CRUCE_GUIA_ERROR_NO_CORR_GUIA", 13);
    define ("EDO_ANALISIS_CRUCE_GUIA_ERROR_DUR_GUIA", 14);
    define ("EDO_ANALISIS_NO_REC_ERROR_ABRE",       15);
    define ("EDO_ANALISIS_NO_REC_ERROR_DUR",        16);
    define ("EDO_ANALISIS_NO_REC_ERROR_EXPORTA",    17);
    define ("GUIA_ESTADO_EVENTO_PRECUE", 0x00000101);
    define ("GUIA_ESTADO_EVENTO_CUE",    0x00000102);
    define ("GUIA_ESTADO_PASADO",        0x00000103);
    define ("GUIA_ESTADO_EXITO",         0x00000104);
    define ("GUIA_ESTADO_TRANSMITIDO",   0x00000105);
    define ("GUIA_ESTADO_NO_TRANSMITIDO",0x00000106);
    define ("GUIA_ESTADO_INCOMPLETO",    0x00000107);
    define ("GUIA_ESTADO_SALTADO",       0x00000108);
    define ("GUIA_ESTADO_BORRADO",       0x00010000);
    define ("GUIA_ESTADO_MOVIDO",        0x00020000);
    define ("GUIA_ESTADO_AGREGADO",      0x00040000);
    define ("FORMATO_GUIA_CABS",         0x01);
    define ("FORMATO_GUIA_TESTIGOS",     0x02);
    define ("FORMATO_GUIA_ITHIC",        0x03);
    define ("TIPO_EV_ANALISIS_COMERCIAL", 1);
    define ("TIPO_EV_ANALISIS_PROGRAMA",  2);
    define ("TIPO_EV_ANALISIS_BLOQUEO",   3);
    define ("TIPO_EV_ANALISIS_VIVO",      4);
   define ("GRUPO_TESTIGOS_NACIONAL",       0x01);
   define ("GRUPO_TESTIGOS_LOCALES_A7",      0x02);
   define ("GRUPO_TESTIGOS_LOS_ANGELES",     0x03);
   define ("GRUPO_TESTIGOS_TELEVISA_DF",     0x04);
   define ("GRUPO_TESTIGOS_LOCALES_A13",     0x05);
   define ("GRUPO_TESTIGOS_HD",              0x06);
   define ("GRUPO_TESTIGOS_RADIO",           0x08);
   define ("GRUPO_TESTIGOS_LOCALES_TELEVISA",0x09);
   define ("GRUPO_TESTIGOS_DF7",             0x0A);
   define ("GRUPO_TESTIGOS_DF13",            0x0B);
   define ("GRUPO_TESTIGOS_AA_ESTE",         0x0C);
   define ("GRUPO_TESTIGOS_AA_OESTE",        0x0D);
   define ("GRUPO_TESTIGOS_NAL7",            0x0E);
   define ("GRUPO_TESTIGOS_NAL13",           0x0F);
   define ("GRUPO_TESTIGOS_DESARROLLO",      0x10);
   define ("GRUPO_TESTIGOS_OTROS_DF",        0x11);
   define ("GRUPO_TESTIGOS_INTERNAC",        0x12);
   define ("GRUPO_TESTIGOS_TV_PAGA",         0x13);
   define ("GRUPO_TESTIGOS_CABLE_7",         0x15);
   define ("GRUPO_TESTIGOS_CABLE_13",        0x16);
   define ("GRUPO_TESTIGOS_TX_7",            0x17);
   define ("GRUPO_TESTIGOS_TX_13",           0x18);
   define ("GRUPO_TESTIGOS_MUX_1",           0x19);
   define ("GRUPO_TESTIGOS_MUX_7",           0x1A);
   define ("TIPO_GUIA_A7_NAC",        0x01);
   define ("TIPO_GUIA_A7_DF",         0x02);
   define ("TIPO_GUIA_A13_NAC",       0x03);
   define ("TIPO_GUIA_A13_DF",        0x04);
   define ("TIPO_GUIA_AAE_NAC",       0x05);
   define ("TIPO_GUIA_AAP_NAC",       0x06);
   define ("TIPO_GUIA_5MIN_DF",       0x07);
   define ("TIPO_GUIA_1MIN_DF",       0x08);
   define ("TIPO_GUIA_AAP_LA",        0x09);
   define ("TIPO_GUIA_5MIN_PAC",      0x0a);
   define ("TIPO_GUIA_A7_LOC",        0x0b);
   define ("TIPO_GUIA_A13_LOC",       0x0c);
   define ("TIPO_GUIA_A7_X5",         0x0d);
   define ("TIPO_GUIA_A13_X5",        0x0e);
   define ("TIPO_GUIA_X1",            0x0F);
   define ("TIPO_GUIA_P40_X5",        0x10);
   define ("TIPO_GUIA_LA_X5",         0x11);
   define ("TIPO_GUIA_A7DF_X5",       0x12);
   define ("TIPO_GUIA_A13DF_X5",      0x13);
   define ("TIPO_GUIA_AAE_X5",        0x14);
   define ("TIPO_GUIA_AAO_X5",        0x15);
   define ("TIPO_GUIA_A7_NAC_X5",     0x16);
   define ("TIPO_GUIA_A13_NAC_X5",    0x17);
    define("ID_A7_DF",                  "212");
    define("ID_A13_DF",                 "213");
    define("ID_A7_NAC",                 "217");
    define("ID_A13_NAC",                "216");
    define("ID_A13_HD",                 "218");
    define("ID_A7_HD",                  "219");
    define("ID_PROY40",                 "220");
    define("ID_PROY40DF",               "16");
    define("ID_C2TV",                   "12");
    define("ID_C4TV",                   "14");
    define("ID_C5TV",                   "15");
    define("ID_C9TV",                   "19");

//---------------------------------------------------------------------------
function carga_info_testigos($archivo)
{
  $dir=$archivo;
  $file = fopen($dir, "r") or die("No se pudo abrir el archivo");
  $cad="SIN_DATOS";
  while(!feof($file))
  {
    $linea=fgets($file);
    if($linea!="")
    {
      $datos=explode('"',$linea);
      $datos[0]=trim($datos[0]);
      $datos[1]=trim(utf8_encode($datos[1]));
      $datos[3]=trim($datos[3]);
      $datos[5]=trim($datos[5]);
      $datos[6]=trim($datos[6]);
      $testigos[$datos[0]]=array('nombre'=>$datos[1],'ruta_videos'=>$datos[3],
                          'ruta_videos2'=>$datos[5],'grupo_testigo'=>$datos[6]);
    }
  }
  fclose($file);
  return $testigos;
}
//---------------------------------------------------------------------------
function grid_tipo_evento($tipo,$estado,&$tipo1,&$color,&$evcolor,$guia_analisis)
{
  $admin=0;
  $est=hexdec($estado);
  if ($est & GUIA_ESTADO_BORRADO)
  {
    $color=" bgcolor=Purple";
    if($tipo=='N')
      $tipo1="COMERCIAL";
    elseif($tipo=='P')
      $tipo1="PROGRAMA";
  }
  else if ($est & GUIA_ESTADO_MOVIDO && $admin==0x1234)
  {
    $color=" bgcolor=LemonChiffon";
  }else
  {
    switch ($tipo)
    {
      case 'N':
        $color=" bgcolor=#99FFCC";
        $tipo1="COMERCIAL";
      break;
      case 'P':
        $color=" bgcolor=PaleTurquoise";
        $tipo1="PROGRAMA";
      break;
      case 'L':
      if($guia_analisis==true)
      {
        if($estado==276){
          $tipo1="RDI";
          $color=" bgcolor=#BEF781";
          $evcolor=" bgcolor=#BEF781";
        }else{
          $tipo1="COMERCIAL";
          $color=" bgcolor=Olive";
          $evcolor=" bgcolor=Olive";
        }
      }else{
        $tipo1="BLOQUEABLE";
        $color=" bgcolor=#99FFCC";
        $evcolor=" bgcolor=Olive";
      }
      break;
      case 'T':
        $color=" bgcolor=PaleTurquoise";
        $tipo1="PROGRAMA";
      break;
      case 'A':
        $tipo1="AGREGADO";
        $color=" bgcolor=#99FFCC";
        $evcolor=" bgcolor=Aqua";
      break;
      case 'V':
        $color=" bgcolor=#FE9A2E";
        $evcolor=" bgcolor=#FE9A2E";
      break;
      case 'CL':
        $tipo1="COMERCIAL";
        $color=" bgcolor=DodgerBlue";
        $evcolor=" bgcolor=DodgerBlue";
      break;
      case 'B':
        $tipo1="BLOQUE";
        $color=" bgcolor=violet";
        $evcolor=" bgcolor=violet";
      break;
    }
  }
}
//---------------------------------------------------------------------------
function columna_estado($estado,&$estado1,&$estcolor,$guia_analisis)
{
    if($guia_analisis)
    {
      switch($estado)
      {
        case EDO_ANALISIS_VERIFICADO:
          $estado1="VERIFICADO(A)";
          $estcolor="bgcolor=Green";
        break;
        case EDO_ANALISIS_VERIFICADO_ASR:
          $estado1="VERIFICADO(B)";
          $estcolor="bgcolor=Green";
        break;
        case EDO_ANALISIS_VIVO:
          $estado1="TRANSMITIDO";
          $estcolor="bgcolor=teal";
        break;
        case EDO_ANALISIS_NO_RECONOCIDO:
          $estado1="NO RECONOCIDO";
          $estcolor="bgcolor=Yellow";
        break;
        case EDO_ANALISIS_BLOQ_NO_AIRE:
          $estado1="NO AIRE";
          $estcolor="bgcolor=Red";
        break;
        case EDO_ANALISIS_BLOQ_TX:
          $estado1="TRANSMITIDO";
          $estcolor="bgcolor=teal";
        break;
        case EDO_ANALISIS_BLOQ_PENDIENTE_VID:
        case EDO_ANALISIS_BLOQ_PENDIENTE_HUELLA:
        case EDO_ANALISIS_BLOQ_PENDIENTE_VID_CABS:
        case EDO_ANALISIS_NAL_PENDIENTE_VID:
        case EDO_ANALISIS_NAL_PENDIENTE_HUELLA:
        case EDO_ANALISIS_BLOQ_PENDIENTE_ASRUN:
          $estado1="PENDIENTE";
          $estcolor="bgcolor=white";
        break;
        case EDO_ANALISIS_CRUCE_GUIA_ERROR_NO_CORR_GUIA:
        case EDO_ANALISIS_CRUCE_GUIA_ERROR_DUR_GUIA:
        case EDO_ANALISIS_NO_REC_ERROR_ABRE:
        case EDO_ANALISIS_NO_REC_ERROR_DUR:
        case EDO_ANALISIS_NO_REC_ERROR_EXPORTA:
          $estado1="ERROR";
          $estcolor="bgcolor=#B22222";
        break;
      }
    }else if (hexdec($estado) & GUIA_ESTADO_BORRADO)
    {
      $estado1="BORRADO";
      $estcolor=" bgcolor=Purple";
    }else
    {
      $est=hexdec($estado) & hexdec("0xffff");
      switch ($est)
      {
        case GUIA_ESTADO_EVENTO_PRECUE:
          $estado1="PRECUE";
          $estcolor=" bgcolor=Green";
        break;
        case GUIA_ESTADO_EVENTO_CUE:
          $estado1="AIRE";
          $estcolor=" bgcolor=Lime";
      /*
          if (edit_nom_ev_aire0!=NULL)
            edit_nom_ev_aire0->Text=info_guia->nombre;
          if (edit_hora_ini0!=NULL)
            edit_hora_ini0->Text=obt_hora_mseg(info_guia->hora_ini_ms);
          if (edit_dura0!=NULL)
            edit_dura0->Text=obt_hora_mseg(info_guia->duracion);  */
        break;
        case GUIA_ESTADO_PASADO:
          $estado1="PASADO";
          $estcolor=" bgcolor=Silver";/*
          if (info_guia->existe_testigo==ESTADO_TESTIGO_LOCAL)
          {
            reti->Canvas->Brush->Color=clSilver;
            reti->Canvas->FillRect(Rect);
          }
          else
          {
            reti->Canvas->Brush->Color=clGray;
            reti->Canvas->FillRect(Rect);
          } */
        break;
        case GUIA_ESTADO_EXITO:
          $estado1="EXITO";
          $estcolor=" bgcolor=teal";
        break;
        case GUIA_ESTADO_TRANSMITIDO:
          $estado1="TRANSMITIDO";
          $estcolor=" bgcolor=teal";
        break;
        case GUIA_ESTADO_NO_TRANSMITIDO:
          $estado1="NO_TRANSMITIDO";
          $estcolor=" bgcolor=Red";
        break;
        case GUIA_ESTADO_SALTADO:
          $estado1="SALTADO";
          $estcolor=" bgcolor=Maroon";
        break;
        case GUIA_ESTADO_INCOMPLETO:
          $estado1="INCOMPLETO";
          $estcolor=" bgcolor=Yellow";
        break;
        default:
          $estado1="";
          $estcolor=" bgcolor=White";
        break;
      }
    }
}
//---------------------------------------------------------------------------
function columna_testigo($estado,$existe_tst)
{
  $estado1="";
  $est=hexdec($estado) & hexdec("0xffff");
  if($est==GUIA_ESTADO_PASADO || $est==GUIA_ESTADO_TRANSMITIDO)
  {
    if ($existe_tst==ESTADO_TESTIGO_LISTO)
    {
      $estado1=" LISTO ";
    }
    else if ($existe_tst==ESTADO_TESTIGO_NACIONAL)
    {
      $estado1="NACIONAL";
    }
    else if ($existe_tst==ESTADO_TESTIGO_NO_LISTO)
    {
      $estado1="NO LISTO (L)";
    }
    else if ($existe_tst==ESTADO_TESTIGO_LOCAL)
    {
      $estado1="LISTO (LOC)";
    }
    else if ($existe_tst==ESTADO_TESTIGO_ERROR)
    {
      $estado1="ERROR";
    }
    else if ($existe_tst==ESTADO_TESTIGO_NO_VBI)
    {
      $estado1="LISTO (NVBI)";
    }
    else if ($existe_tst==ESTADO_TESTIGO_LISTO_NAC)
    {
     $estado1="LISTO (NAC)";
    }else
      $estado1=" LISTO ";
  }else
    $estado1="";
  return $estado1;
}
?>