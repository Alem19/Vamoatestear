<?php
require_once("utilerias.php");
if(isset($_POST['texto']) && isset($_POST['fecha']) && isset($_POST['testigo']))
{
  date_default_timezone_set('America/Mexico_City');
  $tst=(is_numeric($_POST['testigo']))?$_POST['testigo']:0;
  $fecha=(strlen($_POST['fecha'])==10)?$_POST['fecha']:date('d_m_Y');
  $texto=$_POST['texto'];
  $texto=str_replace("amp;","&",$texto);
  $directorio=SERVGUIAS;
 //$directorio="E:/Bitacoras/";
  $nombre=ajuste($tst,4)."_".$fecha.".txt";
  $archivo=$directorio.$nombre;
  if(!file_exists ($directorio))
  {
    if(!mkdir($directorio,0777))
    {
      $archivo=$nombre;
    }
  }
  if(file_exists($archivo))
  {
    unlink($archivo);
  }
  $add=$texto;
  $manejador1=fopen($archivo,"a");
  if($manejador1)
  {
    if(fwrite($manejador1,$add)!==false)
    {
      fclose($manejador1);
      echo $nombre;
    }else{
      fclose($manejador1);
      echo 0;
    }
  }
}
?>