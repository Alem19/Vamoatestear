<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
clearstatcache();
require_once("manejo_guia.php");
require_once("bitacora.php");
require_once("manejo_bd.php");
//--------------------------------------------------------------------------
function guarda_defase($defase,$ultimo)
{
   ?>
    <script>
        var str = "<?php echo (is_numeric($defase))?$defase:0; ?>";
        defase_guia=str;
        str="<?php echo (is_numeric($ultimo))?$ultimo:0; ?>";
        ultimo_evento=str;
      </script>
  <?php
}
//--------------------------------------------------------------------------
function guarda_tipo_guia($tipo_guia,$clase)
{
   ?>
    <script>
        var clase = "<?php echo (is_numeric($clase))?$clase:0;?>";
        var tipo= "<?php echo (is_numeric($tipo_guia))?$tipo_guia:1;?>";
        if(clase==0)
          tipo_guia_tiempos=tipo;
        else if(clase==1)
          tipo_conciliacion=tipo;
        else if(clase==2)
          tipo_guia_bd=tipo;
        else if(clase==3)
          gpo_tst=tipo;
    </script>
  <?php
}
//--------------------------------------------------------------------------
function guarda_ruta($ruta)
{
  ?>
    <script>
        var str = "<?php echo sanitize($ruta); ?>";
        var vid=str.split(",");
        rutas_vid[vid[0]]=vid[1];
      </script>
  <?php
}
//--------------------------------------------------------------------------
function guarda_rutas_guia($ruta)
{
  ?>
    <script>
        var str = "<?php echo sanitize($ruta); ?>";
        var vid=str.split(",");
        rutas_vid_guia[vid[0]]=vid[1];
      </script>
  <?php
}
//--------------------------------------------------------------------------
function guarda_rutas_guia_man($ruta)
{
  ?>
    <script>
        var str = "<?php echo sanitize($ruta); ?>";
        var vid=str.split(",");
        rutas_vid_tomorrow[vid[0]]=vid[1];
      </script>
  <?php
}
//--------------------------------------------------------------------------
function genera_dir_videos($fecha,$id_tst,$alias1, $alias2, $dirServidor,$GPO_TST,$tipo_guia)
{
  $existe=0;
//  $max_ev=(3600000*24)/300000;
   if ($tipo_guia==TIPO_GUIA_A7_LOC || $tipo_guia==TIPO_GUIA_A13_LOC)
   {
      $max_ev=1440;
      $inicio=282;
   }
   else
   {
      $max_ev=288;
      $inicio=44;
   }
  $bit="Generando lista de videos fecha:".$fecha;
//  Bitacora($bit,0);
  for($cc=$inicio;$cc<$max_ev;++$cc)
  {
    $indice=($cc+1);
    $eventoLoc = ($cc+1)*32;
    $ruta_vid=obt_ruta_vid_X5($id_tst,$fecha,$eventoLoc,$existe, $alias1, $alias2,$dirServidor);
    $ruta_array=$indice.",".$ruta_vid;
    guarda_rutas_guia($ruta_array);
  }
}
//--------------------------------------------------------------------------
function gen_dir_videos_dia_man($fecha,$id_tst,$alias1, $alias2, $dirServidor,$GPO_TST,$tipo_guia)
{
  date_default_timezone_set('America/Mexico_City');
  $fe=str_replace("/","-",$fecha);
  $manana=date("d-m-Y", strtotime($fe." +1 day"));
  $fech=str_replace("-","/",$manana);
  $existe=0;
   if ($tipo_guia==TIPO_GUIA_A7_LOC || $tipo_guia==TIPO_GUIA_A13_LOC)
      $max_ev=326;
   else
      $max_ev=66;
  $bit="Generando lista de videos dia siguiente fecha:".$fech;
//  Bitacora($bit,0);
  for($cc=0;$cc<$max_ev;++$cc)
  {
    $indice=($cc+1);
    $eventoLoc = ($cc+1)*32;
    $ruta_vid=obt_ruta_vid_X5($id_tst,$fech,$eventoLoc,$existe,$alias1,$alias2,$dirServidor);
    $ruta_array=$indice.",".$ruta_vid;
    guarda_rutas_guia_man($ruta_array);
  }
}
//---------------------------------------------------------------------------
  function consulta($id_tst){
    $conexion=null;
    $cursor=null;
    $error="";
    $fila=null;
    $query='SELECT NOMBRE_TESTIGO,DIRECCION_SERVIDOR, NOMBRE_USUARIO, CLAVE_USUARIO,'
          .' RUTA_VIDEOS, RUTA_VIDEOS2, GRUPO_TESTIGOS,TIPO_GUIA'
          .' FROM LISTA_TESTIGOS where ID_TESTIGO ='.$id_tst;
    $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$error);
    if($conexion!==false)
    {
      $cursor=parse_bd($conexion,$query,$error);
      if($cursor!==false)
      {
        $fila=ejecuta_select($cursor,$error);
      }
    }
    if(is_array($fila))
    {
      if(isset($fila[0]['RUTA_VIDEOS'])===false) {
        $texto="Error al obtener datos testigo ".$id_tst." : Código ".$fila[0].": ".$fila[1];
        Bitacora($texto,0);
      }else{
        $fila=$fila[0];
      }
    }else{
      $texto="Error al obtener datos testigo ".$id_tst.": ".$fila;
      Bitacora($texto,0);
    }
    libera_bd($conexion,$cursor);
    return $fila;
  }
//--------------------------------------------------------------------------
  function obtieneAlias($alias, $rutaVideo)
  {
    $carpeta="";
    if($alias!="" && $rutaVideo!="")
    {
      $datos1 = explode('\\',$rutaVideo);
      $indice= count($datos1)-2;
      $carpeta = $datos1[$indice];
    }
    return $alias."/".$carpeta;
  }
//---------------------------------------------------------------------------
  function obt_ruta_vid_X5($id_tx,$fecha_cad,$evento,&$existe,$alias1,$alias2, $dirServidor)
  {
    $existe1=0;
    $ruta_dia="";
    $fecha=str_replace("/","_",$fecha_cad);
    $aux=explode("_",$fecha);
    $year=substr($aux[2],-2);
    $fech=$aux[0].$aux[1].$year;
    $id_cad=obt_id_cad($id_tx);
    $ev=ajuste($evento,8);
    $nom_vid=$id_cad.$fech.$ev.".mp4";
    $ruta_dia=obt_carpeta_dia($fecha,$nom_vid,$existe1,$alias1,$alias2, $dirServidor);
    $existe=$existe1;
    if(!$existe)
    {
      try{
      $carpeta="";
      $carp2="";
      $aliasNvo = str_replace('servidor','testigos',$alias1);
      $carp2="/media/".$aliasNvo."/".$nom_vid;
      if(file_exists($carp2))
      {
         $carpeta="http://".$dirServidor."/".$alias1."/".$nom_vid;
         $existe1=1;
      }
      else
      {
         $carp2=str_replace(".mp4",".mov",$carp2);
         if(file_exists($carp2))
         {
            $carpeta="http://".$dirServidor."/".$alias1."/".str_replace(".mp4",".mov",$nom_vid);
            $existe1=1;
         }else
         {
            $aliasNvo = str_replace('servidor','testigos',$alias2);
            $carp3="/media/".$aliasNvo."/".$nom_vid;
            if(file_exists($carp3))
            {
               $carpeta="http://".$dirServidor."/".$alias2."/".$nom_vid;
               $existe1=1;
            }else
            {
               $carp3=str_replace(".mp4",".mov",$carp3);
               if(file_exists($carp3))
               {
                  $carpeta="http://".$dirServidor."/".$alias2."/".str_replace(".mp4",".mov",$nom_vid);
                  $existe1=1;
               }
            }
         }
      }
      $ruta_dia=$carpeta;
      $existe=$existe1;
      }catch(Exception $e)
      {
        $existe=0;
        Bitacora("ERROR al obt_carpeta X5",0);
      }
    }
    if($ruta_dia=="")
      $ruta_dia="sorry";
    return $ruta_dia;
  }
//----------------------------------------------------------------------------
function obt_ruta_vid_uni($id_tx,$fecha_cad,$evento,&$existe,$alias1,$alias2, $dirServidor)
{
   $existe1=0;
   $ruta_dia="";
   $fecha=str_replace("/","_",$fecha_cad);
   $aux=explode("_",$fecha);
   $year=substr($aux[2],-2);
   $fech=$aux[0].$aux[1].$year;
   $id_cad=obt_id_cad($id_tx);
   $ev=ajuste($evento,8);
   $nom_vid=$id_cad.$fech.$ev.".mp4";
   $ruta_dia=obt_carpeta_dia($fecha,$nom_vid,$existe1,$alias1,$alias2, $dirServidor);
   $existe=$existe1;
   if(!$existe)
   {
      try{
      $carpeta="";
      $carp2="";
      $aliasNvo = str_replace('servidor','testigos',$alias1);
      $carp2="/media/".$aliasNvo."/".$nom_vid;
      if(file_exists($carp2))
      {
         $carpeta="http://".$dirServidor."/".$alias1."/".$nom_vid;
         $existe1=1;
      }
      else
      {
         $carp2=str_replace(".mp4",".mov",$carp2);
         if(file_exists($carp2))
         {
            $carpeta="http://".$dirServidor."/".$alias1."/".str_replace(".mp4",".mov",$nom_vid);
            $existe1=1;
         }else
         {
            $aliasNvo = str_replace('servidor','testigos',$alias2);
            $carp3="/media/".$aliasNvo."/".$nom_vid;
            if(file_exists($carp3))
            {
               $carpeta="http://".$dirServidor."/".$alias2."/".$nom_vid;
               $existe1=1;
            }else
            {
               $carp3=str_replace(".mp4",".mov",$carp3);
               if(file_exists($carp3))
               {
                  $carpeta="http://".$dirServidor."/".$alias1."/".str_replace(".mp4",".mov",$nom_vid);
                  $existe1=1;
               }
            }
         }
      }
      $ruta_dia=$carpeta;
      $existe=$existe1;
      }catch(Exception $e){
        $existe=0;
        Bitacora("ERROR al obt_carpeta UNI",0);
      }
    }
    return $ruta_dia;
}
//----------------------------------------------------------------------------
function obt_tipo_guia($id_tx,&$defase,$tg,$gpo_tst)
{
   $tipo_guia=0;
   obt_tipo_guia_1($gpo_tst,$tipo_guia,$id_tx,$tg);
   if ($tipo_guia==TIPO_GUIA_A7_X5 || $tipo_guia==TIPO_GUIA_A13_X5 || $tipo_guia==TIPO_GUIA_P40_X5
      || $tipo_guia==TIPO_GUIA_A7DF_X5  || $tipo_guia==TIPO_GUIA_A13DF_X5
      || $tipo_guia==TIPO_GUIA_AAE_X5  || $tipo_guia==TIPO_GUIA_AAO_X5
      || $tipo_guia==TIPO_GUIA_A7_NAC_X5  || $tipo_guia==TIPO_GUIA_A13_NAC_X5)
  {
    $def=0;
    switch($tipo_guia)
    {
      case TIPO_GUIA_A7_X5:
        $def= 500;
      break;
      case TIPO_GUIA_A13_X5:
        $def=  500;
      break;
      case TIPO_GUIA_P40_X5:
        $def=  500;
      break;
      case TIPO_GUIA_A13DF_X5:
        $def= 766;
      break;
      case TIPO_GUIA_A7DF_X5:
        $def= 766;
      break;
      case TIPO_GUIA_AAE_X5:
        $def= 566;
      break;
      case TIPO_GUIA_AAO_X5:
        $def= 566;
      break;
      case TIPO_GUIA_A7_NAC_X5:
        $def= 200;
      break;
      case TIPO_GUIA_A13_NAC_X5:
        $def= 200;
      break;
    }
    if($id_tx==218 ||$id_tx==219 ||$id_tx==220)
      $def+=1500;
    $defase=$def;
  }else if ($tipo_guia==TIPO_GUIA_X1)
  { /*
    if (duracion!=NULL)
    {
      *duracion=info_guia->duracion;
    }
    if( info_guia->duracion  <18000000)
    ruta_vid=obt_ruta_vid_x1(id_tst,info_guia,lista_vid,offset,duracion);*/
  }
  else if ($tipo_guia==TIPO_GUIA_A7_LOC || $tipo_guia==TIPO_GUIA_A13_LOC)
  {/*
    if (duracion!=NULL)
    {
      *duracion=info_guia->duracion;
    }
    ruta_vid=obt_ruta_vid_cruzada(id_tst,info_guia,lista_vid,offset,duracion);*/
  }
  else
  {
   $defase=-1;
  }
  return $tipo_guia;
}
//----------------------------------------------------------------------------
function obt_tipo_guia_1($gpo_tst,&$tipo_guia,$id_tst,$guia)
{
  if($id_tst==1999)
  {
    $tipo_guia=TIPO_GUIA_X1;
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_LOCALES_A7)
  {
    if ($guia==1)
      $tipo_guia=TIPO_GUIA_A7_LOC;
    else
      $tipo_guia=TIPO_GUIA_1MIN_DF;
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_LOCALES_A13)
  {
    if ($guia==1)
      $tipo_guia=TIPO_GUIA_A13_LOC;
    else
      $tipo_guia=TIPO_GUIA_1MIN_DF;
  }else if ($gpo_tst==GRUPO_TESTIGOS_HD)
  {
   if ($id_tst==ID_A13_HD)
      $tipo_guia=TIPO_GUIA_A13_X5;
   else if ($id_tst==ID_A7_HD)
      $tipo_guia=TIPO_GUIA_A7_X5;
   else if($id_tst==ID_PROY40)
      $tipo_guia=TIPO_GUIA_P40_X5;
   else if ($id_tst==207)
      $tipo_guia=TIPO_GUIA_A13_X5;
   else if ($id_tst==203)
      $tipo_guia=TIPO_GUIA_A7_X5;
   else if($id_tst==211)
      $tipo_guia=TIPO_GUIA_P40_X5;
   else
      $tipo_guia=TIPO_GUIA_P40_X5;
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_DF7)
  {
    if ($id_tst==212)
    {
      $tipo_guia=TIPO_GUIA_A7DF_X5;
    }
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_DF13)
  {
    if ($id_tst==213)
    {
      $tipo_guia=TIPO_GUIA_A13DF_X5;
    }
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_NAL7)
  {
    if ($id_tst==217)
    {
      $tipo_guia=TIPO_GUIA_A7_NAC_X5;
    }
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_NAL13)
  {
    if ($id_tst==216)
    {
      $tipo_guia=TIPO_GUIA_A13_NAC_X5;
    }
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_AA_ESTE)
  {
    if ($id_tst==214||$id_tst==3)
    {
      $tipo_guia=TIPO_GUIA_AAE_X5;
    }
  }
  else if ($gpo_tst==GRUPO_TESTIGOS_AA_OESTE)
  {
    if ($id_tst==215||$id_tst==4)
    {
      $tipo_guia=TIPO_GUIA_AAO_X5;
    }
  }
  else if ($id_tst==ID_PROY40DF)
  {
    $tipo_guia=TIPO_GUIA_P40_X5;
  }else if ($id_tst==408)
  {
    $tipo_guia=TIPO_GUIA_LA_X5;
  }
}
//----------------------------------------------------------------------------
  function obt_carpeta_dia($fecha,$nom_vid,&$existe1,$alias1,$alias2, $dirServidor)
  {
    $carpeta="";
    $carp2="";
    $aliasNvo = str_replace('servidor','testigos',$alias1);
    $carp2="/media/".$aliasNvo."/".$fecha."/".$nom_vid;
    try{
    if(file_exists($carp2))
    {
      $carpeta="http://".$dirServidor."/".$alias1."/".$fecha."/".$nom_vid;
      $existe1=1;
    }
    else
    {
      $carp2=str_replace(".mp4",".mov",$carp2);
      if(file_exists($carp2))
      {
         $carpeta="http://".$dirServidor."/".$alias1."/".$fecha."/".str_replace(".mp4",".mov",$nom_vid);
         $existe1=1;
      }else
      {
         $aliasNvo = str_replace('servidor','testigos',$alias2);
         $carp3="/media/".$aliasNvo."/".$fecha."/".$nom_vid;
         if(file_exists($carp3))
         {
            $carpeta="http://".$dirServidor."/".$alias2."/".$fecha."/".$nom_vid;
            $existe1=1;
         }else
         {
            $carp3=str_replace(".mp4",".mov",$carp3);
            if(file_exists($carp3))
            {
               $carpeta="http://".$dirServidor."/".$alias2."/".$fecha."/".str_replace(".mp4",".mov",$nom_vid);
               $existe1=1;
            }else
            {
              $existe1=0;
            }
         }
      }
    }
    }catch(Exception $e){
      $existe1=0;
      Bitacora("ERROR al obt_carpeta dia",0);
    }
    return $carpeta;
  }
//--------------------------------------------------------------------------
function reconciliada($fecha,$id_tst)
{
  $conexion=null;
  $cursor=null;
  $fila=null;
  $tabla="";
  $error="";
  $guia=null;
  $query="Select tabla_guia from testigos.lista_testigos where id_testigo=".$id_tst;
  $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$error);
  if($conexion!==false)
  {
    $cursor=parse_bd($conexion,$query,$error);
    if($cursor!==false)
    {
      $fila=ejecuta_select($cursor,$error);
    }
  }
  if(is_array($fila))
  {
    if(isset($fila[0]['TABLA_GUIA']))
      $tabla=$fila[0]['TABLA_GUIA'];
  }
  if($tabla!=="")
  {
    $fila=null;
    $query="SELECT NUMERO_EV,HORA_INICIO,TIPO_EVENTO,CLIENTE,VERSION,DURACION,NO_RACK,"
          ." FECHA,CRUCE_GUIA,EVENTO_CABS,COMANDO_CABS,NUM_PAQUETE_CABS,EVENTOS_CABS,"
          ." VIDEOS_CABS,CODIGO_CABS,TX_C_CABS "
          ."FROM ".$tabla." where fecha =".$fecha." order by NUMERO_EV";
    $cursor=parse_bd($conexion,$query,$error);
    if($cursor!==false)
    {
      $fila=ejecuta_select($cursor,$error);
    }
    if(is_array($fila))
    {
      if($fila[0]==0)
      {
        $guia="ERROR";
        Bitacora($fila[1],1);
      }
      else
        $guia=$fila;
    }
  }
  libera_bd($conexion,$cursor);
  return $guia;
}
//--------------------------------------------------------------------------
function nacional($fecha,$tabla)
{
  $conexion=null;
  $cursor=null;
  $error="";
  $fila=null;
  $guia=null;
  $query="SELECT ev_tst,h_ini,tipo,nombre,version,duracion,ev_cabs,"
        ."rec_key,estado,hora_ms,rack,fecha_aire,archivo_fuente from ".$tabla
        ." where fecha_guia =".$fecha." order by num";
  $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$error);
  if($conexion!==false)
  {
    $cursor=parse_bd($conexion,$query,$error);
    if($cursor!==false)
    {
      $fila=ejecuta_select($cursor,$error);
    }
  }
  if(is_array($fila))
  {
    if($fila[0]==0)
    {
      $guia="ERROR";
      Bitacora($fila[1],1);
    }
    else
      $guia=$fila;
  }else
    $guia="";
  libera_bd($conexion,$cursor);
  return $guia;
}
//---------------------------------------------------------------------------
function genera_guia_nacional($guia,$fecha_cad,$id_tst,$alias1, $alias2, $dirServidor,$GPO_TST)
{
  date_default_timezone_set('America/Mexico_City');
  $repuesta=null;
  $verifica_todos=true;
  $fe1=explode("/",$fecha_cad);
  $fech=$fe1[1]."/".$fe1[0]."/".$fe1[2];
  $a=strtotime($fech);
  $fecha_bor=fecha_borland2($a);
  $tabla_g="GUIA_13_CABS";
  if($guia=="cabs7_air")
    $tabla_g="GUIA_7_CABS";
  else if($guia=="cabs40_air")
    $tabla_g="GUIA_40_CABS";
  else if($guia=="cabsaae")
    $tabla_g="GUIA_AA_ESTE_CABS";
  else if($guia=="cabsaaw_air")
    $tabla_g="GUIA_AA_OESTE_CABS";
  $respuesta=nacional($fecha_bor,$tabla_g);
  if($respuesta=="ERROR")
    echo 'Hubo un error al descargar la gu&iacutea';
  else if($respuesta==""||$respuesta==null)
    echo 'No hay gu&iacutea disponible para esta fecha';
  else{
    echo "<table id='Guia' style='font-size:11px;font-family:arial;width:100%'>";
    $defase=0;
    $primero=0;
    $ultimo=0;
    $sdia=0;
    $intervalo_cuadros=9000;
    $intervalo_ms=300000;
    $tipo_guia_tiempos=5;
    $tg=obt_tipo_guia($id_tst,$defase,1,$GPO_TST);
    if($tg==TIPO_GUIA_A7_LOC||$tg==TIPO_GUIA_A13_LOC)
    {
      $intervalo_cuadros=1800;
      $intervalo_ms=60000;
      $tipo_guia_tiempos=1;
    }
    $max_ev=(3600000*24)/$intervalo_ms;
    guarda_tipo_guia($tipo_guia_tiempos,0);
    for($i=0;$i<count($respuesta);$i++)
    {
      $fila=$respuesta[$i];
      $num_ev=0;
      $ruta_vid="";
      $existe=0;
      $tipo1="";
      $ruta_array="";
      $informacion="";
      $color="";
      $evcolor="";
      $estado1="";
      $estcolor="";
      $cero = $fila['EV_TST']; //strtok($cadena,"\t");
      $Hora = $fila['H_INI'];//strtok("\t");
      $tipo = $fila['TIPO'];//strtok("\t");
      $origen="NACIONAL";
      $cliente =utf8_decode(trim($fila['NOMBRE']));
      $version =utf8_decode(trim($fila['VERSION']));
      $duracion = $fila['DURACION'];
      $ch=hora_cdrs($Hora);
      $cd=hora_cdrs($duracion);
      $num_ev=intval(($ch+$cd)/$intervalo_cuadros)+1;
      if($num_ev>$max_ev){
        $num_ev=1;
        $sdia=1;
      }
      if($primero==0)
        $primero=$num_ev;
      $eventoLoc=$num_ev*32;
      if($sdia)
      {
        $fe=str_replace("/","-",$fecha_cad);
        $manana=date("d-m-Y", strtotime($fe." +1 day"));
        $fecha_cad=str_replace("-","/",$manana);
        $sdia=0;
      }
      if($verifica_todos)
        obt_ruta_vid_X5($id_tst,$fecha_cad,$eventoLoc,$existe, $alias1, $alias2, $dirServidor);
      $eventoLoc = $fila['EV_CABS'];
      if($eventoLoc == 0 && $i==0)
        $eventoLoc=32;
      $ultimo=$eventoLoc;
      $reconcile_key ="0x".ajuste($fila['REC_KEY'],6);
      $estado ="0X".ajuste(dechex($fila['ESTADO']),8);
      $nueve = $fila['HORA_MS'];
      $rack = trim($fila['RACK']);
      $fecha = $fila['FECHA_AIRE'];
      $testigo=columna_testigo($estado,"");
      if(!$existe)
        $testigo="";
      grid_tipo_evento($tipo,$estado,$tipo1,$color,$evcolor,false);
      if($evcolor=="")
        $evcolor=$color;
      columna_estado($estado,$estado1,$estcolor,false);
      if($estado1=="AIRE")
        $verifica_todos=false;
      ajusta_key($reconcile_key);
      $aux=$Hora."*".$duracion."*".$id_tst."*".$defase;
      echo "<tr id='TR".sanitize($eventoLoc)."' onclick='dato_(id,".sanitize($reconcile_key).",".sanitize($defase).")' ";
      if($estado1!="BORRADO" && $estado1!=""&& $testigo!="")
        echo " ondblclick='rep_event_guia(\"".sanitize($aux)."\")'>";
      else
        echo ">";
      echo "<td class='selectable' width='30px' align='center' bgcolor='#C0C0C0'>".sanitize($i+1)."</td>
            <td class='selectable' width='70px' align='center' ".$color.">".sanitize($Hora)."</td>
            <td class='selectable' width='70px' align='center' ".$evcolor.">".sanitize($tipo1)."</td>
            <td class='selectable' width='70px' align='center' ".$color.">".sanitize($origen)."</td>
            <td class='selectable' ".$color." width='240px'>".sanitize($cliente)."</td>
            <td class='selectable' ".$color." width='245px'>".sanitize($version)."</td>
            <td class='selectable' width='70px' align='center' ".$color.">".sanitize($rack)."</td>
            <td class='selectable' width='65px' align='center' ".$color.">".sanitize($duracion)."</td>
            <td class='selectable' width='45px' align='center' ".$color.">".sanitize($testigo)."</td>
            <td class='selectable' width='100px' align='center' ".$estcolor.">".sanitize($estado1)."</td>
      </tr>";
    }
    echo "</table>";
  }
}
//---------------------------------------------------------------------------
function genera_guia_tiempo($fecha,$intervalo,$defase,$id_tst)
{
  date_default_timezone_set('America/Mexico_City');
  $hoy=date("d/m/Y");
  $hora_act1=hora_segs(date("H:i:s"));
  $intervalo=300000;
  $ti_inter=300;
  $tipo_guia_tiempos=5;
  $duracion = "00:05:00:00";
  $resConsulta = consulta($id_tst);
  $alias1A = $resConsulta['NOMBRE_USUARIO'];
  $alias2A = $resConsulta['CLAVE_USUARIO'];
  $rutaVideos1 = $resConsulta['RUTA_VIDEOS'];
  $rutaVideos2 = $resConsulta['RUTA_VIDEOS2'];
  if($alias1A==""||$alias1A==null)
  {
    $alias1A=$alias2A;
    $rutaVideos1=$rutaVideos2;
  }
  if($alias2A==""||$alias2A==null)
  {
    $alias2A=$alias1A;
    $rutaVideos2=$rutaVideos1;
  }
  $GPO_TST=$resConsulta['GRUPO_TESTIGOS'];
  $tipo_guia=$resConsulta['TIPO_GUIA'];
  $alias1 = obtieneAlias($alias1A, $rutaVideos1);
  $alias2 = obtieneAlias($alias2A, $rutaVideos2);
  $dirServidor = $resConsulta['DIRECCION_SERVIDOR'];
  if ($tipo_guia==TIPO_GUIA_1MIN_DF)
  {
    $intervalo=60000;
    $ti_inter=60;
    $tipo_guia_tiempos=1;
    $duracion = "00:01:00:00";
  }else if ($tipo_guia==TIPO_GUIA_5MIN_DF)
  {
    $intervalo=300000;
    $ti_inter=300;
  }else if ($tipo_guia==TIPO_GUIA_5MIN_PAC)
  {
    $intervalo=300000;
    $ti_inter=300;
  }
  guarda_tipo_guia($tipo_guia_tiempos,0);
  guarda_tipo_guia($tipo_guia,2);
  $max_ev=(3600000*24)/$intervalo;
  $ultimo_ver=$hora_act1/$ti_inter;
  if($hoy!=$fecha)
    $ultimo_ver=$max_ev;
  $cero = "NACIONAL";
  $cliente =obt_fecha_completa($fecha);
  $tipo = "TIEMPO";
  $version ="Versi&oacuten no disponible";
  $rack = "NINGUNO";
  $estado = "PASADO";
  ?>
    <table id='Guia_tiempo' style='font-size:12px; width:100%'>
  <?php
  for($cc=0;$cc<$max_ev;$cc++)
  {
    $existe=0;
    $indice=$cc+1;
    $Hora = seg_horas($cc*$ti_inter);
    $eventoLoc = ($cc+1)*32;
    $reconcile_key = 0;
    $nueve = "";
    $fechab = "";
    $testigo = "LISTO";
    $trece = "";
    $catorce = "";
    $hora_act0=strtotime($Hora);
    if($cc>$ultimo_ver)
    {
      $existe=0;
    }else
      $ruta_vid=obt_ruta_vid_uni($id_tst,$fecha,$eventoLoc,$existe, $alias1, $alias2,$dirServidor);
    if(!$existe)
    {
      $ruta_vid="sorry";
      $testigo="";
    }
    $ruta_array=$indice.",".$ruta_vid;
    guarda_ruta($ruta_array);
    $aux=hora_cdrs($Hora)."*".$ruta_vid;
    ?>
      <tr id="TR<?php echo sanitize($indice) ?>" onclick="dato_(id,0,0)"
          ondblclick="reproduce('<?php echo sanitize($aux) ?>')">
        <td class='selectable' width='30' align='center'><?php echo sanitize($indice)?></td>
        <td class='selectable' width='70' align='center'><?php echo sanitize($Hora)?></td>
        <td class='selectable' width='70' align='center'><?php echo sanitize($tipo)?></td>
        <td class='selectable' width='70' align='center'><?php echo sanitize($cero)?></td>
        <td class='selectable' width='240'><?php echo sanitize($cliente)?></td>
        <td class='selectable' width='245'><?php echo sanitize($version)?></td>
        <td class='selectable' width='70' align='center'><?php echo sanitize($rack)?></td>
        <td class='selectable' width='65' align='center'><?php echo sanitize($duracion)?></td>
        <td class='selectable' width='45' align='center'><?php echo sanitize($testigo)?></td>
        <td class='selectable' width='100' align='center'><?php echo sanitize($estado)?></td>
      </tr>
    <?php
  }
  ?>
    </table>
  <?php
}
//------------------------------------------------------------------------
function genera_guia_reconciliada($id_tst,$fecha,$alias1, $alias2, $dirServidor,$GPO_TST)
{
  date_default_timezone_set('America/Mexico_City');
  $respuesta=null;
  $fe1=explode("/",$fecha);
  $fech=$fe1[1]."/".$fe1[0]."/".$fe1[2];
  $a=strtotime($fech);
  $fecha_bor=fecha_borland2($a);
  $fecha_cad=$fecha;
  $respuesta="";
  $respuesta=reconciliada($fecha_bor,$id_tst);
  if($respuesta!=="" && $respuesta!==null)
  {
    $conciliacion=$respuesta;
    $total=count($conciliacion);
    $defase=0;
    $indice = 1;
    $primero=0;
    $ultimo=0;
    $sdia=0;
    $intervalo_cuadros=9000;
    $intervalo_ms=300000;
    $tipo_guia_tiempos=5;
    $tg=obt_tipo_guia($id_tst,$defase,1,$GPO_TST);
    $defase=0;
    if($tg==TIPO_GUIA_A7_LOC||$tg==TIPO_GUIA_A13_LOC)
    {
      $intervalo_cuadros=1800;
      $intervalo_ms=60000;
      $tipo_guia_tiempos=1;
    }
    $max_ev=(3600000*24)/$intervalo_ms;
    guarda_tipo_guia($tipo_guia_tiempos,0);
    guarda_tipo_guia(1,1); //Es una guia conciliada
    echo "<table id='Guia' style='font-size:12px; width:100%'>";
    for($i=0;$i<$total;$i++)
    {
      $no=0;
      $hora=0;
      $hora_cad="";
      $tipo="";
      $origen="CABS";
      $cliente="";
      $version="";
      $rack="";
      $durancion="";
      $estado="";
      $testigo="LISTO";
      $fecha_1="";
      $cruce="";
      $color="";
      $estcolor="";
      $tipo1="";
      $estado1="";
      $reconcile_key="0";
      $existe=0;
      $fila=$conciliacion[$i];
      if($fila!=null)
      {
        $no=$fila['NUMERO_EV'];
        $hora =$fila['HORA_INICIO'];
        $hora_cad=cuadros_hor($hora);
        $tipo = $fila['TIPO_EVENTO'];
        if($tipo==1)
          $tipo="N";
        if($tipo==2)
          $tipo="P";
        if($tipo==3)
          $tipo="L";
        if($tipo==4)
          $tipo="V";
        if($tipo==5)
        {
          $tipo="CL";
          $origen="LOCAL";
        }
        if($tipo==6)
        {
          $tipo="B";
          $origen="LOCAL";
        }
        $cliente =utf8_decode(trim($fila['CLIENTE']));
        $version =utf8_decode(trim($fila['VERSION']));
        $duracion=$fila['DURACION'];;
        $dur_cad=cuadros_hor($duracion);
        $ch=$hora;
        $cd=$duracion;
        $num_ev=intval(($ch+$cd)/$intervalo_cuadros)+1;
        if($num_ev>$max_ev)
        {
          $num_ev=1;
          $sdia=1;
        }
        if($primero==0)
          $primero=$num_ev;
        $eventoLoc=$num_ev*32;
        if($sdia)
        {
          $fe=str_replace("/","-",$fecha_cad);
          $manana=date("d-m-Y", strtotime($fe." +1 day"));
          $fecha_cad=str_replace("-","/",$manana);
          $sdia=0;
        }
        obt_ruta_vid_X5($id_tst,$fecha_cad,$eventoLoc,$existe, $alias1, $alias2, $dirServidor);
        $rack=$fila['NO_RACK'];
        $fecha_1=$fila['FECHA'];
        $cruce=$fila['CRUCE_GUIA'];
        $evcabs=$fila['EVENTO_CABS'];
        $cmd=$fila['COMANDO_CABS'];
        columna_estado($cruce,$estado1,$estcolor,true);
        if(!$existe)
          $testigo="";
        grid_tipo_evento($tipo,$cmd,$tipo1,$color,$evcolor,true);
        $eventoLoc=$no*32;
        $ultimo=$eventoLoc;
        $aux=$hora_cad."*".$dur_cad."*".$id_tst."*".$defase;
        echo "<tr id='TR".sanitize($eventoLoc)."' onclick='dato_(id,".sanitize($reconcile_key).",".sanitize($defase).")'";
        if($testigo!="")
          echo " ondblclick='rep_event_guia(\"".sanitize($aux)."\")' >";
        else
          echo ">";
        echo "<td class='selectable' width='30px' align='center' bgcolor='#C0C0C0'>".sanitize($no)."</td>
            <td class='selectable' width='70px' align='center' ".$color.">".sanitize($hora_cad)."</td>
            <td class='selectable' width='70px' align='center' ".$color.">".sanitize($tipo1)."</td>
            <td class='selectable' width='70px' align='center' ".$color.">".sanitize($origen)."</td>
            <td class='selectable' ".$color." width='240px'>".sanitize($cliente)."</td>
            <td class='selectable' ".$color." width='245px'>".sanitize($version)."</td>
            <td class='selectable' width='70px' align='center' ".$color.">".sanitize($rack)."</td>
            <td class='selectable' width='65px' align='center' ".$color.">".sanitize($dur_cad)."</td>
            <td class='selectable' width='45px' align='center' ".$color.">".sanitize($testigo)."</td>
            <td class='selectable' width='100px' align='center' ".$estcolor.">".sanitize($estado1)."</td>
            </tr>";
      }
    }
    guarda_defase($defase,$ultimo);
    echo "</table>";
    Bitacora("Guia Reconciliada Cargada ",0);
  }else{
    echo 'No hay gu&iacutea disponible para esta fecha';
  }
}
//------------------------------------------------------------------------
function ajusta_key(&$reconcile_key)
{
  $rk=$reconcile_key;
  $es=is_numeric($rk);
  if(!$es)
  {
      $reconcile_key=0;
  }
}
//---------------------------------------------------------------------------
function genera_nom_guia($fecha_,$guia,&$gra,&$dir_rem,&$tabla)
{
  $_gra="";
  $id_guia="";
  $fe_guia=explode("/",$fecha_);
  switch($guia)
  {
    case TIPO_GUIA_A7_NAC_X5:
    case TIPO_GUIA_A7_NAC:
    case TIPO_GUIA_A7_LOC:
    case TIPO_GUIA_A7_X5:
    case TIPO_GUIA_A7DF_X5:
      $id_guia="001";
      $dir_rem="cabs7_air";
      $tabla=1;
    break;
    case TIPO_GUIA_A13_NAC_X5:
    case TIPO_GUIA_A13_NAC:
    case TIPO_GUIA_A13_LOC:
    case TIPO_GUIA_A13_X5:
    case TIPO_GUIA_A13DF_X5:
      $id_guia="002";
      $dir_rem="cabs13_air";
      $tabla=2;
    break;
    case "C2TV":
    case "C4TV":
    case "C5TV":
    case "C9TV":
      $id_guia="t";
      $dir_rem="cabstmpo";
    break;
    case TIPO_GUIA_AAE_NAC:
      $id_guia="e";
      $dir_rem="cabsaae";
      $tabla=3;
    break;
    case TIPO_GUIA_AAE_X5:
      $id_guia="003";
      $dir_rem="cabsaae";
      $tabla=3;
     // fec_cad=fecha.FormatString("yymmdd")+".gra";
    break;
    case TIPO_GUIA_AAP_NAC:
    case TIPO_GUIA_AAO_X5:
      $id_guia="004";
      $dir_rem="cabsaaw_air";
      $tabla=4;
//      fec_cad=fecha.FormatString("yymmdd")+".gra";
    break;
    case TIPO_GUIA_AAP_LA:
    case TIPO_GUIA_LA_X5:
      $id_guia="w";
      $dir_rem="cabsaaw";
    break;
    case TIPO_GUIA_5MIN_DF:
      $id_guia="t";
      $dir_rem="cabstmpo";
    break;
    case TIPO_GUIA_1MIN_DF:
      $id_guia="t";
      $dir_rem="tiempo_1min";
    break;
    case TIPO_GUIA_5MIN_PAC:
      $id_guia="p";
      $dir_rem="cabstmpo_pac";
    break;
    case TIPO_GUIA_P40_X5:
      $id_guia="001";
      $dir_rem="cabs40_air";
      $tabla=5;
    break;
  }
  $_gra=$id_guia.substr($fe_guia[2],-2).$fe_guia[1].$fe_guia[0].".gra";
  $gra=$_gra;
}
//------------------------------------------------------------------------
function gen_pagina()
{
  $guia_ =$_GET['guia'];
  $fecha_=$_GET['fecha'];
  $id_tst=$_GET['id_tst'];
  $TG=$_GET['TG'];
  if (!empty($guia_))
  {
    $guia=$guia_;
  }

?>
   <!DOCTYPE html lang="es">
    <html>
      <head>
        <!--<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>-->
        <meta http-equiv="Content-Type" content="text/html; charset="UTF-8">
        <link rel="stylesheet" href="css/guias.css">
        <link rel="stylesheet" href="css/simple.css">
        <link rel="stylesheet" href="css/general1.css">
        <script type="text/javascript" src="js/jSelect.js"></script>
        <script type="text/javascript">
        var ev_actual=0;
        var tipo_guia=0;
        var tipo_guia_tiempos=0;
        var tipo_conciliacion=0;
        var tipo_guia_bd=0;
        var gpo_tst=0;
        var ev_selec=0;
        var tam_ventana=0;
        var rutas_vid=[];
        var rutas_vid_guia=[];
        var rutas_vid_tomorrow=[];
        var drag_enter=0;
        var defase_guia=0;
        var ultimo_evento=0;
        var id_tx=0;
        var posicion=0;
        function set_timer_recarga()
        {
          clearTimeout(timer_recarga);
          timer_recarga=null;
          timer_recarga=setTimeout(recarga_guia,60000,0);
        }
        function seleccionados()
        {
          var datos="";
          if(!tipo_guia)
            datos=ev_seleccion_guia();
          else
            datos=ev_seleccion_tiempos();
          return datos;
        }
        function tipo_guia_despliegue()
        {
         return tipo_guia_tiempos;
        }
        function exp_seleccionados(fecha)
        {
          var datos="";
          var ini=0;
          var dur=0;
          var fin=0;
          var aux=null;
          var aux1=null;
          if(!tipo_guia)
          {
            datos=ev_seleccion_guia();
            if(datos.indexOf("]")>-1)
            {
               aux1=datos.split("]");
               aux=aux1[0].split("*");
            }else
               aux=datos.split("*");
            if(aux[0]!="")
            {
              ini=parseInt(aux[0]);
              dur=parseInt(aux[aux.length-1]);
              fin=ini+dur;
              datos=procesa_ruta(ini,dur,fin,fecha,29.97);
            }else
              datos="Sin videos";
          }else
            datos=exporta_ev_tiempo(fecha);
          return datos;
        }
        function procesa_ruta(inicio,duracion,fin,fecha,rate)
        {
            var aux="";
            var top = window.parent;
            var hora=top.cuadros_hor(fin);
            var fe=fecha.split("/");
            var carpeta=fe[0]+"_"+fe[1]+"_"+fe[2];
            var inter_ms=9000;
            var max_ev=288;
            if(rate==29.97)
              inter_ms=8991;
            if(!tipo_guia)
              var pmr_cua=top.obt_hor_cua(document.getElementById("TR32").cells[1].innerHTML);
            else
              var pmr_cua=top.obt_hor_cua(document.getElementById("TR1").cells[1].innerHTML);
            if(tipo_guia_tiempos==1)
            {
              if(rate==29.97)
                inter_ms=1798.2;
              else
                inter_ms=1800;
               max_ev=1440;
            }
            var pmr_ev=(parseInt(pmr_cua/inter_ms)+1);
            var num_ev=0;
            if(inicio!=0)
              num_ev=(parseInt(inicio/inter_ms)+1); //9000 -> 5 min---1800 -> 1 min
            else
              num_ev=1;
            var num_ev_final=(parseInt(fin/inter_ms)+1);
            if(num_ev_final>max_ev)
              num_ev_final=num_ev_final-max_ev;
            var i=num_ev;
            if(i<pmr_ev && num_ev_final<=pmr_ev) // Cambio de fecha
              carpeta=cambia_dia(fe[1]+"/"+fe[0]+"/"+fe[2]);
            aux=id_tx+"-"+Math.round(inicio*(1000/rate))+"-"+carpeta+"-"+Math.round(duracion*(1000/rate));
            return aux;
        }
        function tiempo_video(evento,cuadros,top,rate)
        {
            var inter_ms=9000;
            var dia_cuadros=2591999; //23:59:59:29
            if(rate==29.97)
            {
              inter_ms=8991;
              dia_cuadros=2589407;
            }
            if(tipo_guia_tiempos==1)
            {
              if(rate==29.97)
                inter_ms=1798.2;
              else
                inter_ms=1800;
            }
            var hora_ev=(evento-1)*inter_ms;
            var diferencia=0;
            if(cuadros>dia_cuadros)
               cuadros-=(dia_cuadros+1);
            var hora_ev_g=top.cuadros_hor(cuadros);
            var hora_ev_c=top.cuadros_hor(hora_ev);
               diferencia=Math.abs(cuadros-hora_ev);
            var dif_hora=top.cuadros_hor(diferencia);
            return dif_hora;
        }
        function cambia_dia(fecha)
        {
            var top = window.parent;
            var f = new Date(fecha);
            var dayOfMonth = f.getDate();
            f.setDate(dayOfMonth + 1);
            var nuevo= top.ajusta(f.getDate(),2) + "_" + top.ajusta((f.getMonth() +1),2) + "_" + f.getFullYear();
            return nuevo;
        }
        function ev_seleccion_guia()
        {
          var ids = [];
          var top = window.parent;
          var aux="";
          var aux1="";
          var estado="";
          var id=0;
          var hora_ini="";
          var duracion="";
          var testigo="";
          var primero=0;
          var dur=0;
          var dur_total=0;
          $(".selected1").each(function()
          {
            id=this.id;
            if(id!="")
            {
              hora_ini=document.getElementById(id).cells[1].innerHTML;
              duracion=document.getElementById(id).cells[7].innerHTML;
              testigo=document.getElementById(id).cells[8].innerHTML;
              estado=document.getElementById(id).cells[9].innerHTML;
              estado=estado.trim();
              if(estado!="BORRADO"&&testigo!="")
              {
                dur=top.obt_hor_cua2(duracion);
                if(aux=="")
                {
                  aux=obt_rutas_guias(hora_ini,duracion,top,0,defase_guia);
                  dur_total=dur;
                }
                else
                {
                  aux1=obt_rutas_guias(hora_ini,duracion,top,0,defase_guia);
                  dur_total+=dur;
                }
              }
            }
          });
            if(aux1=="")
              aux+="*"+tipo_guia_bd+"*"+dur_total;
            else
              aux+="*"+tipo_guia_bd+"*"+dur_total+"]"+aux1+"*"+dur;
          return aux;
        }
        function ev_seleccion_tiempos()
        {
          var ids = [];
          var aux="";
          var aux1="";
          var id=0;
          var hora_ini=0;
          var testigo="";
          var id_indice="";
          var top = window.parent;
          $(".selected1").each(function(){
            id=this.id;
            if(id!=="")
            {
              testigo=document.getElementById(id).cells[8].innerHTML;
              if(testigo!="")
              {
                hora_ini=top.obt_hor_cua(document.getElementById(id).cells[1].innerHTML);
                id_indice=this.id.replace("TR","");
                if(aux=="")
                  aux=hora_ini+"*"+rutas_vid[id_indice];
                else
                  aux1=","+rutas_vid[id_indice];
              }
            }
          });
           aux+=aux1+"*"+tipo_guia_bd;
          return aux;
        }
        function exporta_ev_tiempo(fecha)
        {
          var top = window.parent;
          var fe=fecha.split("/");
          var dur_ms=0;
          var carpeta=fe[0]+"_"+fe[1]+"_"+fe[2];
          var nom_=fe[0]+fe[1]+fe[2].substr(2,2);
          var id_="";
          var aux="";
          var aux1="";
          var id=0;
          var hora_ini=0;
          var testigo="";
          var sin_videos=0;
          var duracion=top.hor_seg(document.getElementById("TR1").cells[7].innerHTML)*1000;
          if(id_tx<100)
            id_=top.ajusta(id_tx,2);
          else
            id_=top.ajusta(id_tx,4);
          nom_=id_+nom_;
          $(".selected1").each(function(){
            id=this.id;
            if(id!=="")
            {
              testigo=document.getElementById(id).cells[8].innerHTML;
              if(testigo!="")
              {
                if(aux=="")
                {
                  hora_ini=top.hor_seg(document.getElementById(id).cells[1].innerHTML)*1000;
                  dur_ms=duracion;
                  aux=id_tx+"-"+hora_ini+"-"+carpeta;
                }
                else
                  dur_ms+=duracion;
              }
              sin_videos=1;
            }
          });
            if(sin_videos&&aux=="")
              aux="Sin videos";
            else
              aux+="-"+dur_ms;
          return aux;
        }
        function dato_(evento,key,defase)
        {
          var objeto=null;
          objeto=document.getElementById(evento);
         if($('#'+evento).length)
         var dato=objeto.cells[4].innerHTML;
         dato+="*"+objeto.cells[5].innerHTML;
         dato+="*"+objeto.cells[6].innerHTML;
         dato+="*"+objeto.cells[7].innerHTML;
         dato+="*"+key.toString(16);
         dato+="*"+objeto.cells[1].innerHTML;
         carga_dato(dato);
         ev_selec=evento;
         defase_guia=defase;
        }
        function onfocus_fila(evento)
        {
            var fila=document.getElementById(evento);
            onblur_fila();
            for(var i=0;i<10;++i)
            {
              $(fila.cells[i]).addClass("selected1");
            }
            $("#"+evento).addClass("selected1");
            ev_selec=evento;
        }
        function onfocus_fila_varios(evento)
        {
            var fila=document.getElementById(evento);
            for(var i=0;i<10;++i)
            {
              $(fila.cells[i]).addClass("selected1");
            }
            $("#"+evento).addClass("selected1");
        }
//--------------------------------------------------------------------------
      function onscrol_(event)
      {
         var e = event || evt; // for trans-browser compatibility
         var key = e.which || e.keyCode;
         var sig_=0;
         var total=288;
         var intervalo=1;
         var siguiente=0;
         if (key== 38 || key == 40)
         {
            if(ev_selec!=0)
            {
               if(tipo_guia)
               {
                  if(tipo_guia_tiempos==1)
                     total=1440;
               }else
               {
                  intervalo=32;
                  total=ultimo_evento;
               }
               if(key==38)
                  sig_=ev_selec-intervalo;
               else
               {
                  sig_=ev_selec+intervalo;
                  siguiente=1;
               }
               if(sig_>0 && sig_<=total)
               {
                  if(e.shiftKey==1)
                  {
                     var o=jQuery.selector;
                     var primero=o['first'].parentNode['id'];

                     if(siguiente==1)
                     {
                        if(primero>=sig_)
                           toggle_fila(ev_selec);
                        else
                           toggle_fila(sig_);
                     }
                     else
                     {
                        if(primero>=ev_selec)
                           onfocus_fila_varios(sig_);
                        else
                           toggle_fila(ev_selec);
                     }
                  }
                  else
                  {
                     var obj=document.getElementById(sig_);
                     onfocus_fila(sig_);
                     jQuery.selector['first']=obj.cells[0];
                  }
                  ev_selec=sig_;
               }
               preventDefault(e);
               fin_ventana(ev_selec);
               return false;
            }
         }else if (key== 35 || key == 36)
         {
            if(tipo_guia)
            {
               if(tipo_guia_tiempos==1)
                  total=1440;
            }else
            {
               intervalo=32;
               total=ultimo_evento;
            }
            if(key==35)
            {
               onfocus_fila(total);
               ev_selec=total;
            }
            else
            {
               onfocus_fila(intervalo);
               ev_selec=intervalo;
            }
            var obj=document.getElementById(ev_selec);
            jQuery.selector['first']=obj.cells[0];
         }
      }
//--------------------------------------------------------------------------
      function fin_ventana(evento)
      {
         var px, py, py_aux,py_aux2;
         var ventana=$(window).height();
         var elemento = $("#"+evento);
         var posicion = elemento.position();
         py = posicion.top;
         px = posicion.left +document.body.scrollLeft;
         py_aux2=document.body.scrollTop;
         py_aux=ventana+document.body.scrollTop;
         if((py+19)>=py_aux)
         {
            window.scrollTo(px, $(window).scrollTop()+19);
            px = posicion.left +document.body.scrollLeft;
            py_aux2=document.body.scrollTop;
            py_aux=ventana+document.body.scrollTop;
            if((py+19)>=py_aux)
               ir_evento(evento);
         }else if((py_aux2)>=py)
         {
            window.scrollTo(px, $(window).scrollTop()-19);
            px = posicion.left +document.body.scrollLeft;
            py_aux2=document.body.scrollTop;
            py_aux=ventana+document.body.scrollTop;
            if((py_aux2)>=py)
               ir_evento(evento);
         }
      }
      function preventDefault(e)
      {
         e = e || window.event;
         if (e.preventDefault)
         e.preventDefault();
         e.returnValue = false;
      }
        function onblur_fila()
        {
          $(".selected1").each(function(){
            $(this).removeClass("selected1");
          });
        }
        function toggle_fila(evento)
        {
            if($("#"+evento).is('.selected1'))
            {
               var fila=document.getElementById(evento);
               for(var i=0;i<10;++i)
               {
                  $(fila.cells[i]).removeClass("selected1");
               }
               $("#"+evento).removeClass("selected1");
            }else
               onfocus_fila_varios(evento);
        }
        function obt_actual(id_testigo)
        {
            id_tx=id_testigo;
            var ev=ev_seleccionado_guia;
            if(ev!="0")
            {
               if(ev.indexOf(",")<0)
               {
                  onfocus_fila(ev);
                  ir_evento(ev);
               }else
               {
                  var ids=ev.split(",");
                  var primer=ids[0];
                  for(var i=0;i<ids.length;++i)
                  {
                     onfocus_fila_varios(ids[i]);
                  }
                  ir_evento_varios(primer);
               }
            }
            $("#Guia tbody tr").each(function (index)
            {
              var campo="";
              $(this).children("td").each(function (index2)
              {
                switch (index2)
                {
                  default:
                  break;
                  break;
                  case 9:
                    campo = $(this).text();
                    if(campo=="AIRE")
                    {
                      var trid = $(this).closest("tr").attr("id"); // table row ID
                      ev_actual=trid;
                      return false;
                    }
                  break;
                }
              })
            });
        }
        function reproduce(ruta)
        {
          var aux=ruta+"*"+tipo_guia_bd;
          if(aux.indexOf("sorry")<0)
          {
            var top = window.parent;
            top.muestraReproductor(aux);
          }
        }
        function obt_rutas_guias(hora,duracion,top,id_tst,defase)
        {
            var objeto=null;
            objeto=document.getElementById("TR32");
            var ruta_="";
            var inter_ms=9000;
            var max_ev=288;
            var cuadros=top.obt_hor_cua(hora)+(defase*30/1000);
            var cuadros1=top.obt_hor_cua2(hora)+(defase*29.97/1000)+1;
            var dur_cuadros=top.obt_hor_cua(duracion);
            if(!tipo_conciliacion)
                var pmr_cua=top.obt_hor_cua(objeto.cells[1].innerHTML);
              else
                var pmr_cua=511389;
            if(tipo_guia_tiempos==1)
            {
               inter_ms=1800;
               max_ev=1440;
            }
            var pmr_ev=(parseInt(pmr_cua/inter_ms)+1);
            var num_ev=0;
            if(cuadros!=0)
              num_ev=(parseInt(cuadros/inter_ms)+1); //9000 -> 5 min
            else
              num_ev=1;
            var num_ev_final=(parseInt((cuadros+dur_cuadros)/inter_ms)+1);
            if(num_ev_final>max_ev)
              num_ev_final=num_ev_final-max_ev;
            var i=num_ev;
            if(i>pmr_ev && num_ev_final<pmr_ev)
            {
               ruta_=cuadros1+"*"+rutas_vid_guia[i];
               ruta_+=","+rutas_vid_tomorrow[num_ev_final];
            }
            else
            {
              if(i>=pmr_ev && num_ev_final>=pmr_ev)
                var videos=rutas_vid_guia;
              else if(i<pmr_ev && num_ev_final<=pmr_ev)
                var videos=rutas_vid_tomorrow;
               ruta_=cuadros1+"*"+videos[i];
               ruta_+=","+videos[num_ev_final];
            }
            return ruta_;
        }
        function rep_event_guia(datos)
        {
            var top = window.parent;
            var dato=datos.split("*");
            var ruta=obt_rutas_guias(dato[0],dato[1],top,dato[2],dato[3]);
            var dur_cuadros=top.obt_hor_cua2(dato[1]);
            ruta=ruta+"*"+tipo_guia_bd+"*"+dur_cuadros;
            top.muestraReproductor(ruta);
        }
        function hora_guia_(hora)
        {
          var top = window.parent;
          var campo=0;
          var id_ant=32;
          var salir=false;
          var prmhora=top.hor_seg(document.getElementById("TR32").cells[1].innerHTML);
          $("#Guia tbody tr").each(function (index)
          {
            $(this).children("td").each(function (index2)
            {
              if(index2==1)
              {
                campo =top.hor_seg($(this).text());
                if(campo==hora)
                {
                  id_ant = $(this).closest("tr").attr("id"); // table row ID
                  ir_evento(id_ant);
                  salir=true;
                }else if(campo>hora && prmhora<hora)
                {
                  ir_evento(id_ant);
                  salir=true;
                }else
                  id_ant=$(this).closest("tr").attr("id");
              }
            })
            if(salir)
            {
               var obj=document.getElementById(id_ant);
               jQuery.selector['first']=obj.cells[0];
               return false;
            }
          });
        }
        function ir_evento(evento)
        {
            var ev_=0;
            ev_=evento;
            onfocus_fila(ev_)
           $('#'+ev_).ScrollTo({
              onlyIfOutside: true
            });
        }
        function ir_evento_varios(evento)
        {
            var ev_=0;
            ev_=evento;
             $('#'+ev_).ScrollTo({
              onlyIfOutside: true
            });
        }
        function scroll_fin(e)
        {
            var px, py, evento,py_aux,py_aux2;
            var ventana=$(window).height();
            evento = e;
            py = evento.clientY +document.body.scrollTop;
            px = evento.clientX +document.body.scrollLeft;
            py_aux2=document.body.scrollTop;
            py_aux=ventana+document.body.scrollTop;
            if((py+20)>=py_aux && drag_enter)
            {
              window.scrollTo(px, $(window).scrollTop()+15);
            }else if((py_aux2+20)>=py && drag_enter)
            {
              window.scrollTo(px, $(window).scrollTop()-15);
            }
        }
        function mouseDown()
        {
          drag_enter=1;
        }
        function mouseUp()
        {
          drag_enter=0;
        }
        function actual(evento)
        {
            var ev_=0;
            if(ev_actual!=0)
              ev_=ev_actual;
            else
            {
              if(!tipo_conciliacion)
                ev_=evento;
              else
                ev_=ultimo_evento;
              ev_="TR"+ev_;
            }
            onfocus_fila(ev_);
           $('#'+ev_).ScrollTo();
            var obj=document.getElementById(ev_);
            jQuery.selector['first']=obj.cells[0];
        }
        function recarga_guia(tipo_recarga)
        {
          var top= window.parent;
          var ids = [];
          var result="0";
           $('.selected1').each(function(){
               if(this.id!="")
                ids.push(this.id);
           });
           if(tipo_recarga==0)
           {

          //  Checar si existe algún cambio antes de mandar a recarga.

            if(ids.length>0)
               top.recarga_guia1(ids.toString());
            else
               top.recarga_guia1("0");

          //  checa_actualizacion(ids);
           }else{
            if(ids.length>0)
              result=ids.toString();
            return result;
           }
        }
        function exporta_guia()
        {
          var texto="";
          if($('#Guia').length)
          {
            $("#Guia tbody tr").each(function (index){
              $(this).children("td").each(function (index2){
                texto+=$(this).text().replace(/&/g,"amp;")+"\t";
              });
              texto+="\n";
            });
          }
          return texto;
        }
      function checa_actualizacion(ids)
      {
        var ev_=0;
        var top=window.parent;
        var indice=0;
        var inter_s=300;
        var guia_vis=0;    //0=Guia,1=tiempo,2=conciliada
        var momentoActual = new Date();
        var hora = momentoActual.getHours();
        var minuto = momentoActual.getMinutes();
        var segundo = momentoActual.getSeconds();
        var sgs= (hora*60*60)+(minuto*60)+segundo;
        var ruta="";
        var forzado=0;
        var fecha_guia=top.fecha_cargada;
        if(ev_actual!=0)
          ev_=ev_actual;
        else
        {
          guia_vis=2;
          if(!tipo_conciliacion)
          {
            ev_=ultimo_video(0);
            ruta=rutas_vid[ev_];
            ev_+=1;
            guia_vis=1
          }else
            ev_=ultimo_evento;
        }
        if(guia_vis!==1)
        {
          indice=ultimo_video(1);
          if(indice==-1)
          {
            indice=ultimo_video(2);
            ruta=rutas_vid_tomorrow[indice];
          }else
            ruta=rutas_vid_guia[indice];
        }
        if(indice==-1){
          forzado=1;
          ruta="sorry";
        }
        else{
          ruta=ruta.replace("http://","");
          ruta=ruta.substring(ruta.indexOf("/")+1);
          ruta=ruta.replace(/\//g,"*");
        }
        $.ajax({
          type: 'POST',
          url: 'actualizacion_guia.php',
          data: 'guia='+guia_vis+'&evento='+ev_+"&testigo="+id_tx+"&ruta="+ruta
                +"&gpo_tst="+gpo_tst+"&fecha_guia="+fecha_guia+"&forzado="+forzado,
          cache: false,
          success:function(Respuesta)
          {
            if(Respuesta==1 || Respuesta==2)
            {
              if(Respuesta==2)
              if(ids.length>0)
                top.recarga_guia1(ids.toString());
              else
                top.recarga_guia1("0");
            }else{
              set_timer_recarga();
            }
          },
          error:function(){
            console.log("Algo salio mal");
          }
        });
      }
      function ultimo_video(tipo)
      {
        var ultimo=-1;
        var i=0;
        var aux="";
        var max=0;
        var vid_aux=null;
        if(tipo==0)
        {
          vid_aux=rutas_vid;
          max=rutas_vid.length;
        }else if(tipo==1)
        {
          vid_aux=rutas_vid_guia;
          max=rutas_vid_guia.length;
        }else{
          vid_aux=rutas_vid_tomorrow;
          max=rutas_vid_tomorrow.length;
        }
        for(i=1;i<max;i++)
        {
          aux=vid_aux[i];
          if(aux!=null)
          {
            if(aux.indexOf("sorry")<0)
              ultimo=i;
          }
        }
        return ultimo;
      }
      </script>
      </head>
      <body onmousemove="scroll_fin(event)"
            onmousedown="mouseDown()" onmouseup="mouseUp()" onkeydown="onscrol_(event)">
         <div class="limiter" id="deselectArea">
<?php
  $gra="";
  $dir_rem="";
  if($TG==1)
  {
    $tipo_guia=0;
    $tabla=0;
    $resConsulta = consulta($id_tst);
    $alias1A = $resConsulta['NOMBRE_USUARIO'];
    $alias2A = $resConsulta['CLAVE_USUARIO'];
    $rutaVideos1 = $resConsulta['RUTA_VIDEOS'];
    $rutaVideos2 = $resConsulta['RUTA_VIDEOS2'];
    if($alias1A==""||$alias1A==null)
    {
      $alias1A=$alias2A;
      $rutaVideos1=$rutaVideos2;
    }
    if($alias2A==""||$alias2A==null)
    {
      $alias2A=$alias1A;
      $rutaVideos2=$rutaVideos1;
    }
    $GPO_TST=$resConsulta['GRUPO_TESTIGOS'];
    $tipo_guia=$resConsulta['TIPO_GUIA'];
    guarda_tipo_guia($tipo_guia,2);
    $alias1 = obtieneAlias($alias1A, $rutaVideos1);
    $alias2 = obtieneAlias($alias2A, $rutaVideos2);
    $dirServidor = $resConsulta['DIRECCION_SERVIDOR'];
    obt_tipo_guia_1($GPO_TST,$tipo_guia,$id_tst,1);
    genera_nom_guia($fecha_,$tipo_guia,$gra,$dir_rem,$tabla);
    guarda_tipo_guia($tabla,3);
    genera_dir_videos($fecha_,$id_tst,$alias1, $alias2, $dirServidor,$GPO_TST,$tipo_guia);
    gen_dir_videos_dia_man($fecha_,$id_tst,$alias1, $alias2, $dirServidor,$GPO_TST,$tipo_guia);
    genera_guia_nacional($dir_rem,$fecha_,$id_tst,$alias1,$alias2,$dirServidor,$GPO_TST);
  }else if($TG==2)
  {
   genera_guia_tiempo(substr($guia,1),300000,0,$id_tst);
  }else if($TG==3)
  {
    $tipo_guia=0;
    $resConsulta = consulta($id_tst);
    $alias1A = $resConsulta['NOMBRE_USUARIO'];
    $alias2A = $resConsulta['CLAVE_USUARIO'];
    $rutaVideos1 = $resConsulta['RUTA_VIDEOS'];
    $rutaVideos2 = $resConsulta['RUTA_VIDEOS2'];
    if($alias1A==""||$alias1A==null)
    {
      $alias1A=$alias2A;
      $rutaVideos1=$rutaVideos2;
    }
    if($alias2A==""||$alias2A==null)
    {
      $alias2A=$alias1A;
      $rutaVideos2=$rutaVideos1;
    }
    $GPO_TST=$resConsulta['GRUPO_TESTIGOS'];
    $tipo_guia=$resConsulta['TIPO_GUIA'];
    guarda_tipo_guia($tipo_guia,2);
    $alias1 = obtieneAlias($alias1A, $rutaVideos1);
    $alias2 = obtieneAlias($alias2A, $rutaVideos2);
    $dirServidor = $resConsulta['DIRECCION_SERVIDOR'];
    obt_tipo_guia_1($GPO_TST,$tipo_guia,$id_tst,1);
    genera_dir_videos($fecha_,$id_tst,$alias1, $alias2, $dirServidor,$GPO_TST,$tipo_guia);
    gen_dir_videos_dia_man($fecha_,$id_tst,$alias1, $alias2, $dirServidor,$GPO_TST,$tipo_guia);
    genera_guia_reconciliada($id_tst,$fecha_,$alias1, $alias2, $dirServidor,$GPO_TST);
  }
 ?>
       </div>
      </body>
   </html>
 <?php
}
gen_pagina();
?>