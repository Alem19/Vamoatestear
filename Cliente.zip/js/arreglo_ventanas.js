/*
	Guarda los datos de los ultimos 30 testigos que el usuario ha visitado,
	el tipo de guía que seleccionó y el ultimo evento seleccionado, para
	emular la versión de escritorio del cliente testigos.
*/

function vista_testigos(){
	this.lista_testigos=[];
	this.total=0;
	this.maximo=30;

	this.agrega_vista= function (id_tst,tipo_guia,seleccionados,fecha_guia){
		this.lista_testigos[this.total]={id:id_tst,tipo:tipo_guia,seleccion:seleccionados,
                    fecha:fecha_guia};
		this.total=this.lista_testigos.length;
	}
	this.busca_vista= function (id_tst){
		var i=0;
		var index=-1;
		for(i=0;i<this.total;++i)
		{
			if(id_tst==this.lista_testigos[i]['id'])
			{
				index=i;
				i=this.total;
			}
		}
		return index;
	}
	this.actualiza_vista= function (id_tst,tipo_guia,seleccionados,fecha_guia){
		var index=this.busca_vista(id_tst);
		if(index>-1){
            if(tipo_guia!=0)
			    this.lista_testigos[index]['tipo']=tipo_guia;
            this.lista_testigos[index]['seleccion']=seleccionados;
            this.lista_testigos[index]['fecha']=fecha_guia;
		}else{
			this.agrega_vista(id_tst,2,seleccionados,fecha_guia);
		}
	}
	this.imprime_todos= function(){
		var i=0;
		var datos="";
		var obj=null;
		for(i=0;i<this.total;++i)
		{
			obj=this.lista_testigos[i];
			datos+=obj['id']+"-"+obj['tipo']+"\n";
		}
		return datos;
	}
}