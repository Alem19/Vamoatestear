	function finalCambio()
	{
		//----------		Desplazamiento de barra de avance ------------
		var posicion = document.getElementById('posicion').value;
		if(numVideos==1){
			miVideo.currentTime = ((duracionTotal/1000) * posicion)	+ inicioVideo;
		}else{
			var visual;
			if(posicion<intervaloInicial){
				cambiaA = 0;
				if(cambiaA!=videoActual)
				{
					var videoAQuitar = videoActual;
					videoActual = cambiaA;
					cambiaVideo();
					if(miVideo.readyState==0 || miVideo.readyState==1){
						miVideo.load();
					}
					visual = 1;
					procede = false;
				}else{
					visual = 0;
				}
				buscaPosicion(1, posicion, visual, true);
				quitaAnterior(videoAQuitar);
			}else{
				var porcentaje;
				if(posicion>intervaloFinal){
					cambiaA = numVideos - 1;
					if(cambiaA!=videoActual){
						var videoAQuitar = videoActual;
						videoActual = cambiaA;
						cambiaVideo();
						if(miVideo.readyState == 0 || miVideo.readyState==1){
							miVideo.load();
						}
						visual = 1;
						procede = false;
					}else{
						visual = 0;
					}
					buscaPosicion(2, posicion, visual, true);
					quitaAnterior(videoAQuitar);
				}else {
					var iniciando = intervaloInicial;
					var enMedio = intervaloMedia;
					cambiaA = Math.ceil((posicion-iniciando)/enMedio);
					cambiaA = Math.ceil((posicion-intervaloInicial)/intervaloMedia);
					if(cambiaA!=videoActual)
					{
						var videoAQuitar = videoActual;
						videoActual = cambiaA;
						cambiaVideo();
						if(miVideo.readyState==0 || miVideo.readyState==1){
							miVideo.load();
						}
						visual = 1;
						procede = false;
					}else{
						visual = 0;
					}
					buscaPosicion(3, posicion, visual, true);
					quitaAnterior(videoAQuitar);
				}
			}
		}
		banderaCargaSig=true;
		bandFinalizoVideo=false;
	}

	function quitaAnterior(quitar){
		quitaVideo(quitar);
		if((videoActual-quitar) > 1){
			var quitarMas1 = quitar + 1;
			if(quitarMas1 <numVideos)
				quitaVideo(quitarMas1);
		}
	}

	function cambiaVideo(){
		miVideo.removeEventListener('timeupdate',actualizaPosicion);
		miVideo.removeEventListener('ratechange',updateRateDisplay);

		Video1 = miVideo;
		var nombreVideoSig = 'mivideo'+videoActual;
		miVideo = document.getElementById(nombreVideoSig);

		miVideo.addEventListener('timeupdate',actualizaPosicion,true);
		miVideo.addEventListener('ratechange',updateRateDisplay,true);
		miVideo.onstalled=function(){
			//console.log('on stalled, reanuda reproduccion');
			for(var index= 0; index<numVideos; index++){
				quitaVideo(index);
			}
			miVideo.load();
			finalCambio();
			reproduce();
		};
		//---- Cambio de etiqueta de fecha
		var nuevaFecha = miVideo.src;
		nuevaFecha = nuevaFecha.substr(nuevaFecha.length-18,6);
		if(fechaPrograma!=nuevaFecha){
			document.getElementById('etiquetaFecha').innerHTML = formateaFecha(nuevaFecha);
			fechaPrograma = nuevaFecha;
		}

		var vol = document.getElementById('volumen').value;
		miVideo.volume = vol/100;
		miVideo.playbackRate = document.getElementById('speedDisplay').innerHTML;
		miVideo.currentTime = 0;
		calculaParcial();
	}

	function buscaPosicion(caso, posiciona, banderaVisual, canplay){
		if(canplay== true){
			procede = true;
		}

		if(procede){
			if(isNaN(miVideo.duration)){
				var duracionDefecto = duraVideo;
			}else{
				var duracionDefecto = miVideo.duration;
			}
			switch(caso){
				case 1:
					if(intervaloInicial == 0){
						miVideo.currentTime = (posiciona * (duracionDefecto-inicioVideo)/intervalo) + inicioVideo;
					}else{
						miVideo.currentTime = (posiciona * (duracionDefecto-inicioVideo)/intervaloInicial) + inicioVideo;
					}
					break;
				case 2:
						miVideo.currentTime = (posiciona - intervaloFinal)/(1000 - intervaloFinal) * (duracionDefecto-tiempoSobra);
					break;
				case 3:
					var porcentaje;
					if(cambiaA==1){
						porcentaje = (posiciona-intervaloInicial)/intervaloMedia;
					}else{
						porcentaje = (posiciona-intervaloInicial-(intervaloMedia * (cambiaA-1)))/intervaloMedia;
					}
					miVideo.currentTime = porcentaje * duracionDefecto;
					break;
				default:
					break;
			}
			miVideo.removeEventListener('canplay',buscaPosicion);
		}
		if(banderaVisual==1){
			Visualiza();
		}
	}

	function calculaParcial(){
		duracionParcial = 0;
		if(videoActual==0){
			duracionParcial=0;
		}else{
			for(var itera=0; itera < videoActual; itera++){
				if(itera==0){
					duracionParcial=duraVideo-inicioVideo;
				}else{
					duracionParcial = duracionParcial + duraVideo;
				}
			}
		}
	}

	function despuesCarga(){
    var ExpReg=/^\d{2}\s[A-za-z]{5,10}\s\d{4}$/;
		videoActual=0;
		duracionParcial=0;
		intervalo=0;
		cambiaManual=0;
		duracionTotal=0;
		tiempoTVideos = 0;
		siguienteVideo = 1;
    banderaPausaGral=false;
		banderaReproduce = true;
		bandFinalizoVideo = false;
		banderaCargaSig=true;
		ejecuta = null;
		procede = true;
		varSalida=0;
		varEntrada=0;
		mes = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
    	fechaPrograma = formateaFecha(fechaPrograma1);
		miVideo = document.getElementById('mivideo0');
		posicion = document.getElementById('posicion');
		numVideos = totalElementos;
		duracionTotal = duracionVideo;
		inicioVideo =Math.round((inicioVideo1*100000))/100000;
		horaDelDia = parseInt(inicioPrograma);
		document.getElementById('speedDisplay').innerHTML = 1;
    document.getElementById('etiquetaFecha').innerHTML = (ExpReg.test(fechaPrograma))?fechaPrograma:"Sin fecha";
		miVideo.addEventListener('timeupdate',actualizaPosicion,true);
		miVideo.addEventListener('ratechange',updateRateDisplay,true);
		miVideo.addEventListener('canplay',corrigeInicio,true);
		posicion.addEventListener('mousedown',inicioCambio,true);
		posicion.addEventListener('mouseup',reanuda,true);
		posicion.addEventListener('click',posicionClick,true);
		verificacion = setTimeout(cargaInicial(), 1600);			// ****************
	}

	function cargaInicial(){
		if(miVideo.readyState== 0 || miVideo.readyState== 1){
			miVideo.load();
		}
	}

	function posicionClick(){
		horaNueva();
		reanuda();
        return true;
	}
	function reanuda(){
		cambiaManual=0;
		reproduce();
        return true;
	}

	function leemetadatos(){
		//--------------	Duraci�n lista de videos	----------------
    duraVideo = miVideo.duration;
		if(tiempoTVideos==0){
			noLeidos=0;
			for(var itera=0; itera < numVideos; itera++)
			{
				var nombreVideo = 'mivideo'+ itera;
				var videoDatos = document.getElementById(nombreVideo);
				if(isNaN(videoDatos.duration)){
					noLeidos = noLeidos + 1;
				}else{
					tiempoTVideos = tiempoTVideos + videoDatos.duration;
				}
			}
			if(noLeidos > 0)
			{
				tiempoTVideos = duraVideo * numVideos;
			}
		}
		if(duracionTotal==0){
			duracionTotal=tiempoTVideos;
		}
		var pctj = (miVideo.duration-inicioVideo)/duracionTotal;
		intervaloInicial = 1000*pctj;
		intervalo = 1000/numVideos;

		var numero = numVideos-1;
		var nombreVideo = 'mivideo'+ numero;
		videoDatosUlt = document.getElementById(nombreVideo);
		videoDatosUlt.load();
		if(isNaN(videoDatosUlt.duration)){
			duracionUltVideo = duraVideo;
		}else{
			duracionUltVideo = videoDatosUlt.duration;
		}
		var nomTemp = videoDatosUlt.src;
		videoDatosUlt.src = '';
		videoDatosUlt.load();
		videoDatosUlt.src = nomTemp;

		tiempoSobra = tiempoTVideos - duracionTotal - inicioVideo;
		var cociente = (duracionUltVideo-tiempoSobra)/duracionTotal;
		intervaloFinal = 1000 - (1000 * cociente);

		intervaloMedia = intervalo + (((intervalo - intervaloInicial) + (intervalo - (1000 * cociente))) / (numVideos-2));

		document.getElementById('totalHr').innerHTML = formateaHora(duracionTotal);
		document.getElementById('horaHr').innerHTML = formateaHora(horaDelDia);
		document.getElementById('etiquetaHora').innerHTML = formateaHora(horaDelDia);
		document.getElementById('posicionHr').innerHTML = formateaHora(0);

		var VentanaPrincipal = window.parent;
    miVideo.volume = VentanaPrincipal.regresa_volumen();
		document.getElementById('vol').innerHTML =(isNaN(miVideo.volume * 100))?50:Math.round(miVideo.volume * 100);
		document.getElementById('volumen').value =(isNaN(miVideo.volume * 100))?50:(miVideo.volume * 100);
		reproduce();
	}

	function actualizaPosicion()
	{
		banderaReproduce = true;
		if(videoActual==0){
			var segundos = miVideo.currentTime+duracionParcial-inicioVideo;
      if(segundos<0)
        segundos=0;
		}
		else{
			var segundos = miVideo.currentTime+duracionParcial;
		}
		document.getElementById('posicionHr').innerHTML = formateaHora(segundos);
		var horaActual = horaDelDia + segundos;
		document.getElementById('etiquetaHora').innerHTML = formateaHora(horaActual);
		document.getElementById('horaHr').innerHTML = formateaHora(horaActual);

		if(cambiaManual==0)
		{
			document.getElementById('posicion').value= (1000/duracionTotal)*(segundos);
		}
		if(segundos >= duracionTotal){
			banderaReproduce = false;
			pausa();
		}

		if(bandFinalizoVideo){
      try{
        if(numVideos>1)
        {
			    if(Video1.currentTime.toFixed(2)<(Video1.duration).toFixed(2)+0.1 ||
              Video1.currentTime.toFixed(2)>(Video1.duration).toFixed(2)-0.2){
				    Visualiza();
          }
        }
      }catch(err){
                //console.log(err.message);
      }
		}

		if(miVideo.currentTime.toFixed(2)>=((miVideo.duration).toFixed(2)-0.2))
		{
			if(!bandFinalizoVideo){
				finalizaVideo();
				bandFinalizoVideo=true;
				banderaCargaSig=true;
			}
		}

		if(miVideo.currentTime>=(miVideo.duration*0.5)){
			if(banderaCargaSig){
				banderaCargaSig=false;
				agregaUno(siguienteVideo);
				var anterior = videoActual - 1;
				if(anterior>=0){
					quitaVideo(anterior);
				}
			}
		}
        return true;
	}

	function desactFecha(){
		var etiquetaFecha = document.getElementById('etiquetaFecha');
		if(etiquetaFecha.style.visibility == 'visible' || etiquetaFecha.style.visibility == '')
		{
			etiquetaFecha.style.visibility = 'hidden';
			document.getElementById('btnDesactFecha').innerHTML = "Muestra Fecha";
		}
		else
		{
			etiquetaFecha.style.visibility = 'visible';
			document.getElementById('btnDesactFecha').innerHTML = "Oculta Fecha";
		}
	}

	function desactHora(){
		var etiquetaHora = document.getElementById('etiquetaHora');
		if(etiquetaHora.style.visibility == 'visible' || etiquetaHora.style.visibility == '')
		{
			etiquetaHora.style.visibility = 'hidden';
			document.getElementById('btnDesactHora').innerHTML = "Muestra Hora";
		}
		else
		{
			etiquetaHora.style.visibility = 'visible';
			document.getElementById('btnDesactHora').innerHTML = "Oculta Hora";
		}
	}
	function cargaSiguiente(){
		if(numVideos<=7){
			var cargaVideos=numVideos;
		}
		else{
			var cargaVideos = 3;
		}
		for(siguienteVideo=1; siguienteVideo < cargaVideos; siguienteVideo++){
			var nomSigVideo = 'mivideo' + siguienteVideo;
			cargaVideo = document.getElementById(nomSigVideo);
			cargaVideo.load();
			cargaVideo.currentTime=0;
		}
		siguienteVideo = siguienteVideo + 1;
	}

	function agregaUno(videoSig){
		if(videoSig < numVideos){ //  && (videoSig > 3)
			var nomSigVideo = 'mivideo' + videoSig;
			cargaVideo = document.getElementById(nomSigVideo);
			cargaVideo.load();
			siguienteVideo = videoSig + 1;
			cargaVideo.currentTime = 0;
		}
	}

	function quitaVideo(videoAnterior){
		if(videoAnterior>0){  // && videoAnterior <= (videoActual-2)
			var nomVideoElimina = 'mivideo' + videoAnterior;
			var videoElimina = document.getElementById(nomVideoElimina);
			var nomTemp = videoElimina.src;
			videoElimina.src = '';
			videoElimina.load();
			videoElimina.src = nomTemp;
		}
	}

	function finalizaVideo(){
		if((videoActual+1)==numVideos)
		{
			banderaReproduce = false;
			miVideo.pause();
		}
		else
		{
			banderaReproduce = false;
			videoActual=videoActual+1;
			cambiaVideo();
			miVideo.currentTime = 0;
      if(!banderaPausaGral)
      {
        banderaReproduce = true;
        miVideo.play();
      }
		}
	}

	function VelNormal(){
		miVideo.playbackRate = 1;
	}

	function IncVel(){
		if(miVideo.playbackRate < 2){
			miVideo.playbackRate = (miVideo.playbackRate + 0.25).toFixed(2);
		}
		else
		{
			if(miVideo.playbackRate >= 2)
			{
				if(miVideo.playbackRate < 16)
				{
					miVideo.playbackRate = (miVideo.playbackRate * 2).toFixed(0);
				}
			}
		}
	}

	function DecVel(){
		if(miVideo.playbackRate <= 2){
			if(miVideo.playbackRate > 0.25){
			    miVideo.playbackRate = (miVideo.playbackRate - 0.25).toFixed(2);
			}
		}else{
		    miVideo.playbackRate = (miVideo.playbackRate / 2).toFixed(0);
		}
	}

	function Rebobina(){
		cambiaA = 0;
		pausa();
		if(cambiaA!=videoActual)
		{
			videoActual = cambiaA;
			cambiaVideo();
			Visualiza();
		}
		miVideo.currentTime = inicioVideo;
	}

	function inicioCambio()
	{
		miVideo.pause();
		cambiaManual=1;
        return true;
	}
	function formateaHora(tiempoSeg){
    if(isNaN(tiempoSeg))
            tiempoSeg=0;
		var horaMs =Math.abs(((((tiempoSeg - Math.floor(tiempoSeg))/0.03334).toString().slice(0,2)).replace(".", " ")).trim());
		var cadena1 = horaMs.toString();
		if(cadena1.length == 1){
			cadena11 = ":0" + cadena1;
		}else{
			cadena11 = ":" + cadena1;
		}
		var horaSg = Math.floor(tiempoSeg)%60;
		var cadena2 = horaSg.toString();
		if(cadena2.length == 1){
			cadena21 = ":0" + cadena2;
		}else{
			cadena21 = ":" + cadena2;
		}
		var horaMn = (Math.floor(tiempoSeg/60)%60).toFixed(0);
		var cadena3 = horaMn.toString();
		if(cadena3.length == 1){
			cadena31 = ":0" + cadena3;
		}else{
			cadena31 = ":" + cadena3;
		}
		var horaHr = Math.floor(tiempoSeg/3600);
		horaHr = horaHr%24;
		var cadena4 = horaHr.toString();
		if(cadena4.length == 1){
			cadena41 = "0" + cadena4;
		}else{
			cadena41 = "" + cadena4;
		}
		return cadena41 + cadena31 + cadena21 + cadena11;
	}

	function formateaFecha(fechaCruda){
    if(isNaN(fechaCruda))
      fechaCruda="010115";
		var dia = fechaCruda.substr(0,2);
		var indice = parseInt(fechaCruda.substr(2,2)) - 1;
		var anio = "20" + fechaCruda.substr(4,2);
		return dia + " " + mes[indice] + " " + anio;
	}

	function controlaVol(){
		var vol = document.getElementById('volumen').value;
    if(isNaN(vol))
      vol=50;
    var aux_vol=vol/100;
		miVideo.volume = aux_vol;
    document.getElementById('vol').innerHTML =(isNaN(vol))?50:Math.round(vol);
		var VentanaPrincipal = window.parent;
    VentanaPrincipal.guarda_volumen(miVideo.volume);
	}

	function corrigeInicio(){
		leemetadatos();
		miVideo.currentTime = inicioVideo;
		miVideo.removeEventListener('canplay',corrigeInicio,true);
        return true;
	}

	function Visualiza(){
		miVideo.style.visibility='visible';
		Video1.style.visibility='hidden';
		bandFinalizoVideo=false;
	}

	function puedeReproducir(){
		if(miVideo.readyState == 0 || miVideo.readyState == 1){
			var indice = videoActual - 1;
			miVideo.load();
			finalCambio();
			reproduce();
		}
	}
	function updateTimeDisplay(e){
		document.getElementById('muestraHora').innerHTML = (e.target.currentTime).toFixed(3);
	}

	function updateRateDisplay(e){
		document.getElementById('speedDisplay').innerHTML = e.target.playbackRate;
        return true;
	}

	function reproduce(){
		if(miVideo.paused==true){
			if(banderaReproduce){
			  miVideo.play();
			}
		}
		else{
		//	pausa();
		}
	}
    function reproduce1(){
      if(miVideo.paused==true){
        banderaReproduce=true;
        banderaPausaGral=false;
        miVideo.play();
		  }else{
        banderaReproduce=false;
        banderaPausaGral=true;
			  pausa();
		  }
    }
	function pausa(){
		miVideo.pause();
	}
	function AvanzaCuadro(){
		if(banderaReproduce){
			miVideo.pause();
			miVideo.currentTime += 0.03333;
		}
	}

	function RegresaCuadro(){
		miVideo.pause();
		miVideo.currentTime -= 0.03333;
	}

	function horaNueva(){
		finalCambio();
		var cocientes = posicion.value / 1000;
		var segs = duracionTotal * cocientes;
		var horaActual = horaDelDia + segs;
        return true;
	}

	function actualizaHora(){
		posicion.addEventListener('input', horaNueva, true);
	}

	function remueveEventoRango(){
		posicion.removeEventListener('input', horaNueva, true);
	}

	function irAlFinal(){
		cambiaA = numVideos - 1;
		pausa();
		if(cambiaA!=videoActual)
		{
			videoActual = cambiaA;
			cambiaVideo();
			miVideo.load();
			Visualiza();
		}
    if(TipoGuia==1)
		  miVideo.currentTime = duraVideo;
    else{
      document.getElementById('posicion').value=1000;
      finalCambio();
    }
	}

	function pantallaCompleta(){
	    var nav = navigator.userAgent.toLowerCase();

		//buscamos dentro de la cadena mediante indexOf() el identificador del navegador
		if(nav.indexOf("firefox") != -1 || nav.indexOf("opera") != -1){
		    miVideo.mozRequestFullScreen();
					//document.mozCancelFullScreen();
		}else if(nav.indexOf("chrome") != -1){
		    miVideo.webkitEnterFullScreen();
					//miVideo.webkitRequestFullscreen();
			miVideo.webkitExitFullscreen();
		}else {
		    alert("No es posible completar la solicitud");
		}
	}

	function salirPantallaCompleta(){
		if (document.exitFullscreen) {
			document.exitFullscreen();
		 } else if (document.msExitFullscreen) {
			document.msExitFullscreen();
		 } else if (document.mozCancelFullScreen) {
			document.mozCancelFullScreen();
		 } else if (document.webkitExitFullscreen) {
			document.webkitExitFullscreen();
		 }
	 }

	function calcHoraActual(){
		if(videoActual==0){
			var segundos = miVideo.currentTime+duracionParcial-inicioVideo;
		}
		else{
			var segundos = miVideo.currentTime+duracionParcial;
		}
		var horaActual = horaDelDia + segundos;
		return horaActual;
	}

	function capturaEntrada(){
		varEntrada = calcHoraActual();
    var duracion=varSalida - varEntrada;
		document.getElementById('entrada').innerHTML = formateaHora(varEntrada);
    if(varSalida!=0)
    {
      if( duracion < 1)
		    document.getElementById('duracion').innerHTML = formateaHora(0);
      else
        document.getElementById('duracion').innerHTML = formateaHora(duracion);
    }
	}

	function capturaSalida(){
		varSalida = calcHoraActual();
		if(varSalida <= varEntrada){
			alert("La hora de salida debe ser mayor que la de entrada");
		}else{
			document.getElementById('salida').innerHTML = formateaHora(varSalida);
			var duracion = varSalida - varEntrada;
			if( duracion > 0)
			{
				document.getElementById('duracion').innerHTML = formateaHora(duracion);
			}
		}
	}

	function exportaSel(){
		if(varEntrada >= varSalida){
			alert("La hora de entrada debe ser menor que la de salida");
		}
		else{
			var nombre = prompt("Guardar como ");
			if(nombre != null){
				if(nombre == ""){
					nombre = "video";
				}
				var VentanaPrincipal = window.parent;
				var HrFormatoInicia = formateaHora(varEntrada);
				var HrInicia = VentanaPrincipal.obt_hor_cua(HrFormatoInicia);
				var HrFormatoTermina = formateaHora(varSalida);
				var HrTermina = VentanaPrincipal.obt_hor_cua(HrFormatoTermina);
				VentanaPrincipal.exporta_rango(HrInicia, HrTermina, nombre);
                document.getElementById('salida').innerHTML = formateaHora(0);
                document.getElementById('entrada').innerHTML = formateaHora(0);
                document.getElementById('duracion').innerHTML = formateaHora(0);
			}
		}
	}
