<?php
  require_once("bitacora.php");
  require_once("utilerias.php");
  require_once("manejo_bd.php");
//---------------------------------------------------------------------------
  function genera_id_peticion()
  {
    $resultado=null;
    $cursor=null;
    $conexion=null;
    $error="";
    $max_id=0;
    $fecha=date("d/m/Y");
    $query="SELECT MAX(ID) FROM CORTES_TESTIGO_WEB "
          ."WHERE FECHA_PETICION BETWEEN TO_DATE('".$fecha."', 'DD/MM/YYYY') AND "
          ."TO_DATE('".$fecha." 23:59:59', 'DD/MM/YYYY HH24:MI:SS')";
    $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$error);
    if($conexion!==false)
    {
      $cursor=parse_bd($conexion,$query,$error);
      if($cursor!==false)
      {
        $resultado=ejecuta_select($cursor,$error);
      }
    }
    if(is_array($resultado))
    {
      if(count($resultado)==2){
        $texto="Error al obtener ID petici�n : C�digo ".$resultado[0].": ".$resultado[1]['message'];
        Bitacora($texto,0);
      }else{
        if(!isset($resultado[0]['MAX(ID)']) || $resultado[0]['MAX(ID)']=="")
        {
          $max_id=date("ymd").ajuste("1",6);
        }else
          $max_id=$resultado[0]['MAX(ID)']+1;
      }
    }else{
      $texto="Error al obtener ID MAX ".$query;
      Bitacora($texto,0);
    }
    libera_bd($conexion,$cursor);
    return $max_id;
  }
//---------------------------------------------------------------------------
  function agrega_peticion($id_tst,$fecha_vid,$hora_ini,$dur_ms,$nombre,&$id_exportacion)
  {
    date_default_timezone_set('America/Mexico_City');
    $exito=0;
    $fe1=explode("_",$fecha_vid);
    $fech=$fe1[1]."/".$fe1[0]."/".$fe1[2];
    $a=strtotime($fech);
    $fecha_borland=fecha_borland2($a);
    $fecha=date("d/m/Y")." ".date("H:i:s");
    $id=genera_id_peticion();
    if($id!==0)
    {
      $query="INSERT INTO CORTES_TESTIGO_WEB "
          ."(ID,ID_TESTIGO,FECHA_VIDEO,HORA_INI_CORTE,DURACION_CORTE,NOMBRE_EXPORTA,FECHA_PETICION) "
          ."VALUES(".$id.",".$id_tst.",".$fecha_borland.",".$hora_ini.",".$dur_ms
          .",'".$nombre."',TO_DATE('".$fecha."','DD/MM/YYYY HH24:MI:SS'))";
      Bitacora($query,0);
      try{
        $conn = oci_connect(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,'AL32UTF8');
        $stid = oci_parse($conn,$query);
        $fila =oci_execute($stid);
        oci_free_statement($stid);
        oci_close($conn);
        $id_exportacion=$id;
        $exito=1;
      }catch(Exception $e){
        $texto="ERROR: Al insertar petici�n en BD: ".$e[1]=$e.Message;
        Bitacora($texto,0);
      }
    }else{
      $texto="ERROR: Al generar ID del corte ";
      Bitacora($texto,0);
    }
    return $exito;
  }
//---------------------------------------------------------------------------
  if(isset($_POST['ruta']) && isset($_POST['name']))
  {
    $rutas=$_POST['ruta'];
    $nombre=$_POST['name'];
    $modoSap=$_POST['modoSap'];
    $id_tst=0;
    $fecha=0;
    $hora_ini=0;
    $dur_ms=0;
    $id_exportacion=0;
    $datos=explode("-",$rutas);
    if(count($datos)==4)
    {
      $id_tst=(is_numeric($datos[0]))?$datos[0]:0;
      $modoSap=(is_numeric($modoSap))?$modoSap:0;
      if($modoSap)
      {
        $id_tst=$modoSap;
      }
      $hora_ini=(is_numeric($datos[1]))?$datos[1]:0;
      $fecha=$datos[2];
      $dur_ms=(is_numeric($datos[3]))?$datos[3]:0;
      if(agrega_peticion($id_tst,$fecha,$hora_ini,$dur_ms,$nombre,$id_exportacion))
        echo $id_exportacion;
      else
        echo 0;
    }else
      echo 0;
  }
//---------------------------------------------------------------------------

?>
