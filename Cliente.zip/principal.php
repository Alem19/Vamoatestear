<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT"); // Date in the past
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Pragma: no-cache");
clearstatcache();
require_once("utilerias.php");
require_once("manejo_bd.php");
require_once("manejo_guia.php");
require_once("bitacora.php");
//---------------------------------------------------------------------------
function genera_codigo_menu($nombre,$id_tst,$grupo,$iter,&$cadena1,&$codigo1)
{
  $cadena="";
  $codigo="";
  switch ($grupo)
  {
    case GRUPO_TESTIGOS_LOCALES_A7:
      $cadena="   Locales 7 /";
      $codigo='<li id="LA7" name="G2"><a >Locales 7</a>
                <div class="dropdown_2columns" style="overflow: scroll; height:150px; ">
                 <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_LOCALES_A13:
      $cadena="   Locales 13 /";
      $codigo='<li id="LA13" name="G5"><a >Locales 13</a>
                <div class="dropdown_2columns" style="overflow: scroll; height:150px; ">
                 <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_HD:
      $cadena="   Locales 40 /";
      $codigo='<li id="LA40" name="G6"><a >Locales 40</a>
                  <div class="dropdown_2columns" style="overflow: scroll; height:150px; ">
                    <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_LOS_ANGELES:
      $cadena="   Otras Se&ntilde;ales L.A. /";
      $codigo='<li id="LAng" name="G3"><a >Otras L.A.</a>
                <div class="dropdown_1column">
                 <div class="col_1">';
    break;
    case GRUPO_TESTIGOS_OTROS_DF:
      $cadena="   Otras Se&ntilde;ales D. F. /";
      $codigo='<li id="OSDF" name="G17"><a >Otras D. F.</a>
                <div class="dropdown_1column">
                 <div class="col_1">
                  <div id="271" class="black_box selectable" '
                  .'onclick="ev_clic(id,\'   Otras Se&ntilde;ales D. F. / Canal 3.1   \',17)">'
                  .'Canal 3.1</div>';
    break;
    case GRUPO_TESTIGOS_TV_PAGA:
      $cadena="   TV de paga /";
      $codigo='<li id="TVPaga" name="G19"><a >TV de Paga</a>
                <div class="dropdown_2columns" style="overflow: scroll; height:150px; ">
                 <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_TX_13:
      $cadena="  Transmisores 13 /";
      $codigo='<li id="LA13TX" name="G5"><a >Transmisores 13</a>
                <div class="dropdown_2columns" style="overflow-y: scroll; height:150px; ">
                 <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_TX_7:
      $cadena="   Transmisores 7 /";
      $codigo='<li id="LA7TX" name="G2"><a >Transmisores 7</a>
                <div class="dropdown_2columns" style="overflow-y: scroll; height:150px; ">
                 <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_CABLE_7:
      $cadena="   Cablera 7 /";
      $codigo='<li id="TVC7" name="G21"><a >Cablera 7</a>
                <div class="dropdown_2columns" style="overflow-y: scroll; height:150px; ">
                  <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_CABLE_13:
      $cadena="   Cablera 13 /";
      $codigo='<li id="TVC13" name="G22"><a >Cablera 13</a>
                <div class="dropdown_2columns" style="overflow-y: scroll; height:150px; ">
                  <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_MUX_1:
      $cadena="Multiplexados 1 /";
      $codigo='<li id="TMUX1" name="G25"><a >Multiplexados 1</a>
                <div class="dropdown_2columns" style="overflow-y: scroll; height:150px; ">
                  <div class="col_2">';
    break;
    case GRUPO_TESTIGOS_MUX_7:
      $cadena="Multiplexados 7 /";
      $codigo='<li id="TMUX7" name="G26"><a >Multiplexados 7</a>
                <div class="dropdown_2columns" style="overflow-y: scroll; height:150px; ">
                  <div class="col_2">';
    break;
  }
  $cadena1=$cadena;
  $codigo1=$codigo;
}
//------------------------------------------------------------------------------
function crea_menu_testigos(&$AztecaAme,$TelevisaDF,$TVP,$nac_df,$centro)
{
  $loc7="";
  $loc13="";
  $loc40="";
  $LA="";
  $Otras="";
  $loc7TX="";
  $loc13TX="";
  $TVC7="";
  $TVC13="";
  $MUX1="";
  $MUX7="";
  $cadena="";
  $codmenu="";
  $nacionales="";
  $handler="";
  $cursor=null;
  $error="";
  $grupo_ant=0;
  $grupo_act=0;
  $query="SELECT NOMBRE_TESTIGO, ID_TESTIGO, GRUPO_TESTIGOS"
        ." FROM TESTIGOS.LISTA_TESTIGOS"
        ." WHERE GRUPO_TESTIGOS=2 OR GRUPO_TESTIGOS=3 OR GRUPO_TESTIGOS=5 OR GRUPO_TESTIGOS=6"
        ." OR GRUPO_TESTIGOS=17 OR GRUPO_TESTIGOS=19 ORDER BY GRUPO_TESTIGOS, NOMBRE_TESTIGO";
  $handler=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$error);
  if($handler!==false)
  {
    $cursor=parse_bd($handler,$query,$error);
    if($cursor!==false)
    {
      $resultado=ejecuta_select($cursor,$error);
    }
  }
  if(is_array($resultado))
  {
    $aux=$resultado[0];
    if(is_numeric($aux)===false)
    {
      $cadena="";
      $testigo_n="";
      for($i=0;$i<count($resultado);++$i)
      {
        $grupo_act=$resultado[$i]['GRUPO_TESTIGOS'];
        $nombre=$resultado[$i]['NOMBRE_TESTIGO'];
        $id_tst=$resultado[$i]['ID_TESTIGO'];
        if($grupo_act!=$grupo_ant)
        {
          if($i!==0)
          {
            $fin='</div>
              </div>
            </li>';
            switch($grupo_ant)
            {
              case GRUPO_TESTIGOS_LOCALES_A7:
                $loc7=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_LOCALES_A13:
                $loc13=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_HD:
                $loc40=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_LOS_ANGELES:
                $AztecaAme.=$fin;
                $LA.=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_OTROS_DF:
                $Otras=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_INTERNAC:
              break;
              case GRUPO_TESTIGOS_TV_PAGA:
                $TVP=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_TX_7:
                $TVC7=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_TX_13:
                $TVC13=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_CABLE_7:
                $TVC7=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_CABLE_13:
                $TVC13=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_MUX_1:
                $MUX1=$codmenu.$fin;
              break;
              case GRUPO_TESTIGOS_MUX_7:
                $MUX7=$codmenu.$fin;
              break;
            }
          }
          genera_codigo_menu($nombre,$id_tst,$grupo_act,$i,$cadena,$codmenu);
        }
        if(($grupo_act ==5 || $grupo_act ==2 || $grupo_act ==17) && (strpos($nombre,"-")!==false)){
          $n=substr($nombre,0,strpos($nombre,"-"));
        }else{
          $n=$nombre;
        }
        if($grupo_act == 2 || $grupo_act == 5){
          if($id_tst==79 || $id_tst==78 || $id_tst==81 || $id_tst==80 || $id_tst==55 || $id_tst==54 || $id_tst==83 || $id_tst==82 || $id_tst==71
            || $id_tst==72 || $id_tst==85 || $id_tst==84 || $id_tst==110 || $id_tst==87 || $id_tst==86 || $id_tst==57 || $id_tst==56 || $id_tst==47
            || $id_tst==46 || $id_tst==75 || $id_tst==74 || $id_tst==89 || $id_tst==88 || $id_tst==90 || $id_tst==40 || $id_tst==41 || $id_tst==63
            || $id_tst==62 || $id_tst==92 || $id_tst==45 || $id_tst==44 || $id_tst==95 || $id_tst==94 || $id_tst==97 || $id_tst==96 || $id_tst==98
            || $id_tst==225 || $id_tst==226 || $id_tst==32 || $id_tst==31 || $id_tst==34 || $id_tst==33 || $id_tst==36 || $id_tst==35 || $id_tst==68
            || $id_tst==67 || $id_tst==59 || $id_tst==58 || $id_tst==61 || $id_tst==60 || $id_tst==132 || $id_tst==38 || $id_tst==37 || $id_tst==53
            || $id_tst==52 || $id_tst==77 || $id_tst==76 || $id_tst==49 || $id_tst==48 || $id_tst==66 || $id_tst==65 || $id_tst==51 || $id_tst==50
            || $id_tst==26 || $id_tst==39 || $id_tst==64 || $id_tst==91 || $id_tst==93 || $id_tst==99 || $id_tst==601 || $id_tst==602){
            $testigo_n=$cadena." ".$n."   ";
            $cod='<div id="'.$id_tst.'" class="black_box selectable" onclick="ev_clic(id,\''.$testigo_n.'\','.$grupo_act.')">'.$nombre.'</div>';
            $codmenu.=$cod;
          }else{}
        }else if($grupo_act==6)
        {
          if($id_tst!=218 && $id_tst!=207 && $id_tst!=220 && $id_tst!=211 && $id_tst!=219 && $id_tst!=203 && $id_tst!=257
             && $id_tst!=258)
          {
            $n=str_replace("HD","",$n);
            $n=str_replace("40","",$n);
            $testigo_n=$cadena." ".$n."   ";
            $nombre=str_replace("HD","",$nombre);
            $cod='<div id="'.$id_tst.'" class="black_box selectable" onclick="ev_clic(id,\''.$testigo_n.'\','.$grupo_act.')">'.$nombre.'</div>';
            $codmenu.=$cod;
          }
        }else if($grupo_act==17){
          if($id_tst==17 || $id_tst==271 || $id_tst==699 || $id_tst==246)
          {
          }else{
            $testigo_n=$cadena." ".$n."   ";
            $nombre=str_replace("- DF","",$nombre);
            $cod='<div id="'.$id_tst.'" class="black_box selectable" onclick="ev_clic(id,\''.$testigo_n.'\','.$grupo_act.')">'.$nombre.'</div>';
            $codmenu.=$cod;
          }
        }else{
          if($grupo_act==3)
          {
            if($id_tst!=21 && $id_tst!=22 && $id_tst!=23 && $id_tst!=24 && $grupo_act==3)
              $testigo_n="   AA /"." ".$n."   ";
            else
              $testigo_n=$cadena." ".$n."   ";
            $cod='<div id="'.$id_tst.'" class="black_box selectable" onclick="ev_clic(id,\''.$testigo_n.'\','.$grupo_act.')">'.$nombre.'</div>';
            if($id_tst==21||$id_tst==22||$id_tst==23||$id_tst==24)
              $codmenu.=$cod;
            else
              $AztecaAme.=$cod;
          }else
            $codmenu.=$cod;
        }
        $grupo_ant=$grupo_act;
      }
    }else{
      $texto="Error al generar Menu Testigos: Código ".$resultado[0].": ".$resultado[1];
      Bitacora($texto,0);
    }
  }else{
    $texto="Error al generar Menu Testigos: ".$resultado;
    Bitacora($texto,0);
  }
  echo $nac_df;
  echo $loc7;
  echo $loc13;
  echo $loc40;
  echo $AztecaAme;
  echo $LA;
  echo $TVP;
  echo $TelevisaDF;
  echo $Otras;
  echo $centro;
  echo '</div>
        </div>
      </li>';
  libera_bd($handler,$cursor);
}
//------------------------------------------------------------------------------
function crea_menu()
{
  $AztecaAme='<li id="AA" name="G3"><a >Azteca Am&eacuterica</a>
                <div class="dropdown_2columns" style="overflow: scroll; height:150px; ">
                 <div class="col_2">
                  <div id="214" class="black_box selectable" onclick="ev_clic(id,\'\',0)">AA Este HD-Nacional</div>
                  <div id="215" class="black_box selectable" onclick="ev_clic(id,\'\',0)">AA Pacifico HD-Nacional</div>';
  $TelevisaDF='<li id="TV" name="G4"><a >Televisa D.F.</a>
                <div class="dropdown_1column">
                 <div class="col_1">
                  <div id="C2TV" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Canal 2 </div>
                  <div id="C4TV" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Canal 4 </div>
                  <div id="C5TV" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Canal 5 </div>
                  <div id="C9TV" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Canal 9 </div>
                 </div>
                </div>
              </li>';
  $TVP='<li id="TVPaga" name="G19"><a >TV de Paga</a>
              <div class="dropdown_2columns" style="overflow: scroll; height:150px; ">
                <div class="col_2">
                  <div id="855" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / AZCinema HD   \',19)">AZCinema HD</div>
                  <div id="850" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / AZClick HD   \',19)">AZClick HD</div>
                  <div id="852" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / AZCoraz&oacuten HD   \',19)">AZCoraz&oacuten HD</div>
                  <div id="851" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / AZMundo HD   \',19)">AZMundo HD</div>
                  <div id="516" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / Azteca Noticias 7.2   \',19)">Azteca Noticias 7.2</div>
                  <div id="548" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / Sky - Azteca 13   -1   \',19)">Sky - Azteca 13   -1</div>
                  <div id="570" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / Sky - Azteca 13   -2   \',19)">Sky - Azteca 13   -2</div>
                  <div id="856" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / Total Play - Azteca 13  -1 HD   \',19)">Total Play - Azteca 13  -1 HD</div>
                  <div id="857" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / Total Play - Azteca 13  -2 HD   \',19)">Total Play - Azteca 13  -2 HD</div>
                  <div id="853" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / AZClick HD Nacional   \',19)">AZClick HD Nacional</div>
                  <div id="854" class="black_box selectable" onclick="ev_clic(id,\'   TV de paga / AZCoraz&oacuten HD Nacional   \',19)">AZCoraz&oacuten HD Nacional</div>
                </div>
              </div>
            </li>';
  echo ' <ul id="menu">';
  $nac_df='<li id="AN" name="GN"><a>Azteca Nacional</a>
                <div class="dropdown_3columns">
                 <div class="col_3">
                  <div id="203" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Azteca 7 HD </div>
                  <div id="207" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Azteca 13 HD </div>
                  <div id="211" class="black_box selectable" onclick="ev_clic(id,\'\',0)">ADN 40 HD </div>
                  <div id="475" class="black_box selectable" onclick="ev_clic(id,\'   Azteca Nacional / A+ HD   \',0)">A+ HD </div>
                  <div id="274" class="black_box selectable" onclick="ev_clic(id,\'   Azteca Nacional / Azteca 7 Intercom   \',0)">Azteca 7 HD Intercom </div>
                  <div id="273" class="black_box selectable" onclick="ev_clic(id,\'  Azteca Nacional / Azteca 13 Intercom  \',0)">Azteca 13 HD Intercom </div>
                  <div id="277" class="black_box selectable" onclick="ev_clic(id,\'Azteca Nacional / Proyecto 40 Intercom\',0)">Proyecto 40 HD Intercom </div>
                 </div>
                </div>
              </li>
              <li id="ADF" name="GDF"><a >Azteca D.F</a>
                <div class="dropdown_3columns">
                 <div class="col_3">
                  <div id="A7HD" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Azteca 7 HD </div>
                  <div id="A13HD" class="black_box selectable" onclick="ev_clic(id,\'\',0)">Azteca 13 HD </div>
                  <div id="P40" class="black_box selectable" onclick="ev_clic(id,\'\',0)">ADN 40 HD </div>
                  <div id="699" class="black_box selectable" onclick="ev_clic(id,\'Azteca D.F./ Azteca 13 -1\',0)">Azteca 13 -1 </div>
                  <div id="246" class="black_box selectable" onclick="ev_clic(id,\'Azteca D.F./ Azteca 13 -2\',0)">Azteca 13 -2 </div>
                 </div>
                </div>
              </li>';
  $centro='<li id="GSA" name="GSA"><a>Centroam&eacuterica</a>
                <div class="dropdown_2columns">
                  <div class="col_2">
                    <div id="350" class="black_box selectable" onclick="ev_clic(id,\'Guatemala - Azteca31\',0)">Guatemala - Azteca31</div>
                    <div id="351" class="black_box selectable" onclick="ev_clic(id,\'Guatemala - Azteca35\',0)">Guatemala - Azteca35</div>
                    <div id="352" class="black_box selectable" onclick="ev_clic(id,\'Honduras\',0)">Honduras</div>
                  </div>
                </div>
              </li>';
  crea_menu_testigos($AztecaAme,$TelevisaDF,$TVP,$nac_df,$centro);
  echo '</ul>';
}
//------------------------------------------------------------------------------
?>
<!DOCTYPE html lang="es">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>CLIENTE TESTIGOS WEB</title>
    <style>
      *{/* Universal reset: */
	        margin:0;
	        padding:0;
      }
      body{
        background:Silver;
	      font-family:Arial, Helvetica, sans-serif;
	      line-height:21px;
	      text-align:left;
      }
      .selectable{
        cursor: pointer;
      }
      .selected{
      }
    </style>
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/Cliente.css">
    <link type="text/css" rel="stylesheet" href="css/glDatePicker.darkneon.css">
    <script src="js/arreglo_ventanas.js"></script>
    <script src="js/Encripcion.js"></script>
    <script type="text/javascript" chartset="UTF-8">
      var Calendario=null;
      var expira_sesion=null;
      var fecha_cargada="";
      var fecha_actual_general=new Date();
      var seleccionado="";
      var ventana=null;
      var inicio_pag=0;
      var lastItem;
      var drag_=0;
      var carga_lista=0;
      var px=0, py=0;
      var forma_guia_actual=0;
      var ev_seleccionado_guia="0";
      var ev_actual=0;
      var cola_exportacion=[];
      var ocupado=0;
      var ID_A7_NAC="217";
      var ID_A13_NAC="216";
      var ID_PROY40="220";
      var ID_A7_HD="219";
      var ID_A13_HD="218";
      var ID_PROY40DF="16";
      var ID_A7_DF="212";
      var ID_A13_DF="213";
      var ID_C2TV="12";
      var ID_C4TV="14";
      var ID_C5TV="15";
      var ID_C9TV="19";
      var volumen=0.5;
      var guia_tiempos=0;
      var ajustado=0;
      var grupo_testigo=0;
      var timer_exp=null;
      var timer_recarga=null;
      var reproduciendo=0;
      var modoSap=0;
      var reguia=1;
      var meses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
                    "Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
      var diasSemana =["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
//--------------------funciones Reproductor----------------------------------
      function set_timer_recarga1()
      {
        set_timer_recarga();
      }
      function agranda(){
        document.getElementById('fondoRep').style.visibility="visible";
        document.getElementById('titulo').style.visibility="visible";
        document.getElementById("fondoRep").style.width = '961px';
        document.getElementById("fondoRep").style.height = '580px';
        document.getElementById("cuadroRep").style.width = '956px';
        document.getElementById("cuadroRep").style.height = '548px';
        document.getElementById("cuadroRep").style.borderWidth = '2px';
        document.getElementById("imgCierra").style.width = '20px';
        document.getElementById("imgCierra").style.height = '20px';
        reproduciendo=1;
      }
      function reduce()
      {
        document.getElementById('titulo').style.visibility="hidden";
        document.getElementById("fondoRep").style.width = '0px';
        document.getElementById("fondoRep").style.height = '0px';
        document.getElementById("cuadroRep").style.width = '0px';
        document.getElementById("cuadroRep").style.height = '0px';
        document.getElementById("cuadroRep").style.borderWidth = '0px';
        document.getElementById("imgCierra").style.width = '0px';
        document.getElementById("imgCierra").style.height = '0px';
        document.getElementById("cuadroRep").src='';
        set_timer_recarga1();
        reproduciendo=0;
      }
      function logout_()
      {
        if(reproduciendo==0)
        {
          alert("Sesión finalizada");
          window.location="login/logout.php";
        }else{
        }
      }
      function muestraReproductor(carpeta){
        if(guia_tiempos==1){
          document.getElementById("cuadroRep").src ="Reproductor.php?dirVideo="+
            carpeta+"&modo=1&modoSap="+modoSap;
        }else{
          document.getElementById("cuadroRep").src ="Reproductor.php?dirVideo="+
            carpeta+"&modo=0&modoSap="+modoSap;
        }
        agranda();
      }
//------------------------------------------------------------------------------
      function guarda_volumen(vol){
        volumen=vol;
      }
      function regresa_volumen(){
        return volumen;
      }
      function salir_testigos(){
        var url="login/logout.php";
        $(location).attr('href',url);
      }
      function elemento_exp(ruta,nombre,estado,id)
      {
        this.ruta=ruta;
        this.nombre=nombre;
        this.estado=estado;
        this.intentos=0;
        this.id_bd=0;
        this.id=id;
      }
      function obt_real_id(act_tst)
      {
        var real_id=0;
        if(act_tst=="A7N")
          real_id=ID_A7_NAC;
        else if(act_tst=="A13N")
          real_id=ID_A13_NAC;
        else if(act_tst=="P40")
          real_id=ID_PROY40;
        else if(act_tst=="P40DF")
          real_id=ID_PROY40DF;
        else if(act_tst=="A7DF")
          real_id=ID_A7_DF;
        else if(act_tst=="A13DF")
          real_id=ID_A13_DF;
        else if(act_tst=="A13HD")
          real_id=ID_A13_HD;
        else if(act_tst=="A7HD")
          real_id=ID_A7_HD;
        else if(act_tst=="C2TV")
          real_id=ID_C2TV;
        else if(act_tst=="C4TV")
          real_id=ID_C4TV;
        else if(act_tst=="C5TV")
          real_id=ID_C5TV;
        else if(act_tst=="C9TV")
          real_id=ID_C9TV;
        else
          real_id=act_tst;
        return real_id;
      }
      function recarga_guia1(evento)
      {
        var fecha=$('#edDTP').val();
        if(fecha.indexOf("x")>-1)
        {
          fecha=fecha_cargada;
          selecciona_fecha(fecha);
          $('#edDTP').val(fecha);
        }
        var fec=fecha.split("/");
        var tipo_guia=1;
        var tguia="";
        var id="NINGUNA";
        var id_tst="";
        var texto="";
        var act_tst=seleccionado;
        var panel_sz="";   //lastItem.id;
        var date= new Date();
        var mi_fecha=(date.toLocaleString('es-MX')).split("/");
        var aux="0";
        var fecha_="";
        var dia=mi_fecha[0].toString();
        var mes=mi_fecha[1].toString();
        var aa=mi_fecha[2].toString();
        aa=aa.substr(0,4);
        if(dia.length<2)
          dia=aux.concat(dia);
        if(mes.length<2)
          mes=aux.concat(mes);
        fecha_=dia+"/"+mes+"/"+aa;
        if(forma_guia_actual!=0 && fecha==fecha_ && reproduciendo==0)
        {
          tipo_guia=forma_guia_actual;
          ev_seleccionado_guia=evento;
          document.getElementById('dvLoad').style.zIndex=900;
          document.getElementById('Capa1').style.zIndex=887;
          if(ajustado==0)
          {
            panel_sz=$('#grid_guia').css("height");
            var t_sz=parseInt(panel_sz)+27;
            document.getElementById('dvLoad').style.height=t_sz+"px";
            ajustado=1;
          }
          document.getElementById('dvLoad').style.visibility="visible";
          document.getElementById('Capa1').style.visibility="visible";
          id_tst=obt_real_id(act_tst);
          if(tipo_guia==1)
          {
            id=act_tst;
            guia_tiempos=0;
          }
          else if(tipo_guia==2)
          {
            guia_tiempos=1;
            id="T"+fec[0]+"/"+fec[1]+"/"+fec[2];
          }else
          {
            id=act_tst;
            guia_tiempos=0;
          }
          if(id_tst==274){
              id_tst=203;
              modoSap=274;
            }else if(id_tst==273){
              id_tst=207;
              modoSap=273;
            }else if(id_tst==277){
              id_tst=211;
              modoSap=277;
            }else{
              modoSap=0;
            }
         var data="guia="+id+"&fecha="+fecha+"&id_tst="+id_tst+"&TG="+tipo_guia;
         carga_pag_guia(data,id_tst);
        }
      }
      function selecciona_fecha(fecha)
      {
        var fe=fecha.split("/");
        $('#edDTP').submit();
        $.extend(Calendario.options,{
            firstDate: new Date(fe[2],fe[1]-1 , fe[0]),
            selectedDate: new Date(fe[2],fe[1]-1 , fe[0])
          });
        Calendario.render();
      }
      function carga_guia_default(index)
      {
        var fecha=$('#edDTP').val();
        var data="";
        if(fecha.indexOf("x")>-1)
        {
          fecha=fecha_cargada;
          selecciona_fecha(fecha);
          $('#edDTP').val(fecha);
        }
        var f_com="";
        var fec=null;
        var tguia="";
        var id="NINGUNA";
        var id_tst="";
        var texto="";
        var act_tst=seleccionado;
        var panel_sz="";   //lastItem.id;
        ev_seleccionado_guia="0";
        if(index<0)
          forma_guia_actual=2;
        else
        {
          var obj=ventana.lista_testigos[index];
          forma_guia_actual=obj['tipo'];
          ev_seleccionado_guia=obj['seleccion'];
          if(fecha!=obj['fecha']){
            fecha=obj['fecha'];
            $('#edDTP').val(fecha);
            selecciona_fecha(fecha);
          }
        }
        f_com=fecha_com(fecha);
        fec=fecha.split("/");
        $('#lbFechaCT').val(f_com);
        document.getElementById('dvLoad').style.zIndex=900;
        document.getElementById('Capa1').style.zIndex=887;
        if(ajustado==0)
        {
          panel_sz=$('#grid_guia').css("height");
          var t_sz=parseInt(panel_sz)+27;
          document.getElementById('dvLoad').style.height=t_sz+"px";
          ajustado=1;
        }
        document.getElementById('dvLoad').style.visibility="visible";
        document.getElementById('Capa1').style.visibility="visible";
        id_tst=obt_real_id(act_tst);
        texto=$("#lbTipGuia").val()+" con fecha "+fecha;
        document.getElementById('btnExpG').disabled=false;
        if(forma_guia_actual==2){
          guia_tiempos=1;
          id="T"+fec[0]+"/"+fec[1]+"/"+fec[2];
          texto="Carga guia Tiempos "+texto;
          document.getElementById('btnExpG').disabled=true;
        }else if(forma_guia_actual==1){
          guia_tiempos=0;
          id=id_tst;
          texto="Carga guia "+texto;
        }else{
          guia_tiempos=0;
          id=id_tst;
          texto="Carga guia conciliada "+texto;
        }
        carga_lista=0;
        if(id_tst==274){
          id_tst=203;
          modoSap=274;
        }else if(id_tst==273){
          id_tst=207;
          modoSap=273;
        }else if(id_tst==277){
              id_tst=211;
              modoSap=277;
        }else{
          modoSap=0;
        }
        data="guia="+id+"&fecha="+fecha+"&id_tst="+id_tst+"&TG="+forma_guia_actual;
        carga_pag_guia(data,id_tst);
        if(document.getElementById('fondoRep').style.visibility=="visible")
          reduce();
        limpia_datos();
        var lista = document.getElementById("cbxModo");
        fecha_cargada=fecha;
        lista.value = 0;
        bitacora(texto);
      }
      function bitacora(arch)
      {
        $.ajax({
				  type: 'POST',
					url: 'bitacora.php',
					data: 'texto='+arch,
          cache: false});
      }
      function ver_seleccionados()
      {
         var rutas=seleccionados();
         return rutas;
      }
      function exporta_rango(hora_ini,hora_fin,nombre)
      {
         var fecha=$('#edDTP').val();
         var duracion=hora_fin-hora_ini;
         var rutas=procesa_ruta(hora_ini,duracion,hora_fin,fecha,30);
         envio_servicio(rutas,nombre);
      }
      function envio_servicio(rutas,nombre)
      {
        var f = new Date();
        var id_exp=cola_exportacion.length;
        var nombre1=nombre.replace(/�/g,"n");
        nombre1=nombre1.replace(/�/g,"N");
        nombre1=limpia_nombre(nombre1);
        var nombre_=nombre1+"_"+f.getHours()+"_"+f.getMinutes()+"_"+f.getSeconds();
        agregaNodo(nombre_,id_exp);
        cola_exportacion.push(new elemento_exp(rutas,nombre_,0,"A"+id_exp));
        exporta_elemento(rutas,nombre_,id_exp);
        if(timer_exp==null)
          timer_exp=setTimeout("checa_exportacion()",20000);
      }
      function limpia_nombre(nombre)
      {
        var res = nombre.replace(/\//g,"_");
        res = res.replace(/:/g, "_");
        res = res.replace(/\*/g,"_");
        res = res.replace(/\?/g, "_");
      //  res = res.replace(/\'/g, "_");
      //  res = res.replace(/\"/g, "_");
        return res;
      }
      function agregaNodo(nombre,id_exp){
        var lista = document.getElementById("Exportacion");
        var nvoNodo = document.createElement('li');
        var textoNodo=document.createTextNode(nombre);
        nvoNodo.appendChild(textoNodo);
        lista.appendChild(nvoNodo);
        nvoNodo.id="A"+id_exp;
        $('#'+nvoNodo.id).attr("title","En Espera");
      }
      function exporta_elemento(rutas,nombre,id_exp)
      {
        $.ajax({
				  type: 'POST',
					url: 'Servicio_.php',
					data: 'ruta='+rutas+'&name='+nombre+'&agent='+navigator.userAgent+'&modoSap='+modoSap,
          cache: false,
          success:function(Respuesta)
					{
            item=cola_exportacion[id_exp];
            if(Respuesta>2)
            {
              item.id_bd=Respuesta;
            }else if(item.intentos<2){
              item.intentos+=1;
              alert("Hubo un error al tratar de exportar "+nombre+"\n"
                    +"Se intentará descargar nuevamente.");
            }else{
              item.estado=1;
              $('#A'+id_exp).remove();
              alert("No se puedo exportar intentelo mas tarde "+nombre);
            }
          },
          error:function(){
            checa_exportacion();
					}
        });
      }
      function ruta_(cadena)
      {
        var key="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        var datos=key.split("");
        var chrs=cadena.split("");
        var index= 0;
        var output="";
        if(chrs.length>0)
        {
          for(var i=0;i<chrs.length;i++)
          {
            index=datos.indexOf(chrs[i])-3;
            if(index<0)
              index+=datos.length;
            output+=datos[index];
          }
        }
        return Base64.decode(output);
      }
      function checa_exportacion()
      {
        var items=cola_exportacion.length;
        var item=null;
        var espera=1;
        var estado="";
        var exportados=0;
        var ruta=ruta_("dKU3fGryO2HzOmb3OmH1OmH4RF=ohKEyfqUkb5oyepY2OzCC");
        //var ruta=ruta_("dKU3fGryO2HzOmb3OmH1OmP0O5Y7fJ=1gJImdZ=xcaPy");
        for(var i=0;i<items;i++)
        {
          item=cola_exportacion[i];
          if(item.estado==0&&item.id_bd==0)
          {
            exporta_elemento(item.ruta,item.nombre,i);
          }else if(item.estado==0&&item.id_bd!==0)
          {
            $.ajax({
				      type: 'POST',
					    url: 'exportaciones.php',
					    data: 'id_corte='+item.id_bd+'&name='+item.nombre,
              cache: false,
              success:function(Respuesta)
					    {
                var nombre=item.nombre;
                if(Respuesta==0){
                  estado="En espera";
                }else if(Respuesta==1){
                  estado="Procesando";
                }else if(Respuesta==2){
                  estado="";
                  var hrefElem = document.createElement('A');
                  var nodo = document.getElementById(item.id);
                  var textoNodo=document.createTextNode(nombre);
                  hrefElem.appendChild(textoNodo);
                  hrefElem.href = ruta+item.nombre+".mov";
                  hrefElem.download=item.nombre;
                  nodo.replaceChild(hrefElem,nodo.lastChild);
                  alert("Terminado " + item.nombre);
                  item.estado=1;
                  $('#'+item.id).on("click",function (){
                    $('#'+item.id).remove();
                  });
                  exportados++;
                }else if(Respuesta==3){
                  estado="Error";
                  item.estado=1;
                  alert("Hubo un error al intentar exportar "+item.nombre+"\n"
                        +"Intentelo mas tarde.");
                  $('#'+item.id).attr("color","Red");
                }
                $('#'+item.id).attr("title",estado);
              },
              error:function(){
                espera=0;
					    }
            });
            i=items;
          }
        }
        timer_exp=setTimeout("checa_exportacion()",15000);
      }
      function fecha_com(fecha)
      {
        var aux=fecha.split("/");
        var f=new Date(parseInt(aux[2]),parseInt(aux[1])-1,parseInt(aux[0]));
        var fecha_c=diasSemana[f.getDay()] + ", " + f.getDate() + " de " + meses[f.getMonth()] + " " + f.getFullYear();
        return fecha_c;
      }
      function ajusta(num,ajuste)
      {
        var numero=Math.floor(num);
        var cad=numero.toString();
        var cero="0";
        for(var i=0;i<ajuste;++i)
        {
          if(cad.length<ajuste)
          {
            cad=cero.concat(cad);
          }
        }
        return cad;
      }
      function hor_seg(hora_ini)
      {
        var tiempo=hora_ini.split(":");
        var horas=parseInt(tiempo[0]);
        var mins=parseInt(tiempo[1]);
        var segs=parseInt(tiempo[2]);
        var total=horas*3600+mins*60+segs;
        return total;
      }
      function obt_hor_cua(hora_ini)
      {
        var tiempo=hora_ini.split(":");
        var horas=parseInt(tiempo[0]);
        var mins=parseInt(tiempo[1]);
        var segs=parseInt(tiempo[2]);
        var cuadros=0;
        if(tiempo.length==4)
          cuadros=parseInt(tiempo[3]);
        var total=horas*3600+mins*60+segs;
        var cua=(total*30)+cuadros;
        return cua;
      }
      function obt_hor_cua2(hora_ini)
      {
        var tiempo=hora_ini.split(":");
        var horas=parseInt(tiempo[0]);
        var mins=parseInt(tiempo[1]);
        var segs=parseInt(tiempo[2]);
        var cuadros=0;
        if(tiempo.length==4)
          cuadros=parseInt(tiempo[3]);
        var total=horas*3600+mins*60+segs;
        var cua=Math.round((total*29.97)+cuadros);
        return cua;
      }
      function seg_horas(seg_ini)
      {
         var horas = Math.floor(seg_ini/3600);
         var minutos = Math.floor((seg_ini-(horas*3600))/60);
         var segundos = seg_ini-(horas*3600)-(minutos*60);
         var tiempo=ajusta(horas,2)+":"+ajusta(minutos,2)+":"+ajusta(segundos,2);
         return tiempo;
      }
      function cuadros_hor(cuadros)
      {
         var horas = Math.floor(cuadros/107892);
         var minutos = Math.floor((cuadros-(horas*107892))/1798.2);
         var segundos = Math.floor((cuadros-(horas*107892)-(minutos*1798.2))/29.97);
         var cuadros=cuadros-Math.round((horas*107892)+(minutos*1798.2)+segundos*29.97);
         var tiempo=ajusta(horas,2)+":"+ajusta(minutos,2)+":"+ajusta(segundos,2)+":"+ajusta(cuadros,2);
         return tiempo;
      }
      function carga_dato(evento)
      {
        var datos=evento.split("*");
        $('#edCli').val((datos[0]).trim());
        $('#edVer').val((datos[1]).trim());
        $('#edRack').val((datos[2]).trim());
        $('#edDur').val((datos[3]).trim());
        $('#edRec').val(datos[4]);
        $('#edHora').val(datos[5].substring(0,8));
        $('#lbHInicioCT').val(datos[5]);
        $('#grid_guia').focus();
      }
      function limpia_datos()
      {
        $('#edDur').val("");
        $('#edRec').val("");
        $('#edRack').val("");
        $('#edVer').val("");
        $('#edCli').val("");
        $('#lbHInicioCT').val("00:00:00:00");
      }
      function oculta_p()
      {
        document.getElementById('dvLoad').style.zIndex=50;
        document.getElementById('dvLoad').style.visibility="hidden";
        document.getElementById('dvLoad').style.zIndex=49;
        document.getElementById('Capa1').style.visibility="hidden";
        carga_lista=1;
      }
      function ev_clic(id,categoria,gpoTestigos)
      {
        var f=$('#edDTP').val();
        if(id==273 || id==274 || id==277)
          modoSap=id;
        else
          modoSap=0;
        if(f.indexOf("x")>-1)
        {
          f=fecha_cargada;
          selecciona_fecha(f);
          $('#edDTP').val(f);
        }
        var lista = document.getElementById("cbxModo");
        var antes=-1;
        var seleccion_="0";
        if(seleccionado!="")
          $('#'+seleccionado).css({"background":""});
        $('#'+id).css({"background":"#369"});
        if(seleccionado!=id)
        {
          antes=ventana.busca_vista(obt_real_id(id));
          if(carga_lista){
            seleccion_=recarga_guia(1);
            ventana.actualiza_vista(obt_real_id(seleccionado),0,seleccion_,fecha_cargada);
          }
          seleccionado=id;
          if((id=="C2TV"||id=="C4TV"||id=="C5TV"||id=="C9TV"||id==350||id==351||id==352||
            gpoTestigos==17||gpoTestigos==18||gpoTestigos==19||gpoTestigos==3)&&lista.length>=3)
          {
            if(lista.length==4)
              $("#cbxModo").find("option[value='3']").remove();
            $("#cbxModo").find("option[value='1']").remove();
          }else if((id!="C2TV"&&id!="C4TV"&&id!="C5TV"&&id!="C9TV"&&id!=350&&id!=351&&id!=352
                    &&gpoTestigos!=17&&gpoTestigos!=18&&gpoTestigos!=19&&gpoTestigos!=3))
          {
            if(lista.length==2)
            {
              $("#cbxModo").find("option[value='2']").remove();
              $('#cbxModo').append('<option value="1">La Gu&iacutea</option>');
              $('#cbxModo').append('<option value="2">La Hora</option>');
            }
            if((gpoTestigos==2 || gpoTestigos==5 || id=="A7HD" || id=="A13HD"
                || id=="214" || id=="215" )&&lista.length<4){
                $('#cbxModo').append('<option value="3">La Gu&iacutea Reconciliada</option>');
            }else if(gpoTestigos!=2 && gpoTestigos!=5 && id!="A7HD" && id!="A13HD"
                  && id!=214 && id!=215 && lista.length==4)
              $("#cbModoDCT").find("option[value='3']").remove();
          }
          guia_visible(id,categoria);
          limpia_datos();
          grupo_testigo = gpoTestigos;
          if(antes<0)
          {
            carga_guia_default(-1);
            ventana.agrega_vista(obt_real_id(seleccionado),2,"0",f);
          }else
            carga_guia_default(antes);
        }
        lista.value = 0;
      }
      function guia_visible(act_tst,categoria)
      {
        var t_guia="";
        if(act_tst=="A7N")
        {
          tguia=" Azteca Nacional / Azteca 7 SD   ";
        }else if(act_tst=="A13N"){
          tguia="   Azteca Nacional / Azteca 13 SD   ";
        }else if(act_tst=="P40")
        {
          tguia="   Azteca D.F. / ADN 40 HD   ";
        }else if(act_tst=="203"){
          tguia="   Azteca Nacional / Azteca 7 HD   ";
        }else if(act_tst=="207")
        {
          tguia="   Azteca Nacional / Azteca 13 HD   ";
        }else if(act_tst=="211")
        {
          tguia="   Azteca Nacional / ADN 40 HD   ";
        }else if(act_tst=="P40DF")
        {
          tguia="   Azteca D.F. / AND 40   ";
        }else if(act_tst=="A7DF")
        {
          tguia="   Azteca D.F. / Azteca 7    ";
        }else if(act_tst=="A13DF")
        {
          tguia="   Azteca D.F. / Azteca 13    ";
        }else if(act_tst=="A13HD")
        {
          tguia="Azteca D.F. / Azteca 13 HD";
        }else if(act_tst=="A7HD")
        {
          tguia="Azteca D.F. / Azteca 7 HD";
        } else if(act_tst=="C2TV")
        {
          tguia="   Televisa D.F. / Canal 2    ";
        }else if(act_tst=="C4TV")
        {
          tguia="   Televisa D.F. / Canal 4    ";
        }else if(act_tst=="C5TV")
        {
          tguia="   Televisa D.F. / Canal 5    ";
        }else if(act_tst=="214")
        {
          tguia="   AA / Este HD - Nacional   ";
        }else if(act_tst=="215")
        {
          tguia="   AA / Pacifico HD - Nacional   ";
        }else
          tguia=categoria;
        $("#lbTipGuia").val(tguia);
      }
      function carga_pag_guia(data,id_tst)
      {
        if(reguia==1)
        {
          reguia==0;
          $('#dvGuia').empty();
          $('#dvGuia').load("Muestraguia.php",data,function(responseTxt, statusTxt, xhr){
            if(statusTxt == "success"){
              var elem="";
              tam_ventana=$(window).height();
              if ($("#Guia_tiempo").length)
              {
                elem="#Guia_tiempo";
                tipo_guia=1;
              }else if($("#Guia").length)
              {
                elem="#Guia";
                tipo_guia=0;
              }else
              {
                alert("No disponible en esta fecha");
                oculta_p();
              }
	            $(elem).select({
		            selectElement:"tr"			// which parent element should be selected. If blank, the element itself will be selected
	            });
              set_timer_recarga();
              auto_ajuste('dvGuia');
              obt_actual(id_tst);
              oculta_p();
              reguia=1;
            }else if(statusTxt == "error")
              alert("Error: " + xhr.status + ": " + xhr.statusText);
              reguia=1;
          });
        }
      }
      function auto_ajuste(id)
      {
        var espacio_iframe=515;
        if (window.innerHeight)
        {
            //navegadores basados en mozilla
          espacio_iframe = window.innerHeight - 149;
        }else{
          if (document.body.clientHeight)
          {
              //Navegadores basados en IExplorer, es que no tengo innerheight
            espacio_iframe = document.body.clientHeight - 149;
          }
        }
        if(espacio_iframe<515)
          espacio_iframe=515;
        $('#'+id).css({"height":espacio_iframe});
        $('#dvLoad').css({"height":espacio_iframe+27});
        $('#dvIzquierdo').css({"height":espacio_iframe+80});
      }
      function on_load_pag()
      {
        var tar="";
        var fecha=$('#edDTP').val();
        var primero=$('#menu').find('div.selectable').first()[0].id;
        var nombre=$('#menu').find('div.selectable').first()[0].innerHTML;
        nombre=nombre.substring(0,nombre.indexOf("-"));
        var gpo_=$(lastItem).attr("name");
        if($(lastItem).attr("id")!=="AA")
          tar=$(lastItem).find("a")[0].innerHTML+" / "+nombre;
        else
          tar="AA"+" / "+nombre;
        gpo_=gpo_.replace("G","");
        gpo_=(isNaN(gpo_))?0:gpo_;
        ventana= new vista_testigos();
        if(fecha=="")
        {
          var f = new Date();
          $('#edDTP').val(ajusta(f.getDate(),2) + "/" +ajusta((f.getMonth() +1),2) + "/" + f.getFullYear());
        }
        fecha_cargada=$('#edDTP').val();
        document.getElementById('dvLoad').style.visibility="hidden";
        document.getElementById('dvLoad').style.zIndex=900;
        document.getElementById('dvLoad').style.visibility="visible";
        if(seleccionado=="")
        {
            ev_clic(primero,tar,gpo_);
        }
        document.getElementById('btnSelec').disabled=false;
        document.getElementById('fondoRep').style.visibility="hidden";
        document.getElementById('titulo').style.visibility="hidden";
        $('#lbFechaCT').val(fecha_com($('#edDTP').val()));
        document.getElementById('dvLoad').style.zIndex=50;
      }
      function cambio_tipo_guia()
      {
        var fecha=$('#edDTP').val();
        if(fecha.indexOf("x")>-1){
            fecha=fecha_cargada;
            selecciona_fecha(fecha);
            $('#edDTP').val(fecha);
        }
        var f_com=fecha_com(fecha);
        var fec=fecha.split("/");
        var tipo_guia=1;
        var tguia="";
        var id="NINGUNA";
        var id_tst="";
        var texto="";
        var seleccion_="0";
        var act_tst=seleccionado;
        var panel_sz="";   //lastItem.id;
        tipo_guia=$("#cbxModo").val();
        document.getElementById('btnSelec').disabled=false;
        document.getElementById('btnExpG').disabled=false;
        if(tipo_guia!=0)
        {
          seleccion_=recarga_guia(1);
          ev_seleccionado_guia=seleccion_;
          if(forma_guia_actual!=tipo_guia)
          {
            forma_guia_actual=tipo_guia;
            ev_seleccionado_guia="0";
          }
          $('#lbFechaCT').val(f_com);
          document.getElementById('dvLoad').style.zIndex=900;
          document.getElementById('Capa1').style.zIndex=887;
          if(ajustado==0)
          {
            panel_sz=$('#grid_guia').css("height");
            var t_sz=parseInt(panel_sz)+27;
            document.getElementById('dvLoad').style.height=t_sz+"px";
            ajustado=1;
          }
          document.getElementById('dvLoad').style.visibility="visible";
          document.getElementById('Capa1').style.visibility="visible";
          id_tst=obt_real_id(act_tst);
          if(act_tst=="A7N")
            texto="Azteca 7 Nacional con fecha "+fecha;
          else if(act_tst=="A13N")
            texto="Azteca 13 Nacional con fecha "+fecha;
          else if(act_tst=="P40")
            texto="Proyecto 40 HD Aire con fecha "+fecha;
          else if(act_tst=="P40DF")
            texto="Proyecto 40 con fecha "+fecha;
          else if(act_tst=="A7DF")
            texto="Azteca 7 D.F. con fecha "+fecha;
          else if(act_tst=="A13DF")
            texto="Azteca 13 D.F. con fecha "+fecha;
          else if(act_tst=="A13HD")
            texto="Azteca 13 HD Aire con fecha "+fecha;
          else if(act_tst=="A7HD")
            texto="Azteca 7 HD Aire con fecha "+fecha;
          else if(act_tst=="C2TV")
            texto="Canal 2 D.F. con fecha "+fecha;
          else if(act_tst=="C4TV")
            texto="Canal 4 D.F. con fecha "+fecha;
          else if(act_tst=="C5TV")
            texto="Canal 5 D.F. con fecha "+fecha;
          else if(act_tst=="C9TV")
            texto="Canal 9 D.F. con fecha "+fecha;
          else
            texto=$("#lbTipGuia").val()+" con fecha "+fecha;

          if(tipo_guia==1)
          {
            id=act_tst;
            guia_tiempos=0;
            texto="Carga guia .GRA "+texto;
          }else if(tipo_guia==2)
          {
            guia_tiempos=1;
            id="T"+fec[0]+"/"+fec[1]+"/"+fec[2];
            texto="Carga guia Tiempos "+texto;
            document.getElementById('btnExpG').disabled=true;
          }else
          {
            id=act_tst;
            guia_tiempos=0;
            texto="Carga guia reconciliada "+texto;
            document.getElementById('btnSelec').disabled=true;
          }
          if(id_tst==274){
            id_tst=203;
            modoSap=274;
          }else if(id_tst==273){
            id_tst=207;
            modoSap=273;
          }else if(id_tst==277){
            id_tst=211;
            modoSap=277;
          }else{
            modoSap=0;
          }
          ventana.actualiza_vista(id_tst,tipo_guia,seleccion_,fecha);
          var data="guia="+id+"&fecha="+fecha+"&id_tst="+id_tst+"&TG="+tipo_guia;
          carga_pag_guia(data,id_tst);
          if(document.getElementById('fondoRep').style.visibility=="visible")
              reduce();
          limpia_datos();
          var lista = document.getElementById("cbxModo");
          lista.value = 0;
          fecha_cargada=fecha;
          bitacora(texto);
        }
      }
      function ver_seleccionados()
      {
        var rutas=seleccionados();
        if(rutas.indexOf("http")>1)
          muestraReproductor(rutas);
      }
      function ir_evento_actual()
      {
        var num_ev=0;
        var sgs=0;
        if(guia_tiempos)
        {
          var tipo = tipo_guia_despliegue();
          var momentoActual = new Date();
          var hora = momentoActual.getHours();
          var minuto = momentoActual.getMinutes();
          var segundo = momentoActual.getSeconds();
          sgs= (hora*60*60)+(minuto*60)+segundo;
          if(sgs!=0)
          {
            if(tipo==5){
              num_ev=parseInt(sgs/300)+1;
            }else{
              num_ev=parseInt(sgs/60)+1;
            }
          }else
            num_ev=1;
        }
        actual(num_ev);
      }
      function keydo()
      {
        var e = event || evt; // for trans-browser compatibility
        var key = e.which || e.keyCode;
        if ((key == 8 || key == 9 || key == 46 || (key >= 37 && key <= 40) ||
            (key >= 48 && key <= 57) || (key >= 96 && key <= 105)) && e.shiftKey!=1)
        {
          var edit=document.getElementById("edHora");
          var dato=$('#edHora').val();
          var fin=edit.selectionEnd;
          var ini=edit.selectionStart;
          if(key < 37 || key > 40)
          {
            var i=0,b=0;
            if(ini!=fin)
            {
              var a1=dato.split("");
              for(i=ini;i<fin;i++)
              {
                if(i!=2&&i!=5)
                {
                  a1[i]="x";
                }
              }
              dato=a1.join("");
              $('#edHora').val(dato);
              if(key==46)
              {
                if(ini==2||ini==5)
                {
                  ini=ini+1;
                }
                edit.setSelectionRange(ini,ini);
                e.preventDefault();
                return false;
              }
            }
            else
            {
              if(key==46)
              {
                e.preventDefault();
                return false;
              }
            }
            if(key!=8)
            {
              if(ini==2||ini==5)
              {
                ini=ini+1;
              }
            }
            else
            {
              var arreglo=dato.split("");
              if(ini==3||ini==6)
                ini=ini-2;
              else
                ini=ini-1;
              arreglo[ini]="x";
              dato=arreglo.join("");
              $('#edHora').val(dato);
              edit.setSelectionRange(ini,ini);
              e.preventDefault();
              return false;
            }
            i=dato.indexOf("x");
            if(i!==-1)
              edit.setSelectionRange(i,i+1);
            else
            {
              if(ini>=8)
              {
                $('#edHora').blur();
                e.preventDefault();
                return false;
              }
              else
                edit.setSelectionRange(ini,ini+1);
            }
          }else if(key==38 || key==40)
          {
            var valor=0;
            var tiempo="";
            var posicion=0;
            var cadena="";
            var cuenta=0;
            if(ini==2||ini==5||ini==8)
              cadena=dato.substring(ini-2,ini);
            else if(ini==0||ini==3||ini==6)
              cadena=dato.substring(ini,ini+2);
            else
              cadena=dato.substring(ini-1,ini+1);
            if(cadena.indexOf("x")>-1)
              cadena="00";
            cuenta=parseInt(cadena);

            if(key==38)
              cuenta+=1;
            else
              cuenta-=1;
            if(ini>=0 && ini<3)
              posicion=0;
            else if(ini>=3 && ini<6)
              posicion=3;
            else
              posicion=6;
            switch (posicion)
            {
              case 0:
                if(cuenta==24)
                  cuenta=0;
                else if(cuenta<0)
                  cuenta=23;
                tiempo= ajusta(cuenta,2);
                dato=tiempo+dato.substring(2);
              break;
              case 3:
                if(cuenta==60)
                  cuenta=0;
                else if(cuenta<0)
                  cuenta=59;
                tiempo= ajusta(cuenta,2);
                dato=dato.substring(0,3)+tiempo+dato.substring(5);
              break;
              case 6:
                if(cuenta==60)
                  cuenta=0;
                else if(cuenta<0)
                  cuenta=59;
                tiempo= ajusta(cuenta,2);
                dato=dato.substring(0,6)+tiempo;
              break;
            }
            $('#edHora').val(dato);
            edit.setSelectionRange(posicion,posicion+2);
            e.preventDefault();
            return false;
          }
        }
        else
        {
          e.preventDefault();
          return false;
        }
      }
      function keyu()
      {
        var hora=$('#edHora').val();
          var RegExPattern = /^(([0-1]{1}[0-9]{1}|2{1}[0-3]{1})\:[0-5]{1}[0-9]{1}\:[0-5]{1}[0-9]{1})|(x{2}\:x{2}\:x{2})$/;
          var e = event || evt; // for trans-browser compatibility
          var key = e.which || e.keyCode;
          if ((key == 8 || key == 9 || key == 46 || (key >= 37 && key <= 40) ||
            (key >= 48 && key <= 57) || (key >= 96 && key <= 105)) && e.shiftKey!=1)
          {
            var num_ev=0;
            var sgs=0;
            var tgd=tipo_guia_despliegue();
            if(key != 37 && key != 39)
            {
              if(hora.indexOf("x")<0)
              {
                sgs=hor_seg(hora);
                if(guia_tiempos)
                {
                  if(sgs!=0)
                  {
                     if(tgd==5)
                        num_ev=parseInt(sgs/300)+1;
                     else
                        num_ev=parseInt(sgs/60)+1;
                  }
                  else
                    num_ev=1;
                  actual(num_ev);
                }else
                {
                  hora_guia_(sgs);
                }
              }
            }
          }else
            return false;
      }
      function exporta_clic()
      {
        try{
          var fecha=$('#edDTP').val();
          var rutas=exp_seleccionados(fecha);
          if(rutas!=""&&rutas!="Sin videos"){
            var guarda=prompt("Guardar como:", "");
            if(guarda!=null){
              if(guarda=="")
                guarda="video";
              envio_servicio(rutas,guarda);
            }
          }else if(rutas=="Sin videos")
            alert("Sin videos");
          else
            alert("No se ha seleccionado evento");
        }catch(err){
          var id_exp=cola_exportacion.length;
          $('#A'+id_exp).remove();
          alert("Hubo un error, intentelo mas tarde");
        }
      }
      function exporta_guia_clic()
      {
        var guia_txt=exporta_guia();
        var fecha=$('#edDTP').val();
        fecha=fecha.replace(/\//g,"_");
        var id_tst=obt_real_id(seleccionado);
        $.ajax({
				  type: 'POST',
					url: 'expGuia.php',
					data: 'texto='+guia_txt+"&fecha="+fecha+"&testigo="+id_tst,
          cache: false,
          success:function(Respuesta)
					{
            if(Respuesta!==0 && Respuesta!="")
            {
              window.location.href="descarga_guia.php?file="+Respuesta;
            }else{
              alert('Hubo un error al tratar de exportar \n Intentelo nuevamente.');
            }
          },
          error:function(){
            alert('Hubo un error al tratar de exportar \n Intentelo nuevamente.');
					}
        });
      }
    </script>
  </head>
  <body onload="on_load_pag()">
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery-scrollto.js"></script>
    <script src="js/glDatePicker.js"></script>
    <script src="js/glDatePicker.min.js"></script>
    <form id="FormTestigo">
      <div id="dvMenu">
<?php
crea_menu();
?>
      </div>
      <div id="dvIzquierdo">
        <label for="cbxModo">Depliegue Eventos</label>
        <select id="cbxModo" name="cbxModo" onchange="cambio_tipo_guia()">
          <option value="0">En base a:</option>
          <option value="1">La Guía</option>
          <option value="2">La Hora</option>
        </select>
        <input type="button" id="btnExp" onclick="exporta_clic()" value="Exportar">
        <input type="button" id="btnActual" onclick="ir_evento_actual()" value="Evento Actual">
        <input type="button" id="btnExpG" onclick="exporta_guia_clic()" value="Exportar Guía">
        <input type="button" id="btnSelec" onclick="ver_seleccionados()" value="Ver Selección"><br>
        <label for="edHora">Hora del Día</label>
        <input type="text" id="edHora" onkeydown="keydo()" onkeyup="keyu()" value="00:00:00">
        <label for="edDTP">Fecha</label>
        <input type="text" id="edDTP" value=""/>
        <label for="edCli">Cliente</label>
        <input type="text" id="edCli" readonly>
        <label for="edVer">Versión</label>
        <input type="text" id="edVer" readonly>
        <label for="edRack">No. de Rack o fuente</label>
        <input type="text" id="edRack" readonly>
        <label for="edRec">Reconcile Key   Duración</label>
        <input type="text" id="edRec" readonly>
        <input type="text" id="edDur" readonly>
      </div>
      <div id="dvTestigo">
        <input type="text" id="lbTipGuia" value="" readonly style="width: 45%">
        <input type="text" id="lbFechaCT" value="" readonly>
        <input type="text" id="lbHInicioCT" value="" readonly>
      </div>
      <div id="dvExporta">
        <ul id="menuExport">
          <li id="EXP" ><a>Exportados</a>
            <div class="dropdown_1column">
              <ul id="Exportacion"></ul>
            </div>
          </li>
        </ul>
      </div>
      <div id="dvHTabla">
        <table id="HGuia">
          <thead>
            <tr>
              <th width='30px' bgcolor='#d3d3d3' align='center'>No.</th>
              <th width='70px' bgcolor='#d3d3d3' align='center'>Hora</th>
              <th width='70px' bgcolor='#d3d3d3' align='center'>Tipo</th>
              <th width='70px' bgcolor='#d3d3d3' align='center'>Origen</th>
              <th width='240px' bgcolor='#d3d3d3' align='center'>Cliente</th>
              <th width='245px' bgcolor='#d3d3d3' align='center'>Versión</th>
              <th width='70px' bgcolor='#d3d3d3' align='center'>Reck</th>
              <th width='65px' bgcolor='#d3d3d3' align='center'>Duración</th>
              <th width='45px' bgcolor='#d3d3d3' align='center'>Testigo</th>
              <th width='100px' bgcolor='#d3d3d3' align='center'>Estado</th>
            </tr>
          </thead>
        </table>
      </div>
      <div id="dvGuia">
      </div>
    </form>
    <div id="dvLoad" style="visibility:hidden;">
       <img src="img/carga.gif" alt="Cargando" height="100" width="100">
    </div>
    <div id="Capa1" style="visibility:hidden;height:100%;width:100%;z-index:100;"></div>
    <div id="fondoRep">
      <div id="titulo">
			  <center>
				  TESTIGOS
			  </center>
		  </div>
      <img id="imgCierra" src="img/14048.png" onclick="reduce()"/>
      <center>
        <iframe name="cuadroRep" id="cuadroRep" src="" frameborder="0" scrolling="no"></iframe>
	    </center>
    </div>
  </body>
</html>
<script>
  $(document).ready(function() {
    var year = (new Date).getFullYear();
    var m=(new Date).getMonth();
    var d=(new Date).getDate();
    Calendario=$('#edDTP').glDatePicker({
      showAlways: true,
      zIndex: 2,
      cssName: 'darkneon',
      selectableDateRange: [{from: new Date(year-2, 0, 1), to: new Date (year-2,11, 31)},
        {from: new Date(year-1, 0, 1), to: new Date (year-1,11, 31)},
        {from: new Date(year, 0, 1), to: new Date (year,m,d)}],
        selectableYears: [year-2, year-1, year],
        dowNames: ["D","L","M","M","J","V","S"]
      }).glDatePicker(true);
      var items = document.getElementById( 'menu' ).getElementsByTagName( 'li' );
      var doSelect = function()
      {
        // primero por si le saco si es que tiene la clase "selected" al item previo
        if( lastItem )
        {
          lastItem.className = '';
        }

            // this es el <li> en el cual se ha hecho click
        this.className = 'selected';
        lastItem = this;
      };

            // registro el evento click pa cada <li>
      for( var i = 0, l = items.length; i < l; i++ )
      {
        items[i].onclick = doSelect;
        if(i==0)
        lastItem=items[i];
      }
      auto_ajuste('dvGuia');
      $("#fondoRep").draggable({iframeFix: true});
      $("#fondoRep").draggable( "option", "cursor", "move" );
  });
</script>