<?php
  require_once("bitacora.php");
//--------------------------------------------------------------------------
  function conecta_bd($usr,$pass,$dbname,&$e)
  {
    $conexion=false;
    $conexion=oci_connect($usr,$pass,$dbname,'AL32UTF8');
    if(!$conexion)
    {
      $e = oci_error();
      Bitacora($e['message'],1);
    }
    return $conexion;
  }
//--------------------------------------------------------------------------
  function ejecuta_select($cursor,&$e)
  {
    $arreglo=null;
    $resultado=oci_execute($cursor);
    if(!$resultado)
    {
      $e=oci_error($cursor);
       Bitacora($e['message'],1);
    }else{
      while (($fila = oci_fetch_array($cursor, OCI_ASSOC+OCI_RETURN_NULLS))!==false) {
        $arreglo[]=$fila;
      }
    }
    return $arreglo;
  }
//--------------------------------------------------------------------------
  function ejecuta_query($cursor,&$e)
  {
    $exito=true;
    $exito=oci_execute($cursor,OCI_COMMIT_ON_SUCCESS);
    if($exito===false)
    {
      $e = oci_error($cursor);
      Bitacora($e['message'],1);
    }
    return $exito;
  }
//--------------------------------------------------------------------------
  function ejecuta_query2($cursor,&$e)
  {
    $exito=true;
    $exito=oci_execute($cursor,OCI_NO_AUTO_COMMIT);
    if($exito===false)
    {
      $e = oci_error($cursor);
      Bitacora($e['message'],1);
    }
    return $exito;
  }
//--------------------------------------------------------------------------
  function parse_bd($conexion,$query,&$e)
  {
    $exito=true;
    $exito=oci_parse($conexion,$query);
    if($exito===false)
    {
      $e=oci_error($conexion);
      Bitacora($e['message'],1);
    }
    return $exito;
  }
//--------------------------------------------------------------------------
  function libera_bd($conexion,$cursor)
  {
    if($cursor!=NULL && $cursor!=false)
      oci_free_statement($cursor);
    if($conexion!=null && $conexion!=false)
      oci_close($conexion);
  }
//--------------------------------------------------------------------------
  function rollback_bd($conexion)
  {
      oci_rollback($conexion);
  }
//--------------------------------------------------------------------------
  function commit_bd($conexion)
  {
    $r=oci_commit($conexion);
    if(!$r)
    {
      $r=oci_error($conexion);
    }else
      $r=true;
    return $r;
  }
//--------------------------------------------------------------------------
?>