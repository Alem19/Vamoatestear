<?php
require_once("bitacora.php");
require_once("manejo_bd.php");
//------------------------------------------------------------------------------
function checa_guia_reconciliada($id_tst,$total,$fecha)
{
  $conexion=null;
  $cursor=null;
  $fila=null;
  $tabla="";
  $guia=null;
  $fe1=explode("/",$fecha);
  $fech=$fe1[1]."/".$fe1[0]."/".$fe1[2];
  $a=strtotime($fech);
  $fecha_bor=fecha_borland2($a);
  $actualiza=0;
  $query="Select tabla_guia from testigos.lista_testigos where id_testigo=".$id_tst;

  $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$e);
  if($conexion!==false)
  {
    $cursor=parse_bd($conexion,$query,$e);
    if($cursor!==false)
    {
      $fila=ejecuta_select($cursor,$e);
      if(is_array($fila))
      {
        $tabla=$fila[0]['TABLA_GUIA'];
      }
    }
  }

  if($tabla!=="")
  {
    $fila=null;
    $query="SELECT NUMERO_EV,HORA_INICIO,TIPO_EVENTO,CLIENTE,VERSION,DURACION,NO_RACK,"
          ." FECHA,CRUCE_GUIA,EVENTO_CABS,COMANDO_CABS,NUM_PAQUETE_CABS,EVENTOS_CABS,"
          ." VIDEOS_CABS,CODIGO_CABS,TX_C_CABS "
          ."FROM ".$tabla." where fecha =".$fecha_bor." order by NUMERO_EV";
    Bitacora($query,0);
    $cursor=parse_bd($conexion,$query,$e);
    if($cursor!==false)
    {
      $fila=ejecuta_select($cursor,$e);
      if(is_array($fila))
      {
        $no=count($fila);
        Bitacora($no."-".$total,0);
        if($no>$total)
          $actualiza=1;
      }
    }
  }
  libera_bd($conexion,$cursor);
  return $actualiza;
}
//------------------------------------------------------------------------------
function checa_guia_nacional($gpo,$id_tst,$evento,$fecha)
{
  $conexion=null;
  $cursor=null;
  $fila=null;
  $guia=null;
  $e="";
  $fe1=explode("/",$fecha);
  $fech=$fe1[1]."/".$fe1[0]."/".$fe1[2];
  $a=strtotime($fech);
  $fecha_bor=fecha_borland2($a);
  $actualiza=0;
  $tabla_g="GUIA_13_CABS";
  if($gpo==1)
    $tabla_g="GUIA_7_CABS";
  else if($gpo==5)
    $tabla_g="GUIA_40_CABS";
  else if($gpo==3)
    $tabla_g="GUIA_AA_ESTE_CABS";
  else if($gpo==4)
    $tabla_g="GUIA_AA_OESTE_CABS";
  $query="SELECT ev_tst,h_ini,tipo,nombre,version,duracion,ev_cabs,rec_key,estado,hora_ms,rack,fecha_aire,archivo_fuente"
        ." from ".$tabla_g
        ." where fecha_guia =".$fecha_bor." and ev_cabs=".$evento." order by num";
  $conexion=conecta_bd(USERTESTIGOS,PASSTESTIGOS,BDTESTIGOS,$e);
  if($conexion!==false)
  {
    $cursor=parse_bd($conexion,$query,$e);
    if($cursor!==false)
    {
      $fila=ejecuta_select($cursor,$e);
      if(is_array($fila))
      {
        $estado=$fila[0]['ESTADO'];
        if($estado!=258)
          $actualiza=1;
      }
    }
  }
  libera_bd($conexion,$cursor);
  return $actualiza;
}
//------------------------------------------------------------------------------
if(isset($_POST['guia'])&&isset($_POST['evento'])&&isset($_POST['testigo'])
    &&isset($_POST['ruta'])&&isset($_POST['gpo_tst']))
{
  try
  {
    $actualiza=0;
    $tipo_guia=(is_numeric($_POST['guia']))?$_POST['guia']:0;
    $actual=(is_numeric($_POST['evento']))?$_POST['evento']:0;
    $id_tst=(is_numeric($_POST['testigo']))?$_POST['testigo']:0;
    $gpo_tst=(is_numeric($_POST['gpo_tst']))?$_POST['gpo_tst']:0;
    $fecha_guia=(isset($_POST['fecha_guia']))?$_POST['fecha_guia']:"";
    $forzado=(is_numeric($_POST['forzado']))?$_POST['forzado']:0;
    if($forzado==0)
    {
      $datos=explode("*",$_POST['ruta']);
      $total=count($datos);
      if($total==4 || $total==3)
      {
        $servidor=$datos[0];
        $carpeta=$datos[1];
        $fecha="";
        $dirServidor="http://".$_SERVER['SERVER_ADDR'];
        if($total==4){
          $fecha="/".$datos[2];
          $video=$datos[3];
        }else
          $video=$datos[2];
        if($tipo_guia==1)
        {
          $ruta="";
          $alias=str_replace('servidor','testigos',$servidor);
          $nuevo=intval(substr($video,0,18));
          $ruta="/media/".$alias."/".$carpeta.$fecha."/";
          for($i=1;$i<4;$i++)
          {
            $video_=$nuevo+($i*32);
            if($id_tst<100)
              $video_=ajuste($video_,16);
            else
              $video_=ajuste($video_,18);
            $archivo=$ruta.$video_.".mp4";
            if(file_exists($archivo))
            {
              $carpeta=$dirServidor."/".$servidor.$fecha."/".$archivo;
              $actualiza=1;
            }
          }
        }else if($tipo_guia==0)
        {
          $actualiza=checa_guia_nacional($gpo_tst,$id_tst,$actual,$fecha_guia);
        }else if($tipo_guia==2)
        {
          $total=$actual/32;
          $actualiza=checa_guia_reconciliada($id_tst,$total,$fecha_guia);
        }
        echo $actualiza;
      }else{
        Bitacora("No viene la ruta: ".$_POST['ruta'],0);
        echo $actualiza;
      }
    }else{
      //Actualización Forzada
        Bitacora("Forzado..",0);
        echo 2;
    }
  }catch(Exception $e)
  {
    Bitacora("algo paso",0);
    echo 0;
  }
}else{
  Bitacora("Faltan datos ",0);
  echo 0;
}
?>