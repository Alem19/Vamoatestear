<?php
  require_once("utilerias.php");
  require_once("bitacora.php");
    $ip=ObtenerIP();
    if(strpos($ip,"10.49.44.")!==false)
      header('Location: ../locales/coatzacoalcos/principal.php');
    else if(strpos($ip,"10.49.3.")!==false)
      header('Location: ../locales/campeche/principal.php');
    else if(strpos($ip,"10.49.31.")!==false)
      header('Location: ../locales/queretaro/principal.php');
    else if(strpos($ip,"10.49.11.")!==false)
      header('Location: ../locales/la_paz/principal.php');
    else if(strpos($ip,"10.49.47.")!==false)
      header('Location: ../locales/torreon/principal.php');
    else if(strpos($ip,"10.49.2.")!==false)
      header('Location: ../locales/aguascalientes/principal.php');
    else if(strpos($ip,"10.49.33.")!==false)
      header('Location: ../locales/veracruz/principal.php');
    else if(strpos($ip,"10.49.35.")!==false)
      header('Location: ../locales/zacatecas/principal.php');
?>