<?php

  $texto1="";

  function Bitacora($texto,$error)
  {
   
    $manejador1 = null;
    $add = null;
    $texto1="";
    date_default_timezone_set('America/Mexico_City');
 
    $directorio="../Bitacoras";
    $archivo=$directorio."/Bita_Login_".date("d_m_Y").".bit";
    if(!file_exists ($directorio))
    {
      if(!mkdir($directorio,0777))
      {
        $archivo="Bita_Login_".date("d_m_Y").".bit";
      }
    }
    if($error)
	$texto1="<<ERROR: >>\r\n";
    else
        $texto1="<<EXITO: >>\r\n";
    $add=$texto1."\t".$texto."\t".date("H:i:s")."\t".date("d-m-Y")."\r\n";  
    $manejador1=fopen($archivo,"a");
    if($manejador1)
    {
      fwrite( $manejador1,$add);
      fclose($manejador1);
      $ok=1;
    }
  }

?>