<?php

session_start();

if (isset($_SESSION['xusuario_valido'])) 
{
	
   
    header('Location: ../index.php');
 
                 
} else 
{
	header('Location: login/loginind.php');
}

?>

