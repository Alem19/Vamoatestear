<?php
session_start();

if (isset($_SESSION['xusuario_valido'])) 
{
   header('Location: contenido.php');
} 
else 
{
?>
<!DOCTYPE html>
<html >
    <head>
        <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no,
	 initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="css/estilos_login.css"> 
        <link href='//fonts.googleapis.com/css?family=Raleway:400,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        
      
        
          
        <!--alertify  css-->
        <link rel="stylesheet" type='text/css' href="Alertifylogin/css/alertify.min.css"/>
        <link rel="stylesheet" type='text/css' href="Alertifylogin/css/themes/default.min.css"/>
        <link rel="stylesheet" type='text/css' href="Alertifylogin/css/themes/semantic.min.css"/>
        <link rel="stylesheet" type='text/css' href="Alertifylogin/css/themes/bootstrap.min.css"/>
        
      
        
        <!--alertify js -->
        <script src="Alertifylogin/alertify.min.js"></script>
      
        <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="js/index.js"></script>
        
        <script type="text/javascript">
			var habilita=false;
            function showPassword() 
            {
              var muestra = document.getElementById("password");
              if (muestra.type === "password") 
              {
                muestra.type = "text";
              } 
              else
              {
                muestra.type = "password";
              }
            }
            
			
            function entra()
            {
                var usuario =$("#usuario").val();
                var password =$("#password").val();
                
               
                var datos={"usuario" :usuario,"password" :password};
                
                if(usuario ==="" || password ==="" )
                {
                    
                    $("#error").empty();
                    $("#error").append("<li> Debes llenar los campos </li>"); 
                    setTimeout(function(){ $("#error").empty();  }, 5000);
                    if(usuario==="")
                    {
                      $("#usuario").focus();
                    }
                    else
                    {
                      $("#password").focus();
                    }
                }
                else
                {
                
                $.ajax({
                    type: "POST",
                    url: "login.php",
                    dataType: "json",
                    data:datos,
                    success: function(respuesta)
                    {
                        if(respuesta.estado==true)
                        {
                            switch(respuesta.error)
                            {
                                case 0: $("#error").empty();
                                        $("#error").append("<li>Hubo un Error</li>");
                                        setTimeout(function(){ $("#error").empty();  }, 5000);
                                        break;
                                case 1: $("#error").empty();
                                        $("#error").append("<li>Hubo un Error</li>");
                                        setTimeout(function(){ $("#error").empty();  }, 5000);
                                        break;
                                case 2: $("#error").empty();
                                        $("#error").append("<li>Hubo un Error</li>");
                                        setTimeout(function(){ $("#error").empty();  }, 5000);
                                        break;
                                case 3: $("#error").empty();
                                        $("#error").append("<li>Hubo un Error</li>");
                                        setTimeout(function(){ $("#error").empty();  }, 5000);
                                        break;
                                case 4: $("#error").empty();
                                        $("#error").append("<li>Hubo un Error</li>");
                                        setTimeout(function(){ $("#error").empty();  }, 5000);
                                        break;
                                case 5: $("#error").empty();
                                        $("#error").append("<li>Hubo un Error</li>");
                                        setTimeout(function(){ $("#error").empty();  }, 5000);
                                        break;
                                    
                            }
                            return 0;
                        }      
                        else if(respuesta.estado==false)
                        {
                            location.href="../index.php";
                    
                        }
                    },
                    
                    error: function(){
                        $("#error").empty();
                        $("#error").append("<li>Hubo un Error</li>");                       
                        setTimeout(function(){ $("#error").empty();  }, 5000);
                    }
               
                    
                    });
                }
            }
            
           
        </script>
     
<title>Iniciar Sesión</title>
    </head>
    <body>
        
        <div class="contenedor">
		<h1 class="titulo1">Control Soporte CABS</h1>
                <h2 class="titulo">Iniciar Sesión</h2>
		<hr class="border">

                 <form  class="formulario" name="login">
			<div class="form-group">
                            <i class="icono izquierda fa fa-user"></i><input type="text" name="usuario" class="usuario"  autocomplete="OFF" placeholder="Usuario" id="usuario">
			</div>

                    <div class="form-group">
                        <i class=" icono izquierda fa fa-lock"  title="Presiona el icono si quieres hacer visible tu contaseña"></i><input type="password" name="password" class="password_btn" placeholder="Contraseña " id="password" >
                        <i class="submit-btn fa fa-arrow-right"  onclick="entra()" ></i>
                                
                    </div>
                    
                     <div class='error' id="error">
                       
                         <ul>
                        
                         </ul>
                       
                    </div>
                  

                </form>
	</div>
    </body>
	<script>
    $(document).ready(function(){
      $('#password').keyup(function(e){
        var code = e.keyCode ? e.keyCode:e.which;
        console.log(code);
        if(code == 13)
        {
          entra();
        }
      });
      
      $('.fa-lock').mousedown(function(){
        showPassword();
        habilita =true;
      
      });
      
      $('.fa-lock').mouseup(function(){
        if(habilita)
        {
          showPassword();
          habilita = false;
        }      
      });
      
      $('.fa-lock').mouseleave(function(){
        if(habilita)
        {
          showPassword();
          habilita = false;
        }
      
      });
    });
    
  </script>
</html>

<?php
}
?>