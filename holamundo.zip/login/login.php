<?php 
 
require_once'bitacora.php';  
require '../php/utilerias.php';
session_start(); 


 
	$usuario = htmlspecialchars(filter_var(strtoupper($_POST['usuario']),FILTER_SANITIZE_STRING));
        $usuario= sanitize($usuario);
	$password = htmlspecialchars($_POST['password']);	
        $estado=FALSE;
        $error=-1;
        Bitacora("La del mike", 0);
	try 
        {           
         
          //  $conexion= oci_connect($bduser,$bdpassword,$bdname);
            $conexion= oci_connect(USERLOGS, PASSLOGS,BDBLOQ,'AL32UTF8');
            
            if($conexion!==false)
            { 
                Bitacora("Conexión Correcta", FALSE);
                //prepara una sentencia para la ejecucion
                $query="SELECT ID,ADMINISTRADOR,NOMBRE, PERFIL FROM USUARIOS_SOPORTE_CABS WHERE NUMERO_EMPLEADO='".$usuario."'";
                
                $parse= oci_parse($conexion, $query);
                if($parse !== false)
                {
                    Bitacora("Consulta Exitosa " . $query, FALSE);
                    //ejecuta la consulta
                    $resultado= oci_execute($parse);
                    
                    if ($resultado !== false) 
                    {   //todo se guarda en un arreglo 
                        while (($fila = oci_fetch_array($parse, OCI_ASSOC+OCI_RETURN_NULLS))!==false) {
                         $resultados[]=$fila;
                         
                         }
                        if($resultados[0]['NOMBRE'] == "")
                        {    
                            
                            Bitacora("No Existe Usuario", TRUE);
                            
                            $estado=TRUE;
                            $error= 0;
                        }
                        else
                        {
                            $llave=GetProvider("3DLbZdJ5XzIH6l1toInBp31Y1ahkOt0=");
                            $eusr=encripta_dato($usuario,$llave);
                            $epsw=encripta_dato($password,$llave);
                            $respuesta=envia_soap($eusr,$epsw);
                            $valido=substr($respuesta,strpos($respuesta,"Respuesta="),16);
                            if(strpos($valido,"OK")!==false)
                            {
                                //valida estos dos datos
                                
                                $_SESSION['xusuario_valido'] = $usuario;        //
                                $_SESSION['xid_valido']=$resultados[0]['ID'];
                                $_SESSION['nxUsuario']=$resultados[0]['NOMBRE'];  //
                                $_SESSION['nxAdmin']=$resultados[0]['ADMINISTRADOR'];
                                $_SESSION['nxPerfil']= $resultados[0]['PERFIL'];
                                Bitacora("Se aceptó la Llave Maestra", FALSE);
                            }
                            else
                            {
                                Bitacora("Contraseña Incorrecta", TRUE);
                                $estado=TRUE;
                                $error= 1;
                                 
                                 
                            }       
                        }
                    }
                    else 
                    {
                        
                        $estado=TRUE;
                        $error= 2;
                        Bitacora("Fallo en la consulta a la B.D.", TRUE);

                    }
                    oci_free_cursor($parse);
                }
                else
                {
                    
                    $estado=TRUE;
                    $error= 3;
                    Bitacora("Fallo en la B.D.", TRUE);
                }
                oci_close($conexion);
            }
            else
            {
                
                $estado=TRUE;
                $error= 4;
                 Bitacora("Sin Conexión a la B.D.", TRUE);
            }
          
             //$conexion = new PDO('oci:host=127.0.0.1 ; dbname='.$bdname,$bduser,$bdpassword);
            //$statement = $conexion->prepare('SELECT count(NUMERO_EMPLEADO) AS TOTAL FROM USUARIOS_SOPORTE_CABS WHERE NUMERO_EMPLEADO= :usuario ');

            //$statement->execute(array(':usuario' => $usuario ));
            //$resultado = $statement->fetch();

                 
        } 
        catch (Exception $e) 
        {
            $estado=TRUE;
            $error= 5;
	}                
$ret=array('error' => $error,'estado' => $estado);   

echo json_encode($ret, JSON_FORCE_OBJECT);




