<?php

session_start();
$valida= (isset($_POST['xValida']))?1:0;
if (isset($_SESSION['xusuario_valido']) && $valida==1) 
{
     $recarga=$_SESSION['xusuario_valido'];
     $recarga1=$_SESSION['xid_valido'];
     $recarga2=$_SESSION['nxUsuario'];  
     $recarga3=$_SESSION['nxAdmin'];
     
     $_SESSION['xusuario_valido']=$recarga;
     $_SESSION['xid_valido']=$recarga1;
     $_SESSION['nxUsuario']=$recarga2;  
     $_SESSION['nxAdmin']=$recarga3;
     
     echo 1;
    
}
else
{
    echo 0;
}


