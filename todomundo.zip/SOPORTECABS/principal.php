<?php

include ("php/conexion.php");
include ("php/bitacora.php");

session_start();
date_default_timezone_set('America/Mexico_City');


if (isset($_SESSION['xusuario_valido'])) 
{
  //filtros
  if(isset($_SESSION['xFiltro']))
  {
      
      $filtro1=$_SESSION['xFiltro'][0];
      $filtro2=$_SESSION['xFiltro'][1];
      $filtro3=$_SESSION['xFiltro'][2];
      $filtro4=$_SESSION['xFiltro'][3];
      $filtro5=$_SESSION['xFiltro'][4];
      $filtro6=$_SESSION['xFiltro'][5];
      $filtro7=$_SESSION['xFiltro'][6];
      $filtro8=$_SESSION['xFiltro'][7];
  }
  else
  {
      
      $filtro1=0;
      $filtro2="";
      $filtro3="";
      $filtro4=0;
      $filtro5=-1;
      $filtro6=0;
      $filtro7=0;
      $filtro8=0;
  }
  
$date = strtotime(date("ymd"));
$dato_incial = '0001';
$last = strtotime(' -7 days');
$dato_final='9999';


$inicio_semana =date('ymd', $last).$dato_incial;
$fin_semana =  date('ymd', $date).$dato_final;


?> 

<!DOCTYPE html>
<html>
    <head>


        <!--<meta charset="utf-8">-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
      
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href='//fonts.googleapis.com/css?family=Raleway:400,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        
        
        <link href="css/estilos.css" rel="stylesheet">  

        <!--JS -->
        <script src="js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/index.js"></script> 
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="bootstrap/js/bootstrap.js"></script>  
        <script languaje ="javascript">
            
			var recar;
            var x=0;
            $(document).ready(function(){
                  //document.getElementById('xApp').disabled=true;
                  x=0;
                $("#xSistema").change(function (){
                    $("#xSistema option:selected").each(function(){
                        id_sistema =$(this).val();
                        $.post("php/getCombos.php", { id_sistema: id_sistema,origen:1},
                        function(data){
                            $("#xApp").html(data);
                            document.getElementById('xApp').disabled=false;
                        });
                    });
                });
               recar=setTimeout(recargasesion,600000);
               
            });
            
          
           
           function buscarReporte()
            {
                var xIdReporte =$("#xReporte").val();
                var xUsuario =$("#xUsuario").val();
                var xFechaInicial =$("#xFechaInicial").val();
                var xFechaFinal = ($("#checkfecha").prop("checked"))?$("#xFechaFinal").val():0;
                var xEstado =$("#xEstado").val();
                var xLugar =$("#xLugar").val();
                var xSistema =$("#xSistema").val();
                var xApp =$("#xApp").val();
                if(xApp!=null){
                    if(xApp.indexOf('-')>-1)
                    {
                        var dApp= xApp.split("-");
                        xApp=dApp[0];
                    }
                }
                
                var datos = "xReporte=" + xIdReporte + "&xUsuario=" + xUsuario
                            + "&xFechaInicial=" + xFechaInicial
                            + "&xFechaFinal=" + xFechaFinal
                            + "&xEstado=" + xEstado
                            + "&xLugar=" + xLugar
                            + "&xSistema=" + xSistema 
                            + "&xApp=" + xApp; 
                    
               
               console.log(xUsuario+"-"+xFechaInicial+"-"+xFechaFinal+"-"+xEstado+"-"+xLugar+"-"+xSistema+"-"+xApp);   
               
               //if(xUsuario == 0 && xFechaInicial=="" && xFechaFinal=="" && xEstado==0 && xLugar==0 && xSistema==0)
               
                   
                  // location.reload(true);
                              
                /*else if((xSistema>0 && xSistema<3)&& xApp==0){
                   
                    alert("Seleccione una Applicación");
                    document.getElementById("xApp").focus();
                    return false;
                }*/
                // else
                 
                    
                    $.ajax(
                         {
                             type:'POST',
                             url: 'php/tabla_reportes.php',
                             data: datos,
                             beforeSend:function()
                             {
                                 $('#tabla_reportes').html ('<center><img src="img/cargar.gif"></center>');

                             } 
                         })

                         .done(function(datos)
                         {
                                  $('#tabla_reportes').html(datos);

                         })    
                     .fail(function()
                     {
                                  alert('Error');
                     });
     
                }
            
            
            function deshabilita ()
            {
                console.log("Entro");
               
                var checkfecha = ($("#checkfecha").prop("checked"))?1:0;
                 console.log(checkfecha);
                if(checkfecha==1){
                    

                  $("#xFechaFinal").removeAttr("disabled");
                  

                   }

               else {
                    $("#xFechaFinal").attr("disabled","disabled");
               }
            }
           
            function seleccion(id,iduser,idsistema,idaplicacion,idestado)
            {
                
           
            var fecha_reporte= document.getElementById(id).cells[2].innerHTML;
            var ruta= "modificarReporte.php?id="+ id + "&iduser=" + iduser
            +"&fecha_reporte=" + fecha_reporte + "&idestado=" + idestado + 
            "&idsistema=" + idsistema +"&idaplicacion=" + idaplicacion;
            location.href = ruta;
            
            }
            
            function  limpiar()

                {
                  if($("#xUsuario").attr("disabled") != 'disabled'){
                      
                   $("#xUsuario").val(0); 
                }
                    var xUsuario = $("#xUsuario").val();
                    var xFechaInicial = $("#xFechaInicial").val("");
                    var xFechaFinal = ($("#checkfecha").prop("checked",false)) ? $("#xFechaFinal").val(0) : 0;
                    var xEstado = $("#xEstado").val(0);
                    var xLugar = $("#xLugar").val(-1);
                    var xSistema = $("#xSistema").val(0);
                    var xApp = $("#xApp").val(0);
                    
                    $("#xFechaFinal").attr("disabled","disabled");
                     //$('#checkboxRed1').prop( "checked", false);
                    
                    var datos_limpiar = "&xUsuario=" + xUsuario
                            + "&xFechaInicial=" + xFechaInicial
                            + "&xFechaFinal=" + xFechaFinal
                            + "&xEstado=" + xEstado
                            + "&xLugar=" + xLugar
                            + "&xSistema=" + xSistema
                            + "&xApp=" + xApp;



                    $.ajax(
                            {
                                type: 'POST',
                                url: 'php/tabla_reportes.php',
                                data: datos_limpiar,
                                beforeSend: function ()
                                {
                                    $('#tabla_reportes').html('<center><img src="img/cargar.gif"></center>');

                                }
                            })

                            .done(function (datos)
                            {
                                $('#tabla_reportes').html(datos);

                            })
                            .fail(function ()
                            {
                                alert('Error');
                            });
                }
				
				function recargasesion()
            {
                var variable=1;
                var url='recarga.php';                                        
                if(x<=17) //despues de 180 mins cerrara sesion
                {
                  $.ajax({
               
                    type: 'POST',
                    url: url,
                    data: variable,
                    success: function(respuesta)
                    {
                        clearTimeout(recar); 
                        recar=setTimeout(recargasesion,600000);
                        x++;
                        console.log('reinicia: '+x);
                    },
                    error:function()
                    {
                       clearTimeout(recar);   
                       console.log("no se pudo");
                    }
               
                  });
                }
                else
                {
                  if($(".fa-lock").length)
                  {  
                    window.location="login/cerrar.php";
                  }
                }
                
                
            }
            
           
                          
        </script>
        
    </head>
    <body>
        
         <div id="seleccion">
             
             <table>
                 
                        <tr>
                         <!-- <td><strong># Reporte:</strong></td>-->
                          <td class="col-lg-2"><strong>Asignado a:</strong></td>
                          <td class="col-lg-1"><strong>Fecha Inicial:</strong></td>
                          <td class="col-lg-1">
                              <label class="checkbox-inline" style="margin-top: -5px; margin-left: -3px" >
                                  <?php
                                    $checado="checked";
                                    if($filtro8 == 0)
                                        $checado="";
                                    echo '<input title="Activar rango de fecha" type="checkbox" id="checkfecha" name="checkfecha" onclick="deshabilita();"'.$checado.'>';
                                  ?>
                              </label><strong>Fecha Final:</strong>
                          </td>
                          <td class="col-lg-2"><strong>Estado:</strong></td>
                          <td class="col-lg-2"><strong>Lugar:</strong></td>
                          <td class="col-lg-2"><strong>Sistema:</strong></td>
                          <td class="col-lg-2"><strong>Aplicación:</strong></td>
                          
                          
                        </tr>

                        <tr>
                            <!--<td>
                                <input type="text" class="form-control"
                                       placeholder="# Reporte..." 
                                        id = "xReporte" name="xReporte"/> 
                            </td>-->
                            <td class="small"> 
                                 <?php 
                                          //$admin=$_SESSION['nxAdmin'];
                                          //if($admin == 1)
                                          
                                                echo '<select class="form-control input-sm" id="xUsuario" name="xUsuario">';
                                                echo '<option value="0">--TODOS--</option>';
                                             
                                                $sql= ("SELECT ID, NOMBRE 
                                                        FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS
                                                        WHERE SOPORTE =1
                                                        ORDER BY NOMBRE ASC");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {   if($filtro1 == $row['ID'])
                                                    {
                                                      echo"<option value='".$row['ID']."' selected>".$row['NOMBRE']."</option>";
                                                    }
                                                    else
                                                    {
                                                      echo"<option value='".$row['ID']."' >".$row['NOMBRE']."</option>";
                                                    }
                                                }
                                          
                                         /* else
                                          {
                                               echo '<select class="form-control input-sm" id="xUsuario" name="CboAsignado" required  disabled="true">';
                                              echo '<option value="'.$_SESSION['xid_valido'].'">'.($_SESSION['nxUsuario']).'</option>';
                                          }*/
                                        ?>
                                    </select> 
                            </td>
                            
                            <td class="small"><?php echo '<input class="form-control input-sm" type="date" name="xFechaInicial"
                                        id="xFechaInicial"  value="'.$filtro2.'">'; ?>
                            </td>
                            
                             <td class="small"> 
                                 <?php  $habilitado=" ";
                                    if($filtro8 == 0)
                                        $habilitado='disabled="disabled"';
                                    echo '<input class="form-control input-sm" type="date" name="xFechaFinal" id="xFechaFinal"'. $habilitado.' value="'.$filtro3.'" > '; 
                                 ?>
                            </td>
                            
                            <td class="small"> <select class="form-control input-sm" id="xEstado" name="xEstado" >
                                        <option value="0">--TODOS--</option>
                                        
                                        <?php      
                                                $sql= ("SELECT * FROM ".$nom_bd.".CAT_ESTADOS_REPORTE
                                                        ORDER BY ID_ESTADO_REPORTE ASC");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                    if($filtro4 == $row['ID_ESTADO_REPORTE'])
                                                    {
                                                      echo"<option value='".$row["ID_ESTADO_REPORTE"]."'selected>".$row["ESTADO_REPORTE"]."</option>";
                                                    } 
                                                    else 
                                                    {
                                                      echo"<option value='".$row["ID_ESTADO_REPORTE"]."'>".$row["ESTADO_REPORTE"]."</option>";
                                                    }
                                                }
                                        ?>
                                 </select> 
                            </td> 
                            
                            <td class="small"> <select class="form-control input-sm" id = "xLugar" name="xLugar"> 
                                 <option value="-1">--TODOS--</option>
                                        <?php      
                                                $sql= ("SELECT * FROM ".$nom_bd.".CAT_UBICACIONES 
                                                       ORDER BY NOMBRE ASC" );
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                    if($filtro5 == $row['ID_UBICACION'])
                                                    {
                                                      echo"<option value='".$row['ID_UBICACION']."' selected>".$row['NOMBRE']."</option>";
                                                    } 
                                                    else
                                                    {
                                                      echo"<option value='".$row['ID_UBICACION']."'>".$row['NOMBRE']."</option>";
                                                    }
                                                }
                                        ?>
                                
                                </select> 
                            </td>
                            
                            <td class="small"> <select class="form-control input-sm" id = "xSistema" name="xSistema"> 
                                 <option value="0">--TODOS--</option>
                                        <?php      
                                                $sql= ("SELECT ID_SISTEMA, NOMBRE_SISTEMA FROM ".$nom_bd.".CAT_SISTEMAS_CABS");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                    if($filtro6 == $row['ID_SISTEMA'])
                                                    {
                                                       echo"<option value='".$row['ID_SISTEMA']."' selected>".$row['NOMBRE_SISTEMA']."</option>";
                                                    } 
                                                    else
                                                    {
                                                       echo"<option value='".$row['ID_SISTEMA']."'>".$row['NOMBRE_SISTEMA']."</option>";
                                                    }
                                               
                                                }
                                        ?>
                                
                                </select> 
                            </td>
                                
                            <td class="small"> <select class="form-control input-sm" id = "xApp" name="xApp"> 
                                    <option value="0">--TODOS--</option>
                                     <?php      
                                         if ($filtro6>0){
                                             
                                        
                                                $sql= ("SELECT ID_APP, NOMBRE_APP, TIPO_UBICACION 
                                                        FROM  ".$nom_bd.".CAT_APP_CABS 
                                                        WHERE ID_SISTEMA ='$filtro6' ORDER BY ID_APP ASC");
                                                    $resultado = oci_parse($conn, $sql);
                                                    oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                    if($filtro7 == $row['ID_APP'])
                                                    {
                                                       echo"<option value='".$row['ID_APP']."' selected>".$row['NOMBRE_APP']."</option>";
                                                    } 
                                                    else
                                                    {
                                                        echo"<option value='".$row['ID_APP']."' >".$row['NOMBRE_APP']."</option>";
                                                    }
                                               
                                                }
                                         }
                                        ?>
                                
                                </select> 
                            </td>
                                
                            <td class="small">  <button id="boton" name= "boton" onclick="buscarReporte();" type="button" class="btn " title="Buscar">
                                    <i class=" icono izquierda fa fa-search">
                                    </i> </button>  
                            </td>
                            
                            <td class="small">  <button id="boton" name= "boton" onclick="limpiar();" type="button" class="btn " title="Limpiar">
                                <i class=" icono izquierda fa fa-eraser">
                                </i> </button>  
                        </td>
                        </tr>

                </table>  
         </div>
        
        
        <div id="tabla_reportes">  
            <?php
            //$admin=$_SESSION['nxAdmin'];
            $sql_filter="";
           // if(!isset($_SESSION["xFiltro"]))
              
               /* $sql="SELECT A.ID_REPORTE,A.ID_USUARIO_ASIGNADO AS ID_USER, 
                      A.ID_SISTEMA, A.ID_APP, B.NOMBRE,
                      TO_CHAR(A.FECHA_HORA_ALTA,'DD/MM/YYYY HH24:MI:SS') AS FECHA_HORA_ALTA, 
                      C.NOMBRE_SISTEMA, D.NOMBRE_APP, E.NOMBRE AS LUGAR,
                      G.ESTADO_REPORTE,
                      A.RED_1,
                      A.RED_7,
                      A.RED_40,
                      A.RED_AL,
                      A.RED_1_1,
                      A.RED_1_2,
                      A.RED_7_PUBLIMAX,
                      A.REVISADO,
                      H.PROBLEMA
                      

                       FROM ".$nom_bd.".REPORTES_CABS A, ".$nom_bd.".USUARIOS_SOPORTE_CABS B, 
                       ".$nom_bd.".CAT_SISTEMAS_CABS C, ".$nom_bd.".CAT_APP_CABS D,
                       ".$nom_bd.".CAT_UBICACIONES E, ".$nom_bd.".CAT_RELACION_UBICACION F,
                       ".$nom_bd.".CAT_ESTADOS_REPORTE G, ".$nom_bd.".CAT_PROBLEMAS_CABS H
                       
                       WHERE B.ID  = A.ID_USUARIO_ASIGNADO AND ";
                
                    /*if($admin != 1 )
                    {
                        $sql.="A.ID_USUARIO_ASIGNADO = ".$_SESSION['xid_valido']." AND ";
                    }*/

                      /*$sql.="C.ID_SISTEMA  = A.ID_SISTEMA AND 
                           D.ID_APP  = A.ID_APP AND 
                           F.ID_UBICACION=A.ID_UBICACION AND 
                           A.ID_ESTADO_REPORTE = G.ID_ESTADO_REPORTE AND
                           E.ID_UBICACION=F.ID_UBICACION AND 
                           F.TIPO_UBICACION=A.TIPO_UBICACION AND
                           H.ID_PROBLEMA = A.ID_PROBLEMA AND
                           A.ID_REPORTE BETWEEN ".$inicio_semana." AND ".$fin_semana."
                           ORDER BY A.ID_REPORTE DESC";*/
            /*}
            else
            {*/
                $sql="SELECT A.ID_REPORTE,A.ID_USUARIO_ASIGNADO AS ID_USER, A.ID_SISTEMA, A.ID_APP,
                      B.NOMBRE,TO_CHAR(A.FECHA_HORA_ALTA,'DD/MM/YYYY HH24:MI:SS') AS FECHA_HORA_ALTA, 
                      C.NOMBRE_SISTEMA, D.NOMBRE_APP, E.NOMBRE AS LUGAR, G.ESTADO_REPORTE,
                      A.RED_1,
                      A.RED_7,
                      A.RED_40,
                      A.RED_AL,
                      A.RED_1_1,
                      A.RED_1_2,
                      A.RED_7_PUBLIMAX,
                      A.REVISADO,
                      H.PROBLEMA
                      

                 FROM ".$nom_bd.".REPORTES_CABS A, ".$nom_bd.".USUARIOS_SOPORTE_CABS B, ".$nom_bd.".CAT_SISTEMAS_CABS C, 
                      ".$nom_bd.".CAT_APP_CABS D,
                      ".$nom_bd.".CAT_UBICACIONES E, ".$nom_bd.".CAT_RELACION_UBICACION F, ".$nom_bd.".CAT_ESTADOS_REPORTE G,
                      ".$nom_bd.".CAT_PROBLEMAS_CABS H

                 WHERE B.ID  = A.ID_USUARIO_ASIGNADO AND 
                 C.ID_SISTEMA  = A.ID_SISTEMA AND
                 F.ID_UBICACION = A.ID_UBICACION AND 
                 A.ID_ESTADO_REPORTE = G.ID_ESTADO_REPORTE AND
                 F.TIPO_UBICACION = A.TIPO_UBICACION AND        
                 E.ID_UBICACION=F.ID_UBICACION AND 
                 D.ID_APP  = A.ID_APP AND
                 H.ID_PROBLEMA = A.ID_PROBLEMA";
                
            if($filtro1!=0 )
            {        
                if($sql_filter=="")
                {
                    $sql_filter=" A.ID_USUARIO_ASIGNADO = ".$filtro1;    
                }else {
                    $sql_filter.=" AND A.ID_USUARIO_ASIGNADO = ".$filtro1;    
                }
            }


            if($filtro2!=0 && $filtro3!=0)
            {   
                $fechainicial = explode("-", $filtro2);
                $fechafinal = explode("-", $filtro3);
                $newDate=$fechainicial[2]."/".$fechainicial[1]."/".$fechainicial[0];
                $newDate2=$fechafinal[2]."/".$fechafinal[1]."/".$fechafinal[0];
                if($sql_filter=="")
                {
                    $sql_filter=" A.FECHA_HORA_ALTA >= TO_DATE('".$newDate." 00:00:01','DD/MM/YYYY HH24:MI:SS') AND"
                            ." A.FECHA_HORA_ALTA <= TO_DATE('".$newDate2." 23:59:59','DD/MM/YYYY HH24:MI:SS')";    
                }else {
                    $sql_filter.=" AND ( A.FECHA_HORA_ALTA >= TO_DATE('".$newDate." 00:00:01','DD/MM/YYYY HH24:MI:SS') AND"
                            ." A.FECHA_HORA_ALTA <= TO_DATE('".$newDate2." 23:59:59','DD/MM/YYYY HH24:MI:SS'))";   
                }
            }

            if($filtro4!=0)
            {        
                if($sql_filter=="")
                {
                    $sql_filter=" A.ID_ESTADO_REPORTE = ".$filtro4;    
                }else {
                    $sql_filter.=" AND A.ID_ESTADO_REPORTE = ".$filtro4;    
                }
            }

            if($filtro5 >-1)
            {        
                if($sql_filter=="")
                {
                    $sql_filter=" A.ID_UBICACION = ".$filtro5;    
                }else {
                    $sql_filter.=" AND A.ID_UBICACION = ".$filtro5;    
                }
            }


            if($filtro6!=0)
            {
                if($sql_filter=="")
                {
                    $sql_filter=" A.ID_SISTEMA = ".$filtro6;    
                }else {
                    $sql_filter.=" AND A.ID_SISTEMA = ".$filtro6;    
                }

            }

            if($filtro7!=0)
            {
                if($sql_filter=="")
                {
                    $sql_filter="A.ID_APP = ".$filtro7;    
                }else {
                    $sql_filter.=" AND A.ID_APP = ".$filtro7;    
                }

            }
            if($sql_filter!="")
                $sql_filter=" AND (".$sql_filter.") ";
            $sql.=$sql_filter." ORDER BY A.ID_REPORTE DESC ";
                
            
            Bitacora("query filtro: ". $sql, 0);
                 $resultado = oci_parse($conn, $sql);

                oci_execute($resultado);

                 echo "<table id='tabla_reportes' border='1' 
                        class='table table-hover'>
                      <thead>

                                            <tr>
                                                    <th ># REPORTE</th>
                                                    <th >USUARIO ASIGNADO</th>
                                                    <th >FECHA SOLICITUD</th>
                                                    <th >ESTADO </th>
                                                    <th >SISTEMA</th>
                                                    <th >APLICACION</th>
                                                    <th >PROBLEMA</th>
                                                    <th >REDES</th>
                                                    <th >LUGAR</th>

                                            </tr> 
                       </thead>";

                while ($tabla_reportes = oci_fetch_array($resultado, 
                                         OCI_ASSOC+OCI_RETURN_NULLS)) 


                        {
                            $iduser=$tabla_reportes['ID_USER'];
                            $fecha=$tabla_reportes['FECHA_HORA_ALTA'];
                            $idsistema=$tabla_reportes['ID_SISTEMA'];
                            $idapp=$tabla_reportes['ID_APP'];                           
                                 echo  "<tr id='".$tabla_reportes['ID_REPORTE']."' 
                                        class='selectable'                         
                                        onclick='seleccion(id, ".$iduser.", 
                                         ".$idsistema.", ".$idapp.")' 
                                        >";
                            $cadena="";
                            $cadena=($tabla_reportes['RED_1']==1)?"1":""; 
                            
                            $aux=($tabla_reportes['RED_7']==1)?"7":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            $aux=($tabla_reportes['RED_40']==1)?"40":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            
                            $aux=($tabla_reportes['RED_AL']==1)?"A+":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            
                            $aux=($tabla_reportes['RED_1_1']==1)?"1-1 Hr":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            
                            
                            $aux=($tabla_reportes['RED_1_2']==1)?"1-2 Hr":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                           
                            $aux=($tabla_reportes['RED_7_PUBLIMAX']==1)?"7_Publimax":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                               
                                $color= estados($tabla_reportes['ESTADO_REPORTE']);
                                $color2= estados($tabla_reportes['REVISADO']);
                                echo    "<td class='input-sm' ".$color2.">".$tabla_reportes['ID_REPORTE']."</td>
                                        <td class='input-sm' >".$tabla_reportes['NOMBRE']."</td>
                                        <td class='input-sm' >".$tabla_reportes['FECHA_HORA_ALTA']."</td>
                                        <td class='input-sm' ".$color.">".$tabla_reportes['ESTADO_REPORTE']."</td>  
                                        <td class='input-sm' >".$tabla_reportes['NOMBRE_SISTEMA']."</td>
                                        <td class='input-sm' >".$tabla_reportes['NOMBRE_APP']."</td>
                                        <td class='input-sm' >".$tabla_reportes['PROBLEMA']." </td>
                                        <td class='input-sm' >".$cadena."</td>
                                        <td class='input-sm' >".$tabla_reportes['LUGAR']."</td>  

                                        </tr>"; 
                        }
                            $total=oci_num_rows($resultado);
                    echo " <h5><b> Reportes: ".$total."</h5></b>
                           <br>";     

                    echo "</table>\n";

                    if($conn!=null && $conn!=false)
                    oci_close($conn);
                    ?>
        </div>
        
     
    </body>

</html>

<?php
}
else 
{
  header('Location: login/loginind.php');
}

?>