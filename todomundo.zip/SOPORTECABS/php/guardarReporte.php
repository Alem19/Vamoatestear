 <?php

    require_once 'conexion.php';
    require_once ('bitacora.php');
    date_default_timezone_set('America/Mexico_City');
   
    $fecha_alta = filter_input(INPUT_POST,'fecha_alta');
     $a= explode("T", $fecha_alta);
     $hora = $a[1].":00";
     $f= explode("-", $a[0]);
     
     $date=$f[2]."/".$f[1]."/".$f[0];
     $date2=($f[0]-2000).$f[1].$f[2];
    
    
    $max_id=0;
    //$date=date("d/m/y");
    $query="SELECT MAX(ID_REPORTE) FROM ".$nom_bd.".REPORTES_CABS "
          ."WHERE FECHA_HORA_ALTA BETWEEN TO_DATE('".$date."', 'DD/MM/YY') AND "
          ."TO_DATE('".$date." 23:59:59', 'DD/MM/YY HH24:MI:SS')";
    
    Bitacora($query,0);
    
   /* $conn = oci_connect(USERLOGS, PASSLOGS, BDBLOQ,'AL32UTF8');
    if (!$conn) 
        {
        $e = oci_error();
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
        }*/
    
    
    $res = oci_parse($conn, $query);
    oci_execute($res);
    
    
    
    if($res)
    {
        $dato=oci_fetch_array($res,OCI_ASSOC+OCI_RETURN_NULLS);
        Bitacora("Paso",0);
        if(!isset($dato['MAX(ID_REPORTE)']) || $dato['MAX(ID_REPORTE)']=="")
        {

          $max_id=$date2. ajuste("1",4);
          Bitacora("N:".$max_id,0);
        }else{
          $max_id=$dato['MAX(ID_REPORTE)']+1;
          Bitacora("E:".$max_id,0);
        }
    
    

   



         //Variables
         $sistema = filter_input(INPUT_POST,'CboSistema');
         $app = filter_input(INPUT_POST,'CboApp');
         $lugar = filter_input(INPUT_POST,'CboLugar');
         $red1 = filter_input(INPUT_POST,'checkboxRed1');
         $red7 = filter_input(INPUT_POST,'checkboxRed7');
         $red40 = filter_input(INPUT_POST,'checkboxRed40');
         $redAL = filter_input(INPUT_POST,'checkboxRedAL');
         $red11 = filter_input(INPUT_POST,'checkboxRed1-1');
         $red12 = filter_input(INPUT_POST,'checkboxRed1-2');       
         $redPublimax = filter_input(INPUT_POST,'Red7Publimax');       
         $userCreo =filter_input(INPUT_POST, 'CboUserCreo');
         $nomAsignado = filter_input(INPUT_POST,'CboAsignado');
         
         $estadoReporte = filter_input(INPUT_POST,'CboEstado');
         $id_problema = filter_input(INPUT_POST,'CboProblema');
         $id_subcat = filter_input(INPUT_POST,'CboSubCat');
         $id_diagnostico = filter_input(INPUT_POST,'CboDiagnostico');
         $id_actividad = filter_input(INPUT_POST, 'CboActividad');
         $id_solucion = filter_input(INPUT_POST, 'CboSolucion');
         $viaNot = filter_input(INPUT_POST,'CboViaNot');
         $notificadoPor = convierte_carcter(filter_input(INPUT_POST,'notificadoPor'));
         $radioRep = filter_input(INPUT_POST,'radioRep');
         $reportadoA = convierte_carcter(filter_input(INPUT_POST,'reportadoA'));
         $radioEsc = filter_input(INPUT_POST,'radioEsc');
         $escaladoA = convierte_carcter(filter_input(INPUT_POST,'escaladoA'));

         $textReporte = convierte_carcter(filter_input(INPUT_POST,'textReporte'));
         $textDiagnostico = convierte_carcter(filter_input(INPUT_POST,'textDiagnostico'));
         $textActividad = convierte_carcter(filter_input(INPUT_POST,'textActividad'));
         $textSolucion = convierte_carcter(filter_input(INPUT_POST,'textSolucion'));
         
         $tipo_ubicacion = filter_input(INPUT_POST,'tipo_1');
         $revisado = filter_input(INPUT_POST,'revisado'); 
         



         date_default_timezone_set('America/Mexico_City');

         //$fecha=date('d/m/y')." ".date('H:i:s');
         $fecha=$date." ".$hora;
         

         $id_reporte =$max_id;

         $sql="INSERT INTO REPORTES_CABS (ID_REPORTE,ID_SISTEMA, ID_APP, ID_UBICACION, 
                                          RED_1, RED_7, RED_40, RED_AL,
                                          RED_1_1, RED_1_2, RED_7_PUBLIMAX,
                                          FECHA_HORA_ALTA, 
                                          ID_USUARIO_REGISTRO, 
                                          ID_USUARIO_ASIGNADO,
                                          ID_USUARIO_MODIFICO,
                                          ID_ESTADO_REPORTE,
                                          ID_NOTIFICACION, NOTIFICADO_POR, REPORTADO, REPORTADO_A,
                                          ESCALADO, ESCALADO_A, REPORTE, DIAGNOSTICO, ACTIVIDAD, SOLUCION, TIPO_UBICACION,
                                          REVISADO, ID_PROBLEMA, ID_SUBCATEGORIA, ID_DIAGNOSTICO, ID_ACTIVIDAD, ID_SOLUCION )
                                          VALUES ($id_reporte,$sistema, $app, $lugar, 
                                                  $red1, $red7, $red40,$redAL,
                                                  $red11, $red12,$redPublimax,
                                                  TO_DATE('$fecha','DD/MM/YY HH24:MI:SS'), 
                                                  $userCreo, 
                                                  $nomAsignado, 
                                                  $userCreo,
                                                  $estadoReporte, $viaNot,'$notificadoPor', 
                                                  $radioRep, '$reportadoA', 
                                                  $radioEsc, '$escaladoA', '$textReporte', '$textDiagnostico', 
                                                  '$textActividad', '$textSolucion', $tipo_ubicacion, $revisado, $id_problema, $id_subcat, 
                                                  $id_diagnostico, $id_actividad, $id_solucion )";


         Bitacora($sql,0);
         $resultado = oci_parse($conn, $sql);
         oci_execute($resultado);

         if($resultado)
             {     
               $sql= "INSERT INTO REPORTES_CABS_HISTORICO
						(ID_REPORTE, ID_SISTEMA, ID_APP, ID_UBICACION, 
                                                RED_1, RED_7, RED_40, RED_AL, 
                                                RED_1_1, RED_1_2, RED_7_PUBLIMAX,
						FECHA_HORA_ALTA, FECHA_HORA_MODIF, 
                                                ID_USUARIO_REGISTRO,
						ID_USUARIO_ASIGNADO, 
                                                ID_USUARIO_MODIFICO,
                                                ID_ESTADO_REPORTE, ID_NOTIFICACION,
						NOTIFICADO_POR, REPORTADO, REPORTADO_A, ESCALADO, ESCALADO_A, 
                                                REPORTE,DIAGNOSTICO, ACTIVIDAD, SOLUCION, TIPO_UBICACION, REVISADO,ID_PROBLEMA,
                                                ID_SUBCATEGORIA, ID_DIAGNOSTICO, ID_ACTIVIDAD, ID_SOLUCION)
        
						VALUES($id_reporte, $sistema, $app,$lugar, 
                                                        $red1, $red7, $red40, $redAL,
                                                        $red11, $red12,$redPublimax,
							TO_DATE('$fecha','DD/MM/YY HH24:MI:SS'),
							TO_DATE('$fecha','DD/MM/YY HH24:MI:SS'), 
							$userCreo, 
                                                        $nomAsignado,$userCreo, 
							$estadoReporte, $viaNot, '$notificadoPor',
							$radioRep, '$reportadoA', $radioEsc, '$escaladoA',
							'$textReporte', '$textDiagnostico', '$textActividad',
							'$textSolucion',$tipo_ubicacion, $revisado, $id_problema, $id_subcat,
                                                        $id_diagnostico, $id_actividad, $id_solucion )";
                 
               $resultado = oci_parse($conn, $sql);
               oci_execute($resultado);
               

                 echo "El reporte ha sido generado #$id_reporte";
                 
                 
             }
             else
             {

                 echo "No se pudo generar el reporte";
             }
}else {
   echo "No se pudo generar el reporte";
   Bitacora("No se pudo",0);
}
