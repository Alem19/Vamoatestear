<?php
require_once ('bitacora.php');
require_once 'conexion.php';
date_default_timezone_set('America/Mexico_City');

$red_1 = filter_input(INPUT_POST,'checkboxRed1');
$red_7 = filter_input(INPUT_POST,'checkboxRed7');
$red_40 = filter_input(INPUT_POST,'checkboxRed40');
$red_AL = filter_input(INPUT_POST,'checkboxRedAL');
$red_1_1 = filter_input(INPUT_POST,'checkboxRed11');
$red_1_2 = filter_input(INPUT_POST,'checkboxRed12');
$red_7_publimax = filter_input(INPUT_POST,'checkboxRedpublimax');


$user_actualizo = filter_input(INPUT_POST,'CboActualizo');
$estado_reporte = filter_input(INPUT_POST,'CboEstado');

$via_notificacion  = filter_input(INPUT_POST,'CboViaNot');
$notificado_por = convierte_carcter(filter_input(INPUT_POST,'notificadoPor'));
$radio_reportado = filter_input(INPUT_POST,'radioRep');
$reportado_a = convierte_carcter(filter_input(INPUT_POST,'reportadoA'));
$radio_escalado = filter_input(INPUT_POST,'radioEsc');
$escalado_con = convierte_carcter(filter_input(INPUT_POST,'escaladoA'));

$texto_reporte = filter_input(INPUT_POST,'textReporte');
$texto_diagnostico = convierte_carcter(filter_input(INPUT_POST,'textDiagnostico'));
$texto_diagnostico = str_replace("'", '"', $texto_diagnostico );
$texto_actividad = convierte_carcter(filter_input(INPUT_POST,'textActividad'));
$texto_actividad = str_replace("'", '"', $texto_actividad);
$texto_solucion = convierte_carcter(filter_input(INPUT_POST,'textSolucion'));
$texto_solucion = str_replace("'", '"', $texto_solucion);
$revisar = filter_input(INPUT_POST,'revisado');
$idDiagnostico = filter_input(INPUT_POST,'CboDiagnostico');
$idActividad = filter_input(INPUT_POST,'CboActividad');
$idSolucion = filter_input(INPUT_POST,'CboSolucion');
$idProblema = filter_input(INPUT_POST,'CboProblema');
$idSucategoria = filter_input(INPUT_POST,'CboSubCat');

$fecha_modif=date('d/m/y')." ".date('H:i:s');


$id_Reporte = (is_numeric(trim($_POST['idReporte'])))?Trim($_POST['idReporte']):0;

$fecha_reporte = filter_input(INPUT_POST,'FHSolicitud');
$sistema = filter_input(INPUT_POST,'CboSistema');
$aplicacion = filter_input(INPUT_POST,'CboApp');
$user_asignado = filter_input(INPUT_POST,'CboAsignado');
$user_creo= filter_input(INPUT_POST,'creadopor');
$lugar= filter_input(INPUT_POST,'lugar');
$dLugar= explode("-", $lugar);
$ret="";

/*$conn = oci_connect(USERLOGS, PASSLOGS,BDBLOQ,'AL32UTF8');
    if (!$conn) 
        {
        $e = oci_error($conn);
        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
        }*/
        
Bitacora($_POST['idReporte'],0);
Bitacora('ES ESTE:'.$idProblema, 0);

$sql=" UPDATE REPORTES_CABS 
       SET ID_NOTIFICACION = $via_notificacion, NOTIFICADO_POR = '$notificado_por', 
       REPORTADO = $radio_reportado, REPORTADO_A = '$reportado_a',
       ESCALADO = $radio_escalado, ESCALADO_A = '$escalado_con',
       ID_ESTADO_REPORTE = $estado_reporte, 
       ID_USUARIO_MODIFICO = $user_actualizo,
       ID_USUARIO_ASIGNADO =$user_asignado,
       RED_1 = $red_1, RED_7 = $red_7, RED_40 = $red_40, RED_AL = $red_AL,
       RED_1_1 = $red_1_1, RED_1_2 = $red_1_2, RED_7_PUBLIMAX = $red_7_publimax,
       FECHA_HORA_MODIF = TO_DATE('$fecha_modif','DD/MM/YY HH24:MI:SS'), 
       REPORTE = '$texto_reporte', DIAGNOSTICO = '$texto_diagnostico', 
       ACTIVIDAD = '$texto_actividad', SOLUCION = '$texto_solucion', REVISADO =$revisar,
       ID_PROBLEMA = $idProblema, ID_SUBCATEGORIA = $idSucategoria,
       ID_DIAGNOSTICO = $idDiagnostico, ID_ACTIVIDAD = $idActividad, 
       ID_SOLUCION = $idSolucion
       WHERE ID_REPORTE= $id_Reporte";


        
Bitacora($sql,0);

$res_modif = oci_parse($conn, $sql);

if(oci_execute($res_modif,OCI_NO_AUTO_COMMIT))
{
  // Acá va todo lo del insert
    $sql= "INSERT INTO  REPORTES_CABS_HISTORICO
       (ID_REPORTE, ID_SISTEMA, ID_APP, RED_1, RED_7, RED_40, RED_AL, 
        RED_1_1, RED_1_2, RED_7_PUBLIMAX,
        FECHA_HORA_ALTA, FECHA_HORA_MODIF, 
        ID_USUARIO_ASIGNADO,
        ID_USUARIO_REGISTRO,
        ID_USUARIO_MODIFICO, 
        ID_ESTADO_REPORTE, ID_NOTIFICACION, NOTIFICADO_POR, REPORTADO, 
        REPORTADO_A, ESCALADO, ESCALADO_A, REPORTE,
        DIAGNOSTICO, ACTIVIDAD, SOLUCION,ID_UBICACION,TIPO_UBICACION,REVISADO,
        ID_PROBLEMA, ID_SUBCATEGORIA,ID_DIAGNOSTICO, ID_ACTIVIDAD, ID_SOLUCION)
        
        VALUES($id_Reporte, $sistema, $aplicacion, $red_1, $red_7, $red_40, $red_AL,
               $red_1_1, $red_1_2, $red_7_publimax,
               TO_DATE('$fecha_reporte','DD/MM/YY HH24:MI:SS'),
               TO_DATE('$fecha_modif','DD/MM/YY HH24:MI:SS'), 
               $user_asignado,
               $user_creo, 
               $user_actualizo,
               $estado_reporte, $via_notificacion, '$notificado_por',
               $radio_reportado, '$reportado_a', $radio_escalado, '$escalado_con',
               '$texto_reporte', '$texto_diagnostico', '$texto_actividad',
               '$texto_solucion',$dLugar[0],$dLugar[1],$revisar, 
                $idProblema, $idSucategoria,
                $idDiagnostico,
                $idActividad, $idSolucion)"; 
    
    Bitacora("Ins UP".$sql,0);
$res_modif = oci_parse($conn, $sql);

if(oci_execute($res_modif, OCI_NO_AUTO_COMMIT))
{
    $red_modif = oci_commit($conn);
    $ret="Cambios guardados";
}else
{
   $e = oci_error($conn);  
   Bitacora($e['message'],0);
   oci_rollback($conn);
   $ret="No se guardo";
}

    
    
}else{
   Bitacora("Paso 1", 0);
   $e = oci_error($conn);        
   Bitacora($e['message'],0);
   $ret="No se guardaron cambios";  
}        
echo $ret;


