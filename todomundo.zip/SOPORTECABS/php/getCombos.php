<?php

include ("conexion.php");

$id_sistema = (isset($_POST['id_sistema']) && is_numeric($_POST['id_sistema']))?$_POST['id_sistema']:0;

$tipo_ubicacion =(isset($_POST['tipo_ubicacion']))?$_POST['tipo_ubicacion']:"";

$origen =(isset($_POST['origen']))?$_POST['origen']:0;


$dvnot = (isset($_POST['dvnot']) && is_numeric($_POST['dvnot']))?$_POST['dvnot']:0;

if($tipo_ubicacion=="" && $id_sistema>0)
{
    $sql = ("SELECT ID_APP, NOMBRE_APP, TIPO_UBICACION FROM ".$nom_bd.".CAT_APP_CABS 
        WHERE ID_SISTEMA ='$id_sistema' ORDER BY NOMBRE_APP ASC");


    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
    
    
    if($origen==1)
        $html = "<option value='0'>--TODOS--</option>";  
    else
        $html = "<option value='0'>--SELECCIONE--</option>";
    while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) {
    $selec="";
        if($id_sistema==3)
            $selec="selected";
        $html.= '<option value= "'.$row["ID_APP"].'-'.$row["TIPO_UBICACION"].'"'.$selec.' >'.$row["NOMBRE_APP"].'</option>';
    }
   
    echo $html;
}


if($tipo_ubicacion!="")
{
   $sql="SELECT B.ID_UBICACION AS ID, A.NOMBRE FROM ".$nom_bd.".CAT_UBICACIONES A, ".$nom_bd.".CAT_RELACION_UBICACION B "
        ."WHERE B.TIPO_UBICACION=".$tipo_ubicacion." AND B.ID_UBICACION=A.ID_UBICACION"
       ." ORDER BY NOMBRE";
    
   
   $resultado = oci_parse($conn, $sql);
   oci_execute($resultado);
   
   $total=oci_num_rows($resultado);
    if($tipo_ubicacion!=3){
        $html = "<option value='0'>--SELECCIONE--</option>";
    }
   while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
   {
    
      $html.= "<option value='".$row['ID']."'>".$row['NOMBRE']."</option>";
   }   
   echo $html; 
   
}


if($dvnot != 0)
{
    $sql_notifi="SELECT ID, NOMBRE FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS
            WHERE PERFIL = 1 AND ID_GRUPO = 1
            ORDER BY NOMBRE ASC";
    
    
    $resultado = oci_parse($conn, $sql_notifi);
   oci_execute($resultado);
   
   $html = "<option value='0'>--SELECCIONE--</option>";
   
    while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) {
        
        $html.="<option value='".$row['NOMBRE']."'>".$row['NOMBRE']."</option>";
        
        
    }
     echo $html; 
}




