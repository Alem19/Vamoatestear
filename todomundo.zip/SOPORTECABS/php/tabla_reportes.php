
<?php
session_start();
include ("conexion.php");
include ("bitacora.php");

date_default_timezone_set('America/Mexico_City');

$xIdReporte = (is_numeric(filter_input(INPUT_POST, 'xReporte')))?filter_input(INPUT_POST, 'xReporte'):0;
$xUsuario = (is_numeric(filter_input(INPUT_POST, 'xUsuario')))?filter_input(INPUT_POST, 'xUsuario'):0;
$xFechaInicial = (is_null($_POST['xFechaInicial']))?0:$_POST['xFechaInicial'];
$xFechaFinal   = (is_null($_POST['xFechaFinal']))?0:$_POST['xFechaFinal'];

if($xFechaFinal==0){
    $xFechaFinal = $xFechaInicial;
} 

if($xFechaInicial==0){
    $xFechaInicial=$xFechaFinal;
}


if($xFechaInicial >0 && $xFechaFinal >0 )
{    
    $fechainicial = explode("-", $xFechaInicial);
    $fechafinal = explode("-", $xFechaFinal);
    $newDate=$fechainicial[2]."/".$fechainicial[1]."/".$fechainicial[0];
    $newDate2=$fechafinal[2]."/".$fechafinal[1]."/".$fechafinal[0];
}
else{
    $newDate=0;
    $newDate2=0;
    $fechainicial="";
    $fechafinal="";
}
$xEstado = (is_numeric(filter_input(INPUT_POST, 'xEstado')))?filter_input(INPUT_POST, 'xEstado'):0;
$xLugar = (is_numeric(filter_input(INPUT_POST,'xLugar')))?filter_input(INPUT_POST,'xLugar'):-1;
$xSistema = (is_numeric(filter_input(INPUT_POST,'xSistema')))?filter_input(INPUT_POST,'xSistema'):0;
$xApp = (is_numeric(filter_input(INPUT_POST,'xApp')))?filter_input(INPUT_POST,'xApp'):0;
$sql_filter="";
Bitacora("Datos Recibidos:".$newDate."-".$newDate2."-".$xIdReporte."-".$xUsuario."-".$xEstado."-".$xSistema."-".$xApp,0);

$sql="SELECT A.ID_REPORTE,A.ID_USUARIO_ASIGNADO AS ID_USER, A.ID_SISTEMA, A.ID_APP,
      B.NOMBRE,TO_CHAR(A.FECHA_HORA_ALTA,'DD/MM/YYYY HH24:MI:SS') AS FECHA_HORA_ALTA, 
      C.NOMBRE_SISTEMA, D.NOMBRE_APP, E.NOMBRE AS LUGAR, G.ESTADO_REPORTE,
      A.RED_1,
      A.RED_7,
      A.RED_40,
      A.RED_AL,
      A.RED_1_1,
      A.RED_1_2,
      A.RED_7_PUBLIMAX,
      A.REVISADO, 
      H.PROBLEMA

       FROM ".$nom_bd.".REPORTES_CABS A, ".$nom_bd.".USUARIOS_SOPORTE_CABS B, ".$nom_bd.".CAT_SISTEMAS_CABS C, ".$nom_bd.".CAT_APP_CABS D,
            ".$nom_bd.".CAT_UBICACIONES E, ".$nom_bd.".CAT_RELACION_UBICACION F, ".$nom_bd.".CAT_ESTADOS_REPORTE G,
            ".$nom_bd.".CAT_PROBLEMAS_CABS H

       WHERE B.ID  = A.ID_USUARIO_ASIGNADO AND 
       C.ID_SISTEMA  = A.ID_SISTEMA AND
       F.ID_UBICACION = A.ID_UBICACION AND 
       A.ID_ESTADO_REPORTE = G.ID_ESTADO_REPORTE AND
       F.TIPO_UBICACION = A.TIPO_UBICACION AND        
       E.ID_UBICACION=F.ID_UBICACION AND 
       D.ID_APP  = A.ID_APP AND
       H.ID_PROBLEMA = A.ID_PROBLEMA ";

$sql_filter="";



if($xIdReporte!=0)
{
    $sql_filter=" A.ID_REPORTE LIKE '".$xIdReporte."%' ";     
}

if($xUsuario!=0)
{        
    if($sql_filter=="")
    {
        $sql_filter=" A.ID_USUARIO_ASIGNADO = ".$xUsuario;    
    }else {
        $sql_filter.=" AND A.ID_USUARIO_ASIGNADO = ".$xUsuario;    
    }
}

  
if($xFechaInicial!=0 && $xFechaFinal!=0)
{        
    if($sql_filter=="")
    {
        $sql_filter=" A.FECHA_HORA_ALTA >= TO_DATE('".$newDate." 00:00:01','DD/MM/YYYY HH24:MI:SS') AND"
                ." A.FECHA_HORA_ALTA <= TO_DATE('".$newDate2." 23:59:59','DD/MM/YYYY HH24:MI:SS')";    
    }else {
        $sql_filter.=" AND ( A.FECHA_HORA_ALTA >= TO_DATE('".$newDate." 00:00:01','DD/MM/YYYY HH24:MI:SS') AND"
                ." A.FECHA_HORA_ALTA <= TO_DATE('".$newDate2." 23:59:59','DD/MM/YYYY HH24:MI:SS'))";   
    }
}

if($xEstado!=0)
{        
    if($sql_filter=="")
    {
        $sql_filter=" A.ID_ESTADO_REPORTE = ".$xEstado;    
    }else {
        $sql_filter.=" AND A.ID_ESTADO_REPORTE = ".$xEstado;    
    }
}

if($xLugar>-1)
{        
    if($sql_filter=="")
    {
        $sql_filter=" A.ID_UBICACION = ".$xLugar;    
    }else {
        $sql_filter.=" AND A.ID_UBICACION = ".$xLugar;    
    }
}


if($xSistema!=0)
{
    if($sql_filter=="")
    {
        $sql_filter=" A.ID_SISTEMA = ".$xSistema;    
    }else {
        $sql_filter.=" AND A.ID_SISTEMA = ".$xSistema;    
    }

}

if($xApp!=0)
{
    if($sql_filter=="")
    {
        $sql_filter="A.ID_APP = ".$xApp;    
    }else {
        $sql_filter.=" AND A.ID_APP = ".$xApp;    
    }

}
if($sql_filter!="")
    $sql_filter=" AND (".$sql_filter.") ";
$sql.=$sql_filter."  ORDER BY A.ID_REPORTE DESC ";
//inicio de variables de sesion
$rango_fechas = ($xFechaInicial!=$xFechaFinal)?1:0;
$_SESSION['xFiltro']=array($xUsuario,$xFechaInicial,$xFechaFinal,$xEstado,$xLugar,$xSistema,$xApp,$rango_fechas);
Bitacora($sql,0);
$resultado = oci_parse($conn, $sql);
    
    oci_execute($resultado);
    
     echo "<table id='tabla_reportes' border='1' class='table table-hover'>
          <thead>
          
				<tr>
					<th># REPORTE</th>
					<th>USUARIO ASIGNADO</th>
					<th>FECHA SOLICITUD</th>
                                        <th>ESTADO</th>
                                        <th>SISTEMA</th>
                                        <th>APLICACION</th>
                                        <th>PROBLEMA</th>
                                        <th>REDES</th>
                                        <th>LUGAR</th>
                                        
				</tr> 
           </thead>";
     
    while ($tabla_reportes = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
    
   
            {
                $iduser=$tabla_reportes['ID_USER'];
                $fecha=$tabla_reportes['FECHA_HORA_ALTA'];
                $idsistema=$tabla_reportes['ID_SISTEMA'];
                $idapp=$tabla_reportes['ID_APP'];
                
                
                     echo  "<tr id='".$tabla_reportes['ID_REPORTE']."' class='selectable'                         
                            onclick='seleccion(id, ".$iduser.", ".$idsistema.", ".$idapp.")' 
                            >";
                     
                                
                              
			
                   $cadena="";
                            $cadena=($tabla_reportes['RED_1']==1)?"1":""; 
                            
                            $aux=($tabla_reportes['RED_7']==1)?"7":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            $aux=($tabla_reportes['RED_40']==1)?"40":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            
                            $aux=($tabla_reportes['RED_AL']==1)?"A+":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            
                            $aux=($tabla_reportes['RED_1_1']==1)?"1-1 Hr":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            
                            
                            $aux=($tabla_reportes['RED_1_2']==1)?"1-2 Hr":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                           
                            $aux=($tabla_reportes['RED_7_PUBLIMAX']==1)?"7_Publimax":"";                            
                            if($cadena!="")
                            {
                                if($aux!="")
                                    $cadena.=",".$aux;                                
                            }else{
                                if($aux!="")
                                    $cadena=$aux;
                            }
                            
                    $color= estados($tabla_reportes['ESTADO_REPORTE']);       
                    $color2= estados($tabla_reportes['REVISADO']);
                    echo       "<td class='input-sm' ".$color2.">".$tabla_reportes['ID_REPORTE']."</td>
                                <td class='input-sm' >".$tabla_reportes['NOMBRE']."</td>
                                <td class='input-sm'>".$tabla_reportes['FECHA_HORA_ALTA']."</td>
                                <td class='input-sm' ".$color.">".$tabla_reportes['ESTADO_REPORTE']."</td>   
                                <td class='input-sm' >".$tabla_reportes['NOMBRE_SISTEMA']."</td>
                                <td class='input-sm' >".$tabla_reportes['NOMBRE_APP']."</td>
                                <td class='input-sm' >".$tabla_reportes['PROBLEMA']." </td>
                                <td class='input-sm'>".$cadena."</td>
                                <td class='input-sm'>".$tabla_reportes['LUGAR']."</td>
                            
                            </tr>"; 
            }
        
        echo " <h5><b> Reportes: ".oci_num_rows($resultado)." </h5></b>
               <br>";     
        
        echo "</table>\n";