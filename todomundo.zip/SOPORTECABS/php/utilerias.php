<?php
//---------------------------------------------------------------------------
  if(!defined('BDBLOQ'))
  {
    $can=obt_config2("NameBD3");
    define("BDBLOQ",$can);
  }
//---------------------------------------------------------------------------
  if(!defined('BDLOGS'))
  {
    $can=obt_config2("NameBD1");
    define("BDLOGS",$can);
  }
  if(!defined('USERLOGS'))
  {
    $can=obt_config2("UserBD1");
    define("USERLOGS",$can);
  }
  if(!defined('PASSLOGS'))
  {
    $can=obt_config2("PassBD1");
    define("PASSLOGS",$can);
  }
//--------------------------------------------------------------------------
  if(!defined('BDTESTIGOS'))
  {
    $can=obt_config2("NameBD2");
    define("BDTESTIGOS",$can);
  }
  if(!defined('USERTESTIGOS'))
  {
    $can=obt_config2("UserBD2");
    define("USERTESTIGOS",$can);
  }
  if(!defined('PASSTESTIGOS'))
  {
    $can=obt_config2("PassBD2");
    define("PASSTESTIGOS",$can);
  }
//--------------------------------------------------------------------------
  function obt_tam_cad($bytes)
  {
    $units = array('Bytes', 'KB', 'MB', 'GB', 'TB');

    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);

    // Uncomment one of the following alternatives
    $bytes /= (1 << (10 * $pow));

    return round($bytes, 2) . ' ' . $units[$pow];
  }
//--------------------------------------------------------------------------
    function seg_horas($seg_ini)
    {
      $horas = floor($seg_ini/3600);
      $minutos = floor(($seg_ini-($horas*3600))/60);
      $segundos = $seg_ini-($horas*3600)-($minutos*60);
      $tiempo=ajuste($horas,2).":".ajuste($minutos,2).":".ajuste($segundos,2);
      return $tiempo;
    }
//---------------------------------------------------------------------------
    function mseg_horas($mseg)
    {
      $seg_ini=$mseg/1000;
      $horas = floor($seg_ini/3600);
      $minutos = floor(($seg_ini-($horas*3600))/60);
      $segundos = $seg_ini-($horas*3600)-($minutos*60);
      $tiempo=ajuste($horas,2).":".ajuste($minutos,2).":".ajuste($segundos,2);
      return $tiempo;
    }
//----------------------------------------------------------------------------
    function cuadros_hor($cuadros)
    {
      $cu=$cuadros*100;
      $f=(int)(($cu%2997)/100);
      $horas = floor($cuadros/107892);
      $minutos = floor(($cuadros-($horas*107892))/1798.2);
      $segundos =floor((($cuadros-($horas*107892)-($minutos*1798.2))/29.97));
      $tiempo=ajuste($horas,2).":".ajuste($minutos,2).":".ajuste($segundos,2).":".ajuste($f,2);
      return $tiempo;
    }
//----------------------------------------------------------------------------
    function hora_segs($hora_ini)
    {
      $hora=substr($hora_ini,0,2);
      $mins=substr($hora_ini,3,2);
      $segs=substr($hora_ini,-2);
      $total=$hora*3600+$mins*60+$segs;
      return $total;
    }
//----------------------------------------------------------------------------
    function hora_cdrs($hora_ini)
    {
      $cdrs=0;
      $hora=substr($hora_ini,0,2);
      $mins=substr($hora_ini,3,2);
      $segs=substr($hora_ini,6,2);
      if(strlen($hora_ini)==11)
        $cdrs=substr($hora_ini,9,2);
      $total=($hora*3600*30)+($mins*60*30)+($segs*30)+$cdrs;
      return $total;
    }
//----------------------------------------------------------------------------
    function dif_transc($hora2)
    {
      $tact=date("H:i:s");
      $t1=explode(":",$tact);
      $t2=explode(":",$hora2);
      $total=($t1[0]*3600+$t1[1]*60+$t1[2])-($t2[0]*3600+$t2[1]*60+$t2[2]);
      return $total;
    }
//----------------------------------------------------------------------------
  function obt_id_cad($id_tst)
  {
    if ($id_tst<100)
      $ret=ajuste($id_tst,2);
    else
      $ret=ajuste($id_tst,4);
    return($ret);
  }
//----------------------------------------------------------------------------
    function ajuste($dato,$ajuste)
    {
      $res=intval($dato);
      for($i=0;$i<$ajuste;$i++)
      {
        if(strlen($res)<$ajuste)
          $res="0".$res;
        else
          $i=$ajuste;
      }
      return $res;
    }
//----------------------------------------------------------------------------
    function cmd_error($cmd,&$error,&$color)
    {
      if($cmd==0)
      {
        $error="CMD_EDO_CMD_LISTO";
        $color="LimeGreen";
      }
      elseif($cmd==1)
      {
        $error="CMD_EDO_CMD_NO_EXISTE";
        $color="Red";
      }
      elseif($cmd==2)
      {
        $error="CMD_EDO_CMD_NO_RESP";
        $color="Red";
      }
      elseif($cmd==5)
      {
        $error="CMD_EDO_REENVIA_CMD";
        $color="Red";
      }
      elseif($cmd==6)
      {
        $error="CMD_EDO_ENV_COMP_CMD";
        $color="Red";
      }
      elseif($cmd==15)
      {
        $error="AUN_NO_REVISADO";
        $color="OrangeRed";
      }
   }
//----------------------------------------------------------------------------
    function obt_fecha_completa($fecha)
    {
      date_default_timezone_set('America/Mexico_City');
      $dia=substr($fecha,0,2);
      $mes=substr($fecha,3,2);
      $year=substr($fecha,-4);
      $dia_s=date("l",mktime(0, 0, 0,(int)$mes,(int)$dia,(int)$year));
      $cad=obt_dia($dia_s).",".$dia." de ".obt_mes($mes)." ".$year;
      return $cad;
    }
//----------------------------------------------------------------------------
    function obt_dia($dia)
    {
      $nombre="";
      if($dia=="Monday")
        $nombre="Lunes";
      else if($dia=="Tuesday")
        $nombre="Martes";
      else if($dia=="Wednesday")
        $nombre="Mi&eacutercoles";
      else if($dia=="Thursday")
        $nombre="Jueves";
      else if($dia=="Friday")
        $nombre="Viernes";
      else if($dia=="Saturday")
        $nombre="S&aacutebado";
      else
        $nombre="Sunday";
      return $nombre;
    }
//----------------------------------------------------------------------------
    function obt_mes($mes)
    {
      $nombre="";
      if($mes==1)
        $nombre="Enero";
      else if($mes==2)
        $nombre="Febrero";
      else if($mes==3)
        $nombre="Marzo";
      else if($mes==4)
        $nombre="Abril";
      else if($mes==5)
        $nombre="Mayo";
      else if($mes==6)
        $nombre="Junio";
      else if($mes==7)
        $nombre="Julio";
      else if($mes==8)
        $nombre="Agosto";
      else if($mes==9)
        $nombre="Septiembre";
      else if($mes==10)
        $nombre="Octubre";
      else if($mes==11)
        $nombre="Noviembre";
      else
        $nombre="Diciembre";
      return $nombre;
    }
//----------------------------------------------------------------------------
    function fecha_borland($hoy)
    {
      $com=strtotime("18:00");
      $dif_fecha_ini = 25569;     //Dias de diferencia entre 30/12/1899 y 1/1/1970
      $segundos_por_dia = 86400;  //Numero de Segundos en un dia
      $fecha=intval($hoy/$segundos_por_dia)+$dif_fecha_ini;
        if($com<$hoy)
          $fecha=$fecha-1;
      return $fecha;
    }
//----------------------------------------------------------------------------
    function fecha_borland2($hoy)
    {
      $com=strtotime($hoy);
      $dif_fecha_ini = 25569;     //Dias de diferencia entre 30/12/1899 y 1/1/1970
      $segundos_por_dia = 86400;  //Numero de Segundos en un dia
      $fecha=round(($hoy/$segundos_por_dia)+$dif_fecha_ini);
      return $fecha;
    }
//----------------------------------------------------------------------------
    function borland_to_cad($f_bor)
    {
      $dif_fecha_ini = 25569;     //Dias de diferencia entre 30/12/1899 y 1/1/1970
      $segundos_por_dia = 86400;
      $hoy=($f_bor-$dif_fecha_ini+1)*$segundos_por_dia;
      return $hoy;
    }
//---------------------------------------------------------------------------
  function define_permisos($permisos)
  {
    $per_=(is_numeric($permisos))?$permisos:1;
    if(!defined('PERMISOS'))
    {
      define("PERMISOS",$per_);
    }
  }
//---------------------------------------------------------------------------
  function desencripta_($dato)
  {
    $salt="AZDqCnT0TEr7XJwg";
    $IV = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
    $str=base64_decode($dato);
    $message_padded = $str;
    if (strlen($message_padded) % 8) {
        $message_padded = str_pad($message_padded, strlen($message_padded) + 8 - strlen($message_padded) % 8, "\0");
    }
    $str1=openssl_decrypt($message_padded,"AES-128-CBC",$salt, OPENSSL_RAW_DATA | OPENSSL_NO_PADDING, $IV);
    return $str1;
  }
//----------------------------------------------------------------------------
function GetProvider($Contrasena)
  {
    $BPass=unpack("C*",$Contrasena);
    $BPass=acomoda($BPass);
    $minsize=128;
    $RealKey=RealKey($minsize,$BPass);
    return $RealKey;
  }
//---------------------------------------------------------------------------
  function acomoda($Arreglo)
  {
    for($i=1;$i<=count($Arreglo);++$i)
    {
      $nuevo[$i-1]=$Arreglo[$i];
    }
    return $nuevo;
  }
//---------------------------------------------------------------------------
  function RealKey($minsize,$key)
  {
    $Rkey="";
    for($i=1;$i<=$minsize;$i+=8)
    {
      $Rkey.=chr($key[($i/8)%count($key)]);
    }
    return $Rkey;
  }
//----------------------------------------------------------------------------
  function encripta_dato($dato,$salt)
  {
    $salt_= str_pad($salt, 16, "\0");
    $block = 16;
    $pad = $block - (strlen($dato) % $block);
    $dato .= str_repeat(chr($pad), $pad);
    $IV = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
    $encriptado = base64_encode(openssl_encrypt($dato,"AES-128-CBC",$salt_,OPENSSL_RAW_DATA | OPENSSL_NO_PADDING,$IV));
    return $encriptado;
  }
//---------------------------------------------------------------------------
function desencripta_dato($dato,$salt)
  {
    $salt_= str_pad($salt, 16, "\0");
    $IV = "\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0";
    $str=base64_decode($dato);
    $message_padded = $str;
    if (strlen($message_padded) % 8) {
        $message_padded = str_pad($message_padded, strlen($message_padded) + 8 - strlen($message_padded) % 8, "\0");
    }
    $str1=openssl_decrypt($message_padded,"AES-128-CBC",$salt_, OPENSSL_RAW_DATA, $IV);
    $str1=substr($str1,0,21);
    return $str1;
  }
//---------------------------------------------------------------------------
  function tamano_linea($linea,$cadena)
  {
    $dato="";
    if($linea==3)
      $dato=substr($cadena,0,strrpos($cadena,"/")+1);
    else if($linea==4)
      $dato=substr($cadena,0,14);
    else if($linea==5)
      $dato=substr($cadena,0,14);
    else if($linea==6)
      $dato=substr($cadena,0,14);
    else if($linea==8)
      $dato=substr($cadena,0,16);
    else if($linea==9)
      $dato=substr($cadena,0,27);
    else if($linea==10)
      $dato=substr($cadena,0,strrpos($cadena,")")+1);
    else if($linea==11)
      $dato=substr($cadena,0,16);
    else if($linea==12)
      $dato=substr($cadena,0,16);
    else if($linea==13)
      $dato=substr($cadena,0,strrpos($cadena,")")+1);
    else if($linea==15)
      $dato=substr($cadena,0,18);
    else if($linea==16)
      $dato=substr($cadena,0,23);
    else if($linea==17)
      $dato=substr($cadena,0,strrpos($cadena,")")+1);
    else
      $dato=$cadena;
    return $dato;
  }
//---------------------------------------------------------------------------
function obt_config2($var)
{
  $cad="SIN_DATOS";
  $des="";
  $i=1;
  $datos=array(0=>'q+1d7dy8v5C0cvApXVulggkC63npOubMONfmPtjyQmc=',
    1=>'TvmEbif52Jd6EYZs5Xva+JzMxEwN63NDMsUnfwqsZgNi0dv8Kz5H5PkjruLZ8gkWvn3Ql1kcKevdGl6wyL3/sHiwqLukpezVp/ksKTWg6F0=',
    2=>'fWdNFbtJ/lw5R9RhfWAY3W7IoZ9m8fU72IQF5Dfhl5s=',
    3=>'AwcGL67lKqkxCSHpDSmC46iNF3I4RoM9BEyszh4EYNk=',
    4=>'NO1D2PxuU7W54tMtBo7jnQ==',
    5=>'CQunCeXLxszAGN8uK1I+Qw==',
    6=>'rmyqq35fNMr7l1v++GyvKA==',
    7=>'14mMKD1hqLTVIRoVrv4yQw==',
    8=>'eK5MQyJcpDjw/3gJ1FTABMIpYGwteO4MxolwtpkXKxE=',
    9=>'akGGF2HLrv67NspnIpGXga9wuKNZDJ3OdtIdF8m3v9Q=',
    10=>'Tij6ZzHrPQxLPPBhFMNwQ0V/FVQGZ8vTR3s5V8UTnEnyIEmo/zuPyW1WLSOYh5'
      .'MfsqQl9kDTObArvuUbCC26VNz9JXjSZPf5o+YoVOp2csTn3UFm0Iz5NrmjacUbOy2f/'
      .'iAxFFXlNXgbr8GQehJZPOuP/k0wPeL2lXHU9tHE6LsqqZyxRWujJTAWdOHVeChG46Msv'
      .'KQbfH/Kk6yhzyL82wMJb8I4OECGGPi+eu0VvrU/dVYHW0CpB/zNoUTuAnAb18vybg0d1x'
      .'Bqxof9x0PwgMpb5iQIiPdJfPko9NI2oQA=',
    11=>'rYUdBJxnq/JpfCaX/ZOvUrXrXjt4n1Y8Kdxdq43XRqM=',
    12=>'SVNTTbAclhddR2gVdIyOf3FqBJCZoNQojE2M0wknYew=',
    13=>'+eRR0LkwSt/ZP/JW0QODhrN+u+coBMVj4axlvmHUkNbKr2+hfR12WTn+'
        .'7aHI1amjt0Mq+R+SH5y8p/wK15TqE2ZsI4pcXHkLxGojU/xWQLvaNxO5h'
        .'PsZ09f0bPZDnQVFHt768ILLeMAnfFTSy4ZwAP+M44vm1BYsk3XFoq+wf0Gyt'
        .'Drd4Q1hcBu00v7p0jpWPVqEZcxTNqjVy3sXNBCdVQ==',
    14=>'9AjFMyY6TfKEEDl22qMwow==',
    15=>'Yjijk3oov2D5gDIM9wg6m7NNLCnQ309MHnoQYLq1ohA=',
    16=>'yeT55Zt2b433gHyL00fhPXUkx5CNcf+97a6Vpsa+E68=',
    17=>'lnzxV/pmt/VO91buG8EgXlr09rHtJXkRcs/WZhNkf7v7+Xz1eThe7Eo1CtEtERSxV4qKJ0A'
        .'kxi3i4VnfGf0hxaGERT8wgBnZDCCaX7qaQl6Sp3qF/9W9okuUCxlp12dFBygO2ENOfT7x'
        .'25kgg1ZgOn6eAGVJd/+uyMVms/RreKwwNFRQioS+Erd1TJZoZYa8/cmb/h7L+4DtLoK8ip'
        .'0OgN5Cok6LgyraIGR/hCLN1Y+zjE7qEdMwbCKs1BISqmbCQZEzHbJ3Fzboc50mFvKPfZJs'
        .'zCt9T4GolpPjG2xWJY4=');
    for($i=0;$i<count($datos);$i++)
    {
      $des=$datos[$i];
      $linea=trim(desencripta_($des));
      $linea=tamano_linea($i,$linea);
      if(strpos($linea,$var)!==false)
      {
        $cad=substr($linea,strpos($linea,"=")+1);
        $i=count($datos);
      }
    }
  return $cad;
}
//---------------------------------------------------------------------------
  function limpia_entrada($input)
  {
    $search = array(
      '@<script[^>]*>.*</script>@i',     // Strip out javascript
      '@<[/!]*?[^<>]*?>@i',              //Strip out HTML tags
      '@<style[^>]*>.*</style>@i',        // Strip style tags properly
      '@< ![sS]*?--[ tnr]*>@i'         // Strip multi-line comments
    );
    $output = preg_replace($search, '', $input);
    return $output;
  }
//---------------------------------------------------------------------------
  function sanitize($input)
  {
    if (is_array($input)) {
        foreach($input as $var=>$val) {
            $output[$var] = sanitize($val);
        }
    }
    else {
        if (get_magic_quotes_gpc()) {
            $input = stripslashes($input);
        }
        $output  = limpia_entrada($input);
    }
    return $output;
  }
//---------------------------------------------------------------------------
function ObtenerIP()
{
  if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"),"unknown"))
    $ip = getenv("HTTP_CLIENT_IP");
  else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
    $ip = getenv("HTTP_X_FORWARDED_FOR");
  else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
    $ip = getenv("REMOTE_ADDR");
  else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
    $ip = $_SERVER['REMOTE_ADDR'];
  else
    $ip = "IP desconocida";
  return($ip);
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
function envia_soap($eusr,$epsw)
    {
      $servidor="http://10.50.169.89/wsapploginparam/service.asmx?WSDL";
      try{
      $opts = array(
        'http'=>array(
            'user_agent' => 'PHPSoapClient'
            )
        );
      
        $context = stream_context_create($opts);
        $clienteSOAP = new SoapClient($servidor,
          array('stream_context' => $context,'cache_wsdl' => WSDL_CACHE_NONE,'trace' => true,
                  'soap_version' => SOAP_1_2,'use' => SOAP_LITERAL));
        $parametros=array('Param1'=>$eusr,'Param2'=>$epsw,'Param3'=>'58');
        $canales = $clienteSOAP->gsc_llave($parametros);
        $result = obj2array($canales);
        
     
        return $result['gsc_llaveResult'];
      }
      catch(SoapFault $e){
        return $e;
      }
    }
    
//---------------------------------------------------------------------------
 function obj2array($obj)
  {
    $out = array();
    foreach ($obj as $key => $val)
    {
      switch(true)
      {
        case is_object($val):
          $out[$key] = obj2array($val);
        break;
        case is_array($val):
          $out[$key] = obj2array($val);
        break;
        default:
          $out[$key] = $val;
      }
    }
    return $out;
  }
//-----------------------------------------------------------------------------
function convierte_carcter($cadena)
{
 $list1=array("/Ñ/","/Á/","/É/","/Í/","/Ó/","/Ú/");
 $list2=array("ñ","á","é","í","ó","ú");
 
 $cadena= preg_replace($list1, $list2, $cadena);
 return $cadena;
}
//-----------------------------------------------------------------------------
function estados($estado)
{ $bg="";
    switch ($estado)
    {
        case 'NUEVO':
            $bg="bgcolor='#F2EEB7'";
            break;
        
        case 'PENDIENTE':
            $bg="bgcolor='#F5CBA7'";
            break;
       case 'CERRADO':
           $bg="bgcolor='#cfe29a'";
            break;
        case 1:
            $bg="bgcolor='#cfe29a'";
            break;
    }
    
    

    return  $bg ;
}

$nom_bd = 'BLOQ_DBA';
?>