<?php
include ("conexion.php");
include ("bitacora.php");

$html="";

$dato_app =(isset($_POST['dato_app']))?$_POST['dato_app']:"";

$id_problema =(isset($_POST['id_problema']))?$_POST['id_problema']:"";

$id_subcat =(isset($_POST['id_subcat']))?$_POST['id_subcat']:"";

$id_actividad =(isset($_POST['id_actividad']))?$_POST['id_actividad']:"";

$id_solucion =(isset($_POST['id_solucion']))?$_POST['id_solucion']:"";

$id_subcat_act= (isset($_POST['id_subcat_act']))?$_POST['id_subcat_act']:"";

$id_subcat_sol= (isset($_POST['id_subcat_sol']))?$_POST['id_subcat_sol']:"";

if($dato_app!="")
{
   $sql="SELECT B.PROBLEMA, B.ID_PROBLEMA FROM ".$nom_bd.".CAT_REL_APP_PROBLEMAS A, ".$nom_bd.".CAT_PROBLEMAS_CABS B
         WHERE A.ID_APP=".$dato_app." AND B.ID_PROBLEMA=A.ID_PROBLEMA 
         ORDER BY B.PROBLEMA";
   Bitacora("APP: ".$sql, 0);
    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
     /*if ($dato_app!=2)
    {*/
       $html = "<option value='0'>--SELECCIONE PROBLEMA--</option>";
    
       while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
		$seleccionado="";
		if($dato_app!=1 && $dato_app!=15 )
			$seleccionado="selected";
        $html.= "<option value='".$row['ID_PROBLEMA']."' ".$seleccionado.">".$row['PROBLEMA']."</option>";
      }
	/*}
    else{
	  
	    while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
       {
        
         $html.= "<option value='".$row['ID_PROBLEMA']."' selected>".$row['PROBLEMA']."</option>";
       }  
	}*/
   echo $html; 
} 

else if ($id_problema!="")
    
{
     $sql="SELECT B.SUBCATEGORIA, B.ID_SUBCATEGORIA FROM ".$nom_bd.".CAT_REL_PROB_SUBCAT A, ".$nom_bd.".CAT_SUBCAT_PROBLEMAS_CABS B
         WHERE A.ID_PROBLEMA=".$id_problema." AND B.ID_SUBCATEGORIA=A.ID_SUBCATEGORIA 
         ORDER BY B.SUBCATEGORIA";
    Bitacora("Problema: ".$sql, 0);
    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
    
    if ($id_problema!=11)
    {
        $html = "<option value='0'>--SELECCIONE SUBCATEGORIA--</option>"; 
      
      while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
        $html.= "<option value='".$row['ID_SUBCATEGORIA']."'>".$row['SUBCATEGORIA']."</option>";
      }
     
    }
    else
    {
        while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
       {
        
         $html.= "<option value='".$row['ID_SUBCATEGORIA']."' selected>".$row['SUBCATEGORIA']."</option>";
       }  
      
    }
   echo $html;
}

else if($id_subcat !="")
{
    $sql="SELECT B.DIAGNOSTICO, B.ID_DIAGNSTICO FROM ".$nom_bd.".CAT_REL_SUBCAT_DIAG A, ".$nom_bd.".CAT_DIAGNOSTICOS_CABS B
         WHERE A.ID_SUBCATEGORIA=".$id_subcat." AND B.ID_DIAGNSTICO=A.ID_DIAGNOSTICO 
         ORDER BY B.DIAGNOSTICO";
    Bitacora("Subcat: ".$sql, 0);
    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
    
    if($id_subcat != 3)
    {
      $html = "<option value='0'>--SELECCIONE DIAGNOSTICO--</option>";
      while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
        $html.= "<option value='".$row['ID_DIAGNSTICO']."'>".$row['DIAGNOSTICO']."</option>";
      }
       
    }
    else
    {   
      
      while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
        $html.= "<option value='".$row['ID_DIAGNSTICO']."'>".$row['DIAGNOSTICO']."</option>";
      }
      
    }
    echo $html;
}

else if($id_actividad !="")
{
    $sql="SELECT B.ACTIVIDAD, B.ID_ACTIVIDAD FROM ".$nom_bd.".CAT_REL_DIAG_ACTIVIDAD A, ".$nom_bd.".CAT_ACTIVIDADES_CABS B
         WHERE A.ID_DIAGNOSTICO=".$id_actividad." AND B.ID_ACTIVIDAD=A.ID_ACTIVIDAD
         ORDER BY B.ACTIVIDAD";
    Bitacora("Actividad: ".$sql, 0);
    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
    
    if($id_actividad != 4 && $id_actividad != 12 && $id_actividad != 26 && $id_actividad != 53 && $id_actividad != 37 && 
	   $id_actividad != 38 && $id_actividad != 41 && $id_actividad != 42)
    {
      $html = "<option value='0'>--SELECCIONE ACTIVIDAD--</option>";
    
      while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
        $html.= "<option value='".$row['ID_ACTIVIDAD']."'>".$row['ACTIVIDAD']."</option>";
      }    
    }
    else
    {
      while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
        $html.= "<option value='".$row['ID_ACTIVIDAD']."'>".$row['ACTIVIDAD']."</option>";
      }      
    }
       
   echo $html;
}

else if($id_solucion !="")
{
    $sql="SELECT B.SOLUCION, B.ID_SOLUCION FROM ".$nom_bd.".CAT_REL_DIAG_SOLUCION A, ".$nom_bd.".CAT_SOLUCIONES_CABS B
         WHERE A.ID_DIAGNOSTICO=".$id_solucion." AND B.ID_SOLUCION=A.ID_SOLUCION
         ORDER BY B.SOLUCION ";
    Bitacora("Solucion: ".$sql, 0);
    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
    
    if($id_solucion != 4 && $id_solucion != 12 && $id_solucion != 26 && $id_solucion != 53 && $id_solucion != 37 && 
	   $id_solucion != 38 && $id_solucion != 41 && $id_solucion != 42)
    {
      $html = "<option value='0'>--SELECCIONE SOLUCION--</option>";
      while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
        $html.= "<option value='".$row['ID_SOLUCION']."'>".$row['SOLUCION']."</option>";
      } 
        
    }
    else
    {
      
      while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
      {
        $html.= "<option value='".$row['ID_SOLUCION']."'>".$row['SOLUCION']."</option>";
      }    
    }
    echo $html;
}

else if($id_subcat_act !="")
{
    $sql="SELECT UNIQUE(A.ID_ACTIVIDAD), B.ACTIVIDAD
          FROM ".$nom_bd.".CAT_REL_DIAG_ACTIVIDAD A, ".$nom_bd.".CAT_ACTIVIDADES_CABS B,
          ".$nom_bd.".CAT_REL_SUBCAT_DIAG C, ".$nom_bd.".CAT_DIAGNOSTICOS_CABS D
          WHERE 
          C.ID_SUBCATEGORIA=".$id_subcat_act."
          AND D.ID_DIAGNSTICO=C.ID_DIAGNOSTICO
          AND A.ID_DIAGNOSTICO= D.ID_DIAGNSTICO 
          AND B.ID_ACTIVIDAD = A.ID_ACTIVIDAD
          ORDER BY B.ACTIVIDAD";
    
    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
    
     $html = "<option value='0'>--SELECCIONE ACTIVIDAD--</option>";
    
     while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
   {
    
      $html.= "<option value='".$row['ID_ACTIVIDAD']."'>".$row['ACTIVIDAD']."</option>";
   }   
   echo $html;
}

else if($id_subcat_sol !="")
{
    $sql="SELECT UNIQUE(A.ID_SOLUCION), B.SOLUCION
          FROM ".$nom_bd.".CAT_REL_DIAG_SOLUCION A, 
          ".$nom_bd.".CAT_SOLUCIONES_CABS B, 
          ".$nom_bd.".CAT_REL_SUBCAT_DIAG C, 
          ".$nom_bd.".CAT_DIAGNOSTICOS_CABS D
          WHERE
          C.ID_SUBCATEGORIA=".$id_subcat_sol." 
          AND D.ID_DIAGNSTICO =C.ID_DIAGNOSTICO
          AND A.ID_DIAGNOSTICO=D.ID_DIAGNSTICO
          AND A.ID_SOLUCION =B.ID_SOLUCION
          ORDER BY B.SOLUCION";
    
    $resultado = oci_parse($conn, $sql);
    oci_execute($resultado);
    
     $html = "<option value='0'>--SELECCIONE SOLUCION--</option>";
    
     while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
   {
    
      $html.= "<option value='".$row['ID_SOLUCION']."'>".$row['SOLUCION']."</option>";
   }   
   echo $html;
}


        
