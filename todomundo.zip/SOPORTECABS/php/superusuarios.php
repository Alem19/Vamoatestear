<?php


include 'php/conexion.php';
//------------------------------------------------------------------------------

$Super_Usario =FALSE;

$ip=ObtenerIP();
$sql1= "SELECT ID, NOMBRE, NUMERO_EMPLEADO FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS 
          WHERE IP = '".$ip."' ";
Bitacora($sql1."  consulta super usuario ", 0); //La manera en como concatenar...
    
$resultado = oci_parse($conn, $sql1);
    
oci_execute($resultado);
    
while ($datos_usuario = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS))
{
  Bitacora("Si entro super usuario", 0);     
  $_SESSION['xusuario_valido']=$datos_usuario['NUMERO_EMPLEADO'];
  //$IP = $datos_usuario['IP']; 
  $NOMBRE = $datos_usuario ['NOMBRE'];
  $xuserx=(($NOMBRE));
  $_SESSION['nxUsuario']= $xuserx;  
  $_SESSION['xid_valido'] =$datos_usuario['ID'];
  $_SESSION['nxAdmin']= 1;
  
  $Super_Usario =TRUE;
        
}

//-----------------------------------------------------------------------------