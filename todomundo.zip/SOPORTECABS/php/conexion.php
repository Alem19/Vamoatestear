<?php

require_once 'utilerias.php';

$conn = oci_connect(USERLOGS, PASSLOGS, BDBLOQ,'AL32UTF8');
if (!$conn) {
    $e = oci_error();
    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
}
?>
