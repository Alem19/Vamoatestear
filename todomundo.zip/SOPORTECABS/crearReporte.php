<?php

include ("php/conexion.php");
date_default_timezone_set('America/Mexico_City');
session_start();
if (isset($_SESSION['xusuario_valido'])) 
{
    
?>

<!DOCTYPE html>
<html>
    <head>

       
        <!--<meta charset="utf-8">-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
       
        
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href="css/estilos.css" rel="stylesheet">
        <link href='//fonts.googleapis.com/css?family=Raleway:400,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"

        <!--JS -->
        <script src="js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/index.js"></script>  
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="bootstrap/js/bootstrap.js"></script>
        
        <script languaje ="javascript">
            
$(document).ready(function()
{
  var tipo_ubicacion=0;
  $("#CboSistema").change(function ()
  {
    $("#CboSistema option:selected").each(function()
    {
      id_sistema =$(this).val();
      $.post("php/getCombos.php", {id_sistema: id_sistema},
      function(data)
      {
        $("#CboApp").html(data);
        $("#CboApp").triggerHandler("change");
      });
    });
    limpia_combo(["problema","subcat","diagnostico","actividad","solucion"]);
  });
                
$("#CboApp").change(function ()
{
  $("#CboApp option:selected").each(function()
  {
    dato=$(this).val().split("-");
    tipo_ubicacion =dato[1];
    dato_app = dato[0];
                       
    $.post("php/getCombos.php", {tipo_ubicacion: tipo_ubicacion},
    function(data)
    {
      if(data=="")
      {
        $("#CboLugar").html("<option value='0'>--SELECCIONE--</option>");
      }
      else
      {
        $("#CboLugar").html(data);
                              
        $.post("php/getCargaRelaciones.php", {dato_app: dato_app},
        function(data)
        {
          if(data=="")
          {
            $("#CboProblema").html("<option value='0'>--SELECCIONE PROBLEMA--</option>");
          }                     
          else
          {
            $("#CboProblema").html(data);
			$("#CboProblema").triggerHandler("change");
          }
                                   
        });                 
      }
    });
});
limpia_combo(["subcat","diagnostico","actividad","solucion"]);
});
                
 $("#CboProblema").change(function()
 {    
   $("#CboProblema option:selected").each(function()
   {
     id_problema=$(this).val();
     $.post("php/getCargaRelaciones.php", {id_problema: id_problema},
     function(data)
     {
       if(data=="")
       {  
         $("#CboSubCat").html("<option value='0'>--SELECCIONE SUBCATEGORIA--</option>");         
       }     
       else
       {   
           var x;
           $("#CboSubCat").html(data);
           x = document.getElementById("CboSubCat");
           
           //Lanza evento change
           
           if(x.length==1)
           {  
              $("#CboSubCat").triggerHandler("change");
              
           }   
       }

     });         
    });  
    limpia_combo(["diagnostico","actividad","solucion"]);
    
 });
 
 $("#CboSubCat").on("change",function()
 { 
   $("#CboSubCat option:selected").each(function()
   { 
     id_subcat=$(this).val();
     id_subcat_act=$(this).val();
     id_subcat_sol=$(this).val();
     
     $.post("php/getCargaRelaciones.php", {id_subcat: id_subcat},
     function(data)
     {
       if(data=="")
       {  
         $("#CboDiagnostico").html("<option value='0'>--SELECCIONE DIAGNOSTICO--</option>"); 
         
       }     
       else
       {   
         var y; 
         $("#CboDiagnostico").html(data);
         y = document.getElementById("CboDiagnostico")
         //Lanza evento change
         
         if(y.length==1)
         {  $("#CboDiagnostico").triggerHandler("change");          
           
         }   
         
       }

     });
     
     
      $.post("php/getCargaRelaciones.php", {id_subcat_sol: id_subcat_sol},
      function(data)
      {
        if(data=="")
        {  
          $("#CboSolucion").html("<option value='0'>--SELECCIONE SOLUCION--</option>");

        }     
        else
        {   
          $("#CboSolucion").html(data);

        }

      });
     
     
      
      $.post("php/getCargaRelaciones.php", {id_subcat_act: id_subcat_act},
      function(data)
      {
        if(data=="")
        {  
          $("#CboActividad").html("<option value='0'>--SELECCIONE ACTIVIDAD--</option>");

        }     
        else
        {   
          $("#CboActividad").html(data);
        }

      });
     
    });
 });

 $("#CboDiagnostico").on("change",function()
 { 
   $("#CboDiagnostico option:selected").each(function()
   {
     id_actividad=$(this).val();
     id_solucion=$(this).val();
     $.post("php/getCargaRelaciones.php", {id_actividad: id_actividad},
     function(data)
     {
       if(data=="")
       {  
         $("#CboActividad").html("<option value='0'>--SELECCIONE ACTIVIDAD--</option>");

       }     
       else
       {   
         
          $("#CboActividad").html(data);
      
       }

     });
     
     $.post("php/getCargaRelaciones.php", {id_solucion: id_solucion},
     function(data)
     {
       if(data=="")
       {  
         $("#CboSolucion").html("<option value='0'>--SELECCIONE SOLUCION--</option>");

       }     
       else
       {   
         $("#CboSolucion").html(data);

       }

     });
      
    });
 });
                
                var hoy=new Date();
                var mes=((hoy.getMonth()+1).length>1)?(hoy.getMonth()+1):"0"+(hoy.getMonth()+1);
                /*var fe=hoy.getFullYear()+"-"+mes+"-"+hoy.getDate()+"T15:56";
                console.log(fe);
                $('#FHSolicitud').val(fe);*/
            }); 
        function validar() 
        {
                sistema = document.getElementById("CboSistema").selectedIndex;
                if(sistema == null || sistema == 0 ) 
                {
                    
                    alert("ERROR:El campo Sistema es obligatorio");
                    document.getElementById("CboSistema").focus();
                    return false;
                }
                
                app = document.getElementById("CboApp").selectedIndex;
                if(app == null || app == 0 ) 
                {   
                    alert("ERROR: El campo Aplicación es obligatorio");
                    document.getElementById("CboApp").focus();
                    return false;
                }
                
                notificacion = document.getElementById("CboViaNot").selectedIndex;
                if(notificacion==null || notificacion == 0)
                {
                    alert("ERROR: Seleccione una Vía de Notificación");
                    document.getElementById("CboViaNot").focus();
                    return false;
                }
                
                asignado = document.getElementById("CboAsignado").value;
                if(asignado == null || asignado == 0 ) 
                {
                    alert("ERROR: Asigne el reporte a alguien");
                    document.getElementById("CboAsignado").focus();
                    return false;
                }
                
                problema = document.getElementById("CboProblema").value;
                if(problema == null || problema == 0 ) 
                {
                    alert("ERROR: El campo Problema es obligatorio");
                    document.getElementById("CboProblema").focus();
                    return false;
                }
                
                subcat = document.getElementById("CboSubCat").value;
                if(subcat == null || subcat == 0 ) 
                {
                    alert("ERROR: El campo Subcategoría es obligatorio");
                    document.getElementById("CboProblema").focus();
                    return false;
                }
                
               /* if(document.getElementById("textReporte").value.length==0){
                    alert("ERROR: Ingrese Reporte/Problema");
                    document.getElementById("textReporte").focus();
                    return false;
                }*/
                
             guardarReporte();
             return true;
        }
        function combo_notificacion()
        {
            var index=$('#CboViaNot').val();         
            $('#dvnot').empty();
            if(index==6 || index==7)
            {                
                $('#dvnot').append("<select id='notificadoPor' class='form-control input-sm'></select>");
                
                 $.ajax({
                                type: "POST",
                                dataType: 'html',
                                url: "php/getCombos.php",
                                data: "dvnot=1",
                                success: function(resp){
                                   console.log(resp); 
                                  $('#notificadoPor').append(resp);  
                                }
                                
                            });
            }else{
                $('#dvnot').append('<input type="text" id="notificadoPor" class="form-control input-sm" id="notificadoPor" name="notificadoPor" autocomplete="off">');
            }
        }
        function guardarReporte()
                {
                    
                    var sistema =$("#CboSistema").val();
                    var dato = $("#CboApp").val().split('-');
                    var app = dato[0];
                                    
                    tipo_ubicacion=0;
                    
                    $("#CboApp option:selected").each(function()
                    {
                        dato=$(this).val().split("-");
                        tipo_ubicacion =dato[1];
                        
                    
                    });
                            
                        
                    var lugar = $("#CboLugar").val();
                   
                    var red1=0;
                    var red7 =0; 
                    var red40 =0; 
                    var redAL =0;
                    var red11=0;
                    var red12=0;
                    var redpublimax=0;
                    var revisado=0;
                    
                    
                    $('input[type=checkbox]').each(function()
                    {
                        if (this.checked) 
                        {
                            switch($(this).attr("id"))
                            {
                                case 'checkboxRed1':
                                    red1=1;
                                break;
                                case 'checkboxRed7':
                                    red7=1;
                                break;
                                case 'checkboxRed40':
                                    red40=1;
                                break;
                                case 'checkboxRedAL':
                                    redAL=1;
                                break;
                                case 'checkboxRed1-1':
                                    red11=1;
                                break;
                                case 'checkboxRed1-2':
                                    red12=1;
                                break;
                                case 'Red7Publimax':
                                    redpublimax=1;
                                break;
                                case 'revisado':
                                     revisado=1;
                                break;
                            }
                        }
                    }); 
                    
                   
                     
                        
                    
                    var userCreo=$("#CboUserCreo").val();
                    var nomAsignado=$("#CboAsignado").val();
                    
                    var estadoReporte=$("#CboEstado").val();
                    var viaNot = $("#CboViaNot").val();
                    var notificadoPor = $("#notificadoPor").val();
                    var radioRep = ($("#radioRep").is(":checked"))?1:0;
                    var radioEsc = ($("#radioEsc").is(":checked"))?1:0;
                    var reportadoA =$("#reportadoA").val();  
                    var escaladoA = $("#escaladoA").val();
                    var problema = $("#CboProblema").val();
                    var subcat = $("#CboSubCat").val();
                    var diagnostico = $("#CboDiagnostico").val();
                    var actividad = $ ("#CboActividad").val();
                    var solucion = $ ("#CboSolucion").val();
                    var textReporte =$("#textReporte").val();
                    var textDiagnostico = $("#textDiagnostico").val();
                    var textActividad =$("#textActividad").val();
                    var textSolucion=$("#textSolucion").val();
                    var fecha_alta=$("#FHSolicitud").val();
                    
                     if(estadoReporte ==3)
                   {
                     if(diagnostico == 0 || actividad == 0 || solucion== 0 )
                     {
                        alert("Para Cerrar el reporte debes seleccionar Diagnostico, Actividad y Solución");
                        return 0;
                     }  
                   }
                    var dataString = "CboSistema=" + sistema
                                                    + "&CboApp=" + app 
                                                    + "&CboLugar=" + lugar 
                                                    + "&checkboxRed1=" + red1 
                                                    + "&checkboxRed7=" + red7
                                                    + "&checkboxRed40=" + red40 
                                                    + "&checkboxRedAL=" + redAL
                                                    + "&checkboxRed1-1=" + red11
                                                    + "&checkboxRed1-2=" + red12
                                                    + "&Red7Publimax=" + redpublimax
                                                    + "&CboUserCreo=" + userCreo
                                                    + "&CboAsignado=" + nomAsignado 
                                                    
                                                    + "&CboEstado=" + estadoReporte 
                                                    + "&CboViaNot=" + viaNot 
                                                    + "&notificadoPor=" + notificadoPor 
                                                    + "&radioRep=" + radioRep 
                                                    + "&reportadoA=" + reportadoA
                                                    + "&radioEsc=" + radioEsc
                                                    + "&escaladoA=" + escaladoA
                                                    + "&CboProblema= "+ problema
                                                    + "&CboSubCat= " +subcat
                                                    + "&CboDiagnostico= " +diagnostico
                                                    + "&CboActividad=" +actividad
                                                    + "&CboSolucion=" +solucion
                                                    + "&textReporte=" + textReporte
                                                    + "&textDiagnostico=" + textDiagnostico
                                                    + "&textActividad=" + textActividad
                                                    + "&textSolucion=" + textSolucion
                                                    + "&tipo_1=" + tipo_ubicacion
                                                    + "&revisado=" + revisado
                                                    + "&fecha_alta=" + fecha_alta;
                                            
                                           

                    $.ajax({
                                type: "POST",
                                dataType: 'html',
                                url: "php/guardarReporte.php",
                                data: dataString,
                                success: function(resp)
                                {
                                    
                                    $('#respuesta').html(resp);
                                    $('#modalNuevoReporte').modal
                                    ({
                                     show:true,
                                     backdrop:'static'
                                    });
                                    //  Limpiar();                                
                                }
                                   
                            });
                    
                }
               
                function Limpiar()
                {
                    
                    /*$("#CboSistema").val("0");
                    $("#CboApp").val("0");
                    $("#CboLugar").val("0");
                    if($("#CboAsignado").attr("disabled") != 'disabled')
                    {
                        $("#CboAsignado").val("0");
                    }
                    $("#CboEstado").val("1");
                    $("#CboViaNot").val("0");
                    $("#notificadoPor").val("");
                    $("#reportadoA").val("");
                    $("#escaladoA").val("");
                    $("#textReporte").val("");
                    $("#textDiagnostico").val("");
                    $("#textActividad").val("");
                    $("#textSolucion").val("");
                    $('#checkboxRed1').prop( "checked", false);
                    $('#checkboxRed7').prop( "checked", false);
                    $('#checkboxRed40').prop( "checked", false);
                    $('#checkboxRedAL').prop( "checked", false);
                    $('#checkboxRed1-1').prop( "checked", false);
                    $('#checkboxRed1-2').prop( "checked", false);
                    $('#Red7Publimax').prop( "checked", false);
                    $('#CboProblema').val("-1");
                    $('#CboSubCat').val("-1");
                    $('#CboDiagnostico').val("-1");
                    $('#CboActividad').val("-1");
                    $('#CboSolucion').val("-1");*/
        
                    location.reload();
                    
                                                  
                }  
                function regresa()
                {
                   window.location="index.php";
                }
                
                function limpia_combo(opc)
                { 
                  var elemento,texto;
                  
                  for(var i=0,j=opc.length ; i<j ; i++)
                  {
                    opcion=opc[i]; 
                    switch(opcion)
                    {
                      case 'problema':
                        elemento="CboProblema";
                        texto="--SELECCIONE PROBLEMA--";
                      break;
                      
                      case 'subcat':
                        elemento="CboSubCat";
                        texto="--SELECCIONE SUBCATEGORIA--";
                      break;
                      
                      case 'diagnostico':
                        elemento="CboDiagnostico";
                        texto="--SELECCIONE DIAGNOSTICO--";
                      break;
                      
                      case 'solucion':
                        elemento="CboSolucion";
                        texto="--SELECCIONE SOLUCION--";
                      break;
                      
                      case 'actividad':
                        elemento="CboActividad";
                        texto="--SELECCIONE ACTIVIDAD--";
                      break;  
                    
                  }
                   
                    $("#"+elemento).empty();
                    $("#"+elemento).append("<option value=0>"+texto+"</option>");
                  
                  }
                 
                }
                
               function combo_unico(opc)
                {
                  console.log("Funcion combo: ",opc);
                  switch(opc)
                  {
                    case 1:    
                            console.log("caso 1");
                            $("#CboSubCat option:selected").each(function()
                            { console.log("entro caso 1 1");
                              id_subcat=$(this).val();
                              $.post("php/getCargaRelaciones.php", {id_subcat: id_subcat},
                              function(data)
                              {
                                if(data=="")
                                {   
                                  $("#CboDiagnostico").html("<option value='0'>--SELECCIONE DIAGNOSTICO--</option>"); 
                                }     
                                else
                                {   
                                  $("#CboDiagnostico").html(data);
                                }
                               });     
                               limpia_combo(["actividad","solucion"]);
                            });
                    break;
                    
                    case 2:
                            console.log("caso 2");
                            $("#CboDiagnostico option:selected").each(function()
                            { console.log("entro caso 2 1");
                              id_actividad=$(this).val();
                              id_solucion=$(this).val();
                              $.post("php/getCargaRelaciones.php", {id_actividad: id_actividad},
                              function(data)
                              {console.log("imprime caso 2 1");
                                if(data=="")
                                {  
                                  $("#CboActividad").html("<option value='0'>--SELECCIONE ACTIVIDAD--</option>");
                                }     
                                else
                                {   
                                  $("#CboActividad").html(data);
                                }
                              });
                              
                              $.post("php/getCargaRelaciones.php", {id_solucion: id_solucion},
                              function(data)
                              {
                               if(data=="")
                               {  
                                 $("#CboSolucion").html("<option value='0'>--SELECCIONE SOLUCION--</option>");
                               }     
                               else
                               {   
                                 $("#CboSolucion").html(data);
                               }

                              });
                            });
                    break;
                
                    
                  }
                } 
               
        </script>
        
        <!-- Encabezado - Barra de Titulo -->
        <div class="col-md-8">
            <div class="col-md-13">
                <!--Barra-->
                <nav class="navbar navbar-light bg-light" id="nav" role ="navigation">
                    <span class="navbar-text">
                        <h4> Nuevo Reporte</h4>
                    </span>
                    
                    <div class="collapse navbar-collapse navbar-ex1-collapse">
                        <ul class="navbar-right" id="nav_botones">
                            <button  onclick ="Limpiar();" class="btn" id="boton" type="button" value="btncancelar"><i class=" icono izquierda fa fa-eraser"></i> Limpiar</button>
                            <button  onclick ="validar();" class="btn" id="boton" type="submit" value="btnenviar"><i class=" icono izquierda fa fa-save"></i> Guardar</button> 
                              
                        </ul>
                    </div>
                </nav>
        </div> <!-- Fin Encabezado -->
</head>
<body style="background-color:#FFFFFF; color:#000000;">

    
    <form id ="crearReporte" class="form-horizontal"  role="form"  method="POST" onsubmit="return false" action="return false">
        
        <!-- Inicio 1ra Sección - Formulario -->   
        <div class="col-md-13" id="formulario">
            <!-- Inicio Formulario izquierdo -->
            <div class="col-md-6" id="seccion">
                <div class="form-group">
                                <label for="" id="IdReporte" class="col-md-5">ID Reporte:</label>
                                <div class="col-md-7">
                                  <input type="" class="form-control input-sm" id="idReporte" name="idReporte"
                                           autocomplete="off" disabled="true" >  
                                    
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Sistema: *</label>
                                <div class="col-md-7">
                                    <select class="form-control input-sm" id="CboSistema" name="CboSistema" required>
                                        <option value="0">--SELECCIONE--</option>
                                        <?php      
                                                $sql= ("SELECT ID_SISTEMA, NOMBRE_SISTEMA FROM ".$nom_bd.".CAT_SISTEMAS_CABS ORDER BY NOMBRE_SISTEMA ASC");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                echo"<option value='$row[ID_SISTEMA]'>$row[NOMBRE_SISTEMA]</option>";
                                                }
                                        ?>
                                       
                                    </select>
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Aplicación: *</label>
                                <div class="col-md-7">
                                    <select required class="form-control input-sm" id="CboApp" name="CboApp">
                                        <option value='0'>--SELECCIONE--</option>";
                                    </select>
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Lugar: *</label>
                                <div class="col-md-7">
                                    <select class="form-control input-sm" id="CboLugar" name="CboLugar">
                                        <option value="0">--SELECCIONE--</option>
                                        
                                    </select>
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5">Red: * </label>
                                <div class="col-md-7 form-check">
                                    <label class="checkbox-inline">
                                            <input type="checkbox" id="checkboxRed1" name="checkboxRed1"> 1
                                    </label>
                                    
                                    <label class="checkbox-inline">
                                            <input type="checkbox" id="checkboxRed7" name="checkboxRed7"> 7
                                    </label>
                                    
                                    <label class="checkbox-inline">
                                            <input type="checkbox" id="checkboxRed40" name="checkboxRed40"> 40
                                    </label>
                                    
                                    <label class="checkbox-inline">
                                            <input type="checkbox" id="checkboxRedAL" name="checkboxRedAL"> A+
                                    </label>
                                    
                                       
                                   
                                    <br>
                                    
                                        <label class="checkbox-inline">
                                            <input type="checkbox" id="checkboxRed1-1" name="checkboxRed1-1"> 1-1 Hr
                                        </label>
                                        
                                        <label class="checkbox-inline">
                                            <input type="checkbox" id="checkboxRed1-2" name="checkboxRed1-2"> 1-2 Hr
                                        </label>
                                   
                                        <label class="checkbox-inline">
                                            <input type="checkbox" id="Red7Publimax" name="Red7Publimax"> 7 Publimax
                                        </label>
                                        
                                     
                                </div>
                </div>
                
                <div class="form-group">
                </div>
                
               
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Vía de Notificación: *</label>
                                <div class="col-md-7">
                                    <select class="form-control input-sm" id="CboViaNot" name="CboViaNot" onchange="combo_notificacion()">
                                        <option value="0">--SELECCIONE--</option>
                                        <?php      
                                                $sql= ("SELECT * FROM ".$nom_bd.".CAT_VIA_NOTIFICACION ORDER BY NOMBRE_NOTIFICACION ASC");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                echo"<option value='$row[ID_NOTIFICACION]'>$row[NOMBRE_NOTIFICACION]</option>";
                                                }
                                        ?>
                                    </select>
                                </div>
                </div>
                
                
             <div class="form-group">
                                <label for="" class="col-md-5 ">Reportado a:</label><!--6-->
                                <div class="col-md-7"><!--6-->
                                    <input type="" class="form-control input-sm" id="reportadoA" name="reportadoA"
                                           autocomplete="off">
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 "> Escalado con:</label><!--6-->
                                <div class="col-md-7"><!--6-->
                                    <input type="" class="form-control input-sm" id="escaladoA" name="escaladoA"
                                           autocomplete="off">
                                </div>
                </div>
                    
            </div><!-- Fin Formulario izquierdo -->

            <!-- Inicio Formulario derecho--->
            <div class="col-md-6" id="seccion2">
                
                <div class="form-group">
                                <label for="" class="col-md-5">Fecha de solicitud:</label> <!--6-->
                                 <div class="col-md-7"> <!--6-->
                                  
                                     
                                     <?php $admin=$_SESSION['nxAdmin'];
                                     if($admin)
                                     {
                                       echo  '<input class="form-control input-sm" type="datetime-local" name="FHSolicitud" id="FHSolicitud" value="'.date("Y-m-d")."T".date("H:i").'">';
                                     }
                                     else
                                     {
                                       echo  '<input class="form-control input-sm" type="datetime-local" name="FHSolicitud" id="FHSolicitud" disabled="TRUE" value="'.date("Y-m-d")."T".date("H:i").'" >';
                                         
                                     }
                                     
                                    ?>
                                </div>
                                     
                                
                            
                </div>
                
               
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Creó el reporte:</label><!--6-->
                                <div class="col-md-7"><!--6-->
                                    <select class="form-control input-sm" id="CboUserCreo" name="CboUserCreo" disabled="true">
                                    <option value="<?php echo $_SESSION['xid_valido']; ?>"><?php echo strtoupper(($_SESSION['nxUsuario'])); ?></option>
                                    </select>
                                    
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Asignado a: *</label><!--6-->
                                <div class="col-md-7"><!--6-->
                                    <?php 
                                          $admin=$_SESSION['nxAdmin'];
                                          if($admin == 1)
                                          {
                                                echo '<select class="form-control input-sm" id="CboAsignado" name="CboAsignado" required >';
                                                echo '<option value="0">--SELECCIONE--</option>';
                                             
                                                $sql= ("SELECT ID, NOMBRE FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS
                                                        WHERE SOPORTE =1 AND ID_GRUPO=1
                                                        ORDER BY NOMBRE ASC");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                echo"<option value='$row[ID]'>$row[NOMBRE]</option>";
                                                }
                                          }
                                          else
                                          {
                                               echo '<select class="form-control input-sm" id="CboAsignado" name="CboAsignado" disabled="true">';
                                              echo '<option value="'.$_SESSION['xid_valido'].'">'.($_SESSION['nxUsuario']).'</option>';
                                          }
                                        ?>
                                    </select>
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Modificado por:</label><!--6-->
                                <div class="col-md-7"><!--6-->
                                    
                                    <select class="form-control input-sm" id="CboActualizo" name="CboActualizo" disabled="true">
                                       <option value="<?php echo $_SESSION['xid_valido']; ?>">
                                           <?php echo strtoupper(($_SESSION['nxUsuario'])); ?></option>
                                       
                                    </select>
                                    
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Estado del Reporte:</label><!--6-->
                                <div class="col-md-7"><!--6-->
                                    <select class="form-control input-sm" id="CboEstado" nom="CboEstado">
                                       
                                        <?php      
                                                $sql= ("SELECT * FROM ".$nom_bd.".CAT_ESTADOS_REPORTE");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                {
                                                echo"<option value='$row[ID_ESTADO_REPORTE]'>$row[ESTADO_REPORTE]</option>";
                                                }
                                        ?>
                                    </select>
                                    <br>
                                    <br>
                                    
                                </div>
                </div>
                
                <div class="form-group">
                                <label for="" class="col-md-5 ">Notificado Por:</label><!--6-->
                                <div id="dvnot" class="col-md-7"><!--6-->
                                    <input type="" class="form-control input-sm" id="notificadoPor" name="notificadoPor"
                                           autocomplete="off">
                                </div>
                </div>
                
                
                <div class="form-group ">
                <?php $admin=$_SESSION['nxAdmin']; if($admin == 1){
                    echo '<label for="" class="col-md-5 ">Revisado por supervisor</label>';
                    echo '<div class="col-md-7">';
                    echo '<input type="checkbox" id="revisado" name="revisado" >';
                    echo '</div>';
                    
                }
                else
              {
                  echo '<label for="" class="col-md-5 ">Revisado por supervisor</label>';
                  echo '<div class="col-md-7">';
                  echo '<input type="checkbox" id="revisado" name="revisado" disabled="TRUE">';
                  echo '</div>';
              }
                ?> 
                </div>
                
            </div> <!--Fin Formulario derecho-->   
        </div>  <!-- Fin 1ra Sección -->
        
<!-- Aqui empieza  Problemas -->
        
        <div id ="textarea" class="col-md-12"> <!--12-->
        <br>
        <br>
          <div class="col-md-2">  
              <label id="reporte">*Problema:</label>
          </div>
           
          
          <div class="col-md-4">
          <select class="form-control input-sm" id="CboProblema" name="CboProblema">
            <option value="0">--SELECCIONE PROBLEMA--</option>
            
          </select>
          </div>
           
        <div class="col-md-2">
             <label id="subcat">*Subcategoría:</label>
        </div>
          <div class="col-md-4">
          <select class="form-control input-sm" id="CboSubCat" name="CboSubCat">
            <option value="0">--SELECCIONE SUBCATEGORIA--</option>
            
          </select>
          </div>
        </div>
       
        <div class="col-md-12">
           <br>
          <textarea id="textReporte" name="textReporte" class="form-control input-sm" rows="4" placeholder="Notas Reporte"></textarea>
        </div>
        
        <!-- Aqui termina  Problemas -->
        
        
        
        <!-- Aqui empieza  Diagnostico -->
        
        <div id ="textarea" class="col-md-12"> <!--12-->
          <br>
          <div class="col-md-1">
          <label class="">Diagnóstico:</label>
          </div>
          <div class="col-md-1"></div>
          <div class="col-md-4">
          <select class="form-control input-sm" id="CboDiagnostico" name="CboDiagnostico">
            <option value="0">--SELECCIONE DIAGNOSTICO--</option>
          </select>
          <br>    
          </div>
          <div class="col-md-4"></div>
        </div>
        
        <div class="col-md-12">
        <textarea id="textDiagnostico" name="textDiagnostico" class="form-control input-sm" rows="4" placeholder="Notas Diagnostico"></textarea>
        </div> 
        
        <!-- Aqui termina Diagnostico -->
        
        
        <!-- Aqui empieza Actividad -->
        
        <div id ="textarea" class="col-md-12"> 
          <br>
          <div class="col-md-1">
          <label class="">Actividad:</label>
          </div>
          <div class="col-md-1"></div>
          <div class="col-md-4">
          <select class="form-control input-sm" id="CboActividad" name="CboActividad">
            <option value="0">--SELECCIONE ACTIVIDAD--</option>
          </select>
          </div>
        </div>
        <div class="col-md-12">
          <br>  
          <textarea id="textActividad" name="textActividad" class="form-control input-sm" rows="4" placeholder="Notas Actividad"></textarea>
        </div>
        
        <!-- Aqui termina Actividad --> 
        
        
        <!-- Aqui empieza  Solucion -->
        <div id ="textarea" class="col-md-12"> 
          <br>
          <div class="col-md-1">
          <label class="">Solucion:</label>
          </div>
          <div class="col-md-1"></div>
          <div class="col-md-4">
          <select class="form-control input-sm" id="CboSolucion" name="CboSolucion">
            <option value="0">--SELECCIONE SOLUCION--</option>
          </select>
          </div>
        </div>
        
        <div class="col-md-12">
          <br>
          <textarea id="textSolucion" name="textSolucion" class="form-control input-sm" rows="4" placeholder="NotaS Solucion"></textarea>
        </div>
        
        <div id ="textarea" class="col-md-12">
         <br>
         <br>
       </div>
    
    <!-- Fin Solucion -->
       
    </form>
</div>
    
    
        
<div class="modal fade bd-example-modal-sm" id="modalNuevoReporte" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header" id="modal-header">
        <h4 class="modal-title" id="myModalLabel">Confirmación</h4>
      </div>
      
      <div class="modal-body" id="respuesta">
      </div>
      <div class="modal-footer">
        <button type="button" id="boton" class="btn btn-light" data-dismiss="modal" onclick="regresa();">Aceptar</button>    
      </div>
    </div>
  </div>
</div> 
</body>
</html>
        
         
<?php
} else 
{
  header('Location: login/loginind.php');
}
?>