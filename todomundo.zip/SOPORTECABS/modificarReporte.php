<?php
include ("php/conexion.php");
include ("php/bitacora.php");
require 'php/superusuarios.php';

session_start();
if (isset($_SESSION['xusuario_valido'])) 
{

$idReporte= (is_numeric($_GET['id']))?$_GET['id']:0;
$fecha_reporte= $_GET['fecha_reporte'];
$user_asignado= (is_numeric($_GET['iduser']))?$_GET['iduser']:0;
$sistema= (is_numeric($_GET['idsistema']))?$_GET['idsistema']:0;
$aplicacion= (is_numeric($_GET['idaplicacion']))?$_GET['idaplicacion']:0;
$xUser= ucwords(strtolower(($_SESSION['nxUsuario']))); 
$xUser= convierte_carcter($xUser);
$xPerfil = $_SESSION['nxPerfil'];  
                  
Bitacora($idReporte, 0);


     

$query="SELECT A.ID_REPORTE, C.NOMBRE_SISTEMA,A.ID_UBICACION,A.TIPO_UBICACION,
D.NOMBRE_APP, A.FECHA_HORA_ALTA,
TO_CHAR(A.FECHA_HORA_MODIF,'DD/MM/YYYY HH24:MI:SS') AS FECHA_HORA_MODIF, 
A.ID_NOTIFICACION, E.NOMBRE_NOTIFICACION, A.NOTIFICADO_POR,
DECODE(A.REPORTADO,0,'NO',1,'SI') REPORTADO, A.REPORTADO_A,
DECODE(A.ESCALADO,0,'NO',1,'SI') ESCALADO, A.ESCALADO_A,
F.ESTADO_REPORTE, A.ID_ESTADO_REPORTE,
A.ID_USUARIO_ASIGNADO, B.NOMBRE AS USER_ASIGNADO, 
A.ID_USUARIO_MODIFICO, 
A.ID_USUARIO_REGISTRO, 
(SELECT B.NOMBRE FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS B WHERE B.ID=A.ID_USUARIO_REGISTRO) USER_CREO,
A.REPORTE, A.DIAGNOSTICO, A.ACTIVIDAD, A.SOLUCION,
A.RED_1, A.RED_7, A.RED_40, A.RED_AL,
A.RED_1_1, A.RED_1_2, A.RED_7_PUBLIMAX, A.REVISADO, A.ID_DIAGNOSTICO, A.ID_ACTIVIDAD, A.ID_SOLUCION, A.ID_PROBLEMA,
A.ID_SUBCATEGORIA";
//if($tabla!="")
    $query.=", G.NOMBRE AS NOMBRE ";

$query.="FROM ".$nom_bd.".REPORTES_CABS A, ".$nom_bd.".USUARIOS_SOPORTE_CABS B, ".$nom_bd.".CAT_SISTEMAS_CABS C, ".$nom_bd.".CAT_APP_CABS D, 
".$nom_bd.".CAT_VIA_NOTIFICACION E, ".$nom_bd.".CAT_ESTADOS_REPORTE F ";
//if($tabla!="")
{
    $query.=", CAT_UBICACIONES G, CAT_RELACION_UBICACION H ";
}
$query.="WHERE A.ID_USUARIO_ASIGNADO = B.ID AND
A.ID_SISTEMA = C.ID_SISTEMA AND 
A.ID_APP = D.ID_APP AND
E.ID_NOTIFICACION = A.ID_NOTIFICACION AND
F.ID_ESTADO_REPORTE = A.ID_ESTADO_REPORTE ";
//if($tabla!="")
{
   $query.="AND H.ID_UBICACION = A.ID_UBICACION AND G.ID_UBICACION = H.ID_UBICACION AND H.TIPO_UBICACION = A.TIPO_UBICACION ";
}

$query.="AND A.ID_REPORTE = ".$idReporte;


Bitacora($query, 0);
$res = oci_parse($conn, $query);
    
oci_execute($res);

 while ($datos = oci_fetch_array($res, OCI_ASSOC+OCI_RETURN_NULLS)) 
{
      $NomSistema =$datos['NOMBRE_SISTEMA'];
      $NomApp = $datos['NOMBRE_APP'];
      $id_user_asignado =$datos['ID_USUARIO_ASIGNADO'];
      $userAsignado = $datos['USER_ASIGNADO'];
      $textoReporte = $datos['REPORTE']; 
      $textoDiagnostico = $datos['DIAGNOSTICO'];
      $textoActividad = $datos ['ACTIVIDAD']; 
      $textoSolucion = $datos['SOLUCION'];
      $notificado = $datos ['NOTIFICADO_POR'];
      $reporA = $datos ['REPORTADO_A'];
      $escaCon = $datos ['ESCALADO_A'];
      $idEstadoRep = $datos ['ID_ESTADO_REPORTE'];
      $idViaNoti = $datos['ID_NOTIFICACION'];
      $idRed1 = $datos['RED_1'];
      $idRed7 = $datos['RED_7'];
      $idRed40 = $datos['RED_40'];
      $idRedAL = $datos['RED_AL'];
      $idRed1_1 = $datos ['RED_1_1'];
      $idRed1_2 =$datos['RED_1_2'];
      $idRedpublimax = $datos['RED_7_PUBLIMAX'];
      $idReportado =$datos['REPORTADO']; 
      $idEcalado =$datos['ESCALADO']; 
      $id_user_modifico = $datos['ID_USUARIO_MODIFICO'];
      $id_lugar = $datos['ID_UBICACION'];
      $tipo_lugar= $datos['TIPO_UBICACION'];
      $lugar_cad=(isset($datos['ID_UBICACION']))?($datos['NOMBRE']):"NO APLICA";
      $user_registro =$datos['USER_CREO'];
      $id_user_creo=$datos['ID_USUARIO_REGISTRO'];
      $fecha_modificacion = $datos['FECHA_HORA_MODIF'];
      $revisar = $datos['REVISADO'];
      $id_diag = $datos['ID_DIAGNOSTICO'];
      $id_acti = $datos['ID_ACTIVIDAD'];
      $id_solu = $datos['ID_SOLUCION'];
      $id_Prob = $datos['ID_PROBLEMA'];
      $id_subCat = $datos['ID_SUBCATEGORIA'];
}

$consulta="SELECT B.PROBLEMA, A.ID_PROBLEMA 
           FROM ".$nom_bd.".REPORTES_CABS A, ".$nom_bd.".CAT_PROBLEMAS_CABS B
           WHERE B.ID_PROBLEMA = A.ID_PROBLEMA AND
           A.ID_REPORTE=".$idReporte."";
      
$res = oci_parse($conn, $consulta);
oci_execute($res);
while ($datos = oci_fetch_array($res, OCI_ASSOC+OCI_RETURN_NULLS)) 
{
  $id_Problema = $datos['ID_PROBLEMA'];
  $nom_problema =$datos ['PROBLEMA'];   
}

$consulta1="SELECT B.SUBCATEGORIA, A.ID_SUBCATEGORIA 
            FROM ".$nom_bd.".REPORTES_CABS A, ".$nom_bd.".CAT_SUBCAT_PROBLEMAS_CABS B
            WHERE B.ID_SUBCATEGORIA = A.ID_SUBCATEGORIA AND
            A.ID_REPORTE=".$idReporte."";
      
$res = oci_parse($conn, $consulta1);
oci_execute($res);
while ($datos = oci_fetch_array($res, OCI_ASSOC+OCI_RETURN_NULLS)) 
{
  $id_subcat = $datos['ID_SUBCATEGORIA'];
  $nom_subcat =$datos ['SUBCATEGORIA'];   
}
 

?>

<!DOCTYPE html>

    <head>

        <title>Help Desk CABS</title>
        <!--<meta charset="utf-8">-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />
        
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href='//fonts.googleapis.com/css?family=Raleway:400,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        
        
        <link href="css/estilos.css" rel="stylesheet">

        <!--JS -->
        <script src="js/jquery-3.2.1.min.js"></script>
        
        <script type="text/javascript" src="js/index.js"></script>  
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="bootstrap/js/bootstrap.js"></script>
        <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

        <script languaje ="javascript">
            
            
        $(document).ready(function()
            {
                $("#CboProblema").change(function()
                {    
                  $("#CboProblema option:selected").each(function()
                  {
                    id_problema=$(this).val();
                    $.post("php/getCargaRelaciones.php", {id_problema: id_problema},
                    function(data)
                    {
                      if(data=="")
                      {  
                        $("#CboSubCat").html("<option value='-1'>--SELECCIONE SUBCATEGORIA--</option>");         
                      }     
                      else
                      {   
                          var x;
                          $("#CboSubCat").html(data);
                          x = document.getElementById("CboSubCat");

                          //Lanza evento change

                          if(x.length==1)
                          {  
                             $("#CboSubCat").triggerHandler("change");

                          }   
                      }

                    });         
                   });  
                   limpia_combo(["diagnostico","actividad","solucion"]);

                });
                
                 $("#CboSubCat").on("change",function()
                    { 
                      $("#CboSubCat option:selected").each(function()
                      { 
                          
                        id_subcat=$(this).val();
                        id_subcat_act=$(this).val();
                        id_subcat_sol=$(this).val();

                        $.post("php/getCargaRelaciones.php", {id_subcat: id_subcat},
                        function(data)
                        {
                          if(data=="")
                          {  
                            $("#CboDiagnostico").html("<option value='-1'>--SELECCIONE DIAGNOSTICO--</option>"); 

                          }     
                          else
                          {   
                            var y; 
                            $("#CboDiagnostico").html(data);
                            y = document.getElementById("CboDiagnostico")
                            //Lanza evento change

                            if(y.length==1)
                            {  $("#CboDiagnostico").triggerHandler("change");          

                            }   

                          }

                        });


                         $.post("php/getCargaRelaciones.php", {id_subcat_sol: id_subcat_sol},
                         function(data)
                         {
                           if(data=="")
                           {  
                             $("#CboSolucion").html("<option value='-1'>--SELECCIONE SOLUCION--</option>");

                           }     
                           else
                           {   
                             $("#CboSolucion").html(data);

                           }

                         });



                         $.post("php/getCargaRelaciones.php", {id_subcat_act: id_subcat_act},
                         function(data)
                         {
                           if(data=="")
                           {  
                             $("#CboActividad").html("<option value='-1'>--SELECCIONE ACTIVIDAD--</option>");

                           }     
                           else
                           {   
                             $("#CboActividad").html(data);

                           }

                         });

                       });
                    });
                    
                    
                    $("#CboDiagnostico").on("change",function()
                        { 
                          $("#CboDiagnostico option:selected").each(function()
                          {
                            id_actividad=$(this).val();
                            id_solucion=$(this).val();
                            $.post("php/getCargaRelaciones.php", {id_actividad: id_actividad},
                            function(data)
                            {
                              if(data=="")
                              {  
                                

                              }     
                              else
                              {   

                                 $("#CboActividad").html(data);

                              }

                            });

                            $.post("php/getCargaRelaciones.php", {id_solucion: id_solucion},
                            function(data)
                            {
                              if(data=="")
                              {  
                                

                              }     
                              else
                              {   
                                $("#CboSolucion").html(data);

                              }

                            });

                           });
                        });
            });    
            
          var objeto_reporte=null;
          
        function Problema_Subcat(){
                   
               $("#CboProblemas option:selected").each(function()
               {
                 id_problema=$(this).val();
                 $.post("php/getCargaRelaciones.php", {id_problema: id_problema},
                 function(data)
                 {
                   if(data=="")
                   {  
                     $("#CboSubCat").html("<option value='-1'>--SELECCIONE SUBCATEGORIA--</option>");         
                   }     
                   else
                   {   
                       
                       $("#CboSubCat").html(data);
                       
                   }

                 });         
                });  
               
            }
            
  function ejecuta_cambio_diag()
 { 
   $("#CboDiagnostico option:selected").each(function()
   {
     id_actividad=$(this).val();
     id_solucion=$(this).val();
     $.post("php/getCargaRelaciones.php", {id_actividad: id_actividad},
     function(data)
     {
       if(data=="")
       {  
         $("#CboActividad").html("<option value='0'>--SELECCIONE ACTIVIDAD--</option>");

       }     
       else
       {   
         
          $("#CboActividad").html(data);
      
       }

     });
     
     $.post("php/getCargaRelaciones.php", {id_solucion: id_solucion},
     function(data)
     {
       if(data=="")
       {  
         $("#CboSolucion").html("<option value='0'>--SELECCIONE SOLUCION--</option>");

       }     
       else
       {   
         $("#CboSolucion").html(data);

       }

     });
      
    });
 }
          
          function objReporte(red_1,red_7,red_40,red_AL,red_1_1, red_1_2, red_7_publimax, 
                              id_actualizo,estado_reporte,via_notificacion,notificado_por,
                              radio_reportado,radio_escalado,reportado_a,escalado_con,
                              texto_diagnostico, texto_actividad,texto_solucion,asignado,
                              revisado,idDiagnostico, idActividad, idSolucion, idProblema, idSubcategoria)                              
          {
            this.red_1              =red_1;
            this.red_7              =red_7;
            this.red_40             =red_40;
            this.red_AL             =red_AL;
            this.red_1_1            =red_1_1;
            this.red_1_2            =red_1_2;
            this.red_7_publimax     =red_7_publimax;
            this.id_actualizo       =id_actualizo;
            this.estado_reporte     =estado_reporte;
            this.via_notificacion   =via_notificacion;
            this.notificado_por     =notificado_por;
            this.radio_reportado    =radio_reportado;
            this.radio_escalado     =radio_escalado;
            this.reportado_a        =reportado_a;
            this.escalado_con       =escalado_con;
            this.texto_diagnostico  =texto_diagnostico;
            this.texto_actividad    =texto_actividad;
            this.texto_solucion     =texto_solucion;
            this.asignado           =asignado;
            this.revisado           =revisado;
            this.idDiagnostico      =idDiagnostico;
            this.idActividad        =idActividad;
            this.idSolucion         =idSolucion;
            this.idProblema         =idProblema;
            this.idSubcategoria     =idSubcategoria;
          }
          function obt_datos(tipo)
          {
              var ret=0;
              var red_1=0;
              var red_7 =0; 
              var red_40 =0; 
              var red_AL =0;
              var red_1_1=0;
              var red_1_2=0; 
              var red_7_publimax=0;
              
              $('input[type=checkbox]').each(function()
              {
                        if (this.checked) 
                        {
                            switch($(this).attr("id"))
                            {
                                case 'checkboxRed1':
                                    red_1=1;
                                break;
                                case 'checkboxRed7':
                                    red_7=1;
                                break;
                                case 'checkboxRed40':
                                    red_40=1;
                                break;
                                case 'checkboxRedAL':
                                    red_AL=1;
                                break;
                                case 'checkboxRed11':
                                    red_1_1=1;
                                break;
                                case 'checkboxRed12':
                                    red_1_2=1;
                                break;
                                case 'checkboxRedpublimax':
                                    red_7_publimax=1;
                                break;
                                
                            }
                        }
                    }); 
                    
                    var id_actualizo=$("#CboActualizo").val();
                    var estado_reporte=$("#CboEstado").val();
                    var via_notificacion = $("#CboViaNot").val();
                    var notificado_por = $("#notificadoPor").val();
                    var radio_reportado = ($("#radioRep").is(":checked"))?1:0;
                    var radio_escalado = ($("#radioEsc").is(":checked"))?1:0;
                    var reportado_a =$("#reportadoA").val();
                    var escalado_con = $("#escaladoA").val();
                    var asignado =$("#CboAsignado").val();
                    
                    var idProblema = $("#CboProblema").val();
                    var idDiagnostico = $("#CboDiagnostico").val();
                    var idActividad = $("#CboActividad").val();
                    var idSolucion = $("#CboSolucion").val();
                    var idSubcategoria = $("#CboSubCat").val();
                    
                    var texto_diagnostico = $("#textDiagnostico").val();
                    texto_diagnostico=texto_diagnostico.trim();
                    if(texto_diagnostico=="")
                        texto_diagnostico="Sin Datos";
                    var texto_actividad =$("#textActividad").val();
                    texto_actividad=texto_actividad.trim();
                    if(texto_actividad=="")
                        texto_actividad="Sin Datos";
                    var texto_solucion=$("#textSolucion").val();
                    texto_solucion=texto_solucion.trim();
                    if(texto_solucion=="")
                        texto_solucion="Sin Datos";
                    
                    var revisado = ($("#revisado").is(":checked"))?1:0;
                    
                    
                    
                    
                    if(tipo==1)
                    {
                        objeto_reporte=new objReporte(red_1,red_7,red_40,red_AL,red_1_1, red_1_2, red_7_publimax,
                                                      id_actualizo,estado_reporte,via_notificacion,notificado_por, 
                                                      radio_reportado,radio_escalado,reportado_a,escalado_con,
                                                      texto_diagnostico,texto_actividad,texto_solucion,asignado, 
                                                      revisado, idDiagnostico, idActividad, idSolucion,idProblema, 
                                                      idSubcategoria);
                    }else
                    {
                        if(objeto_reporte.red_1              ==red_1 &&
                            objeto_reporte.red_7              ==red_7 &&
                            objeto_reporte.red_40             ==red_40 &&
                            objeto_reporte.red_AL             ==red_AL &&
                            objeto_reporte.red_1_1            ==red_1_1 &&
                            objeto_reporte.red_1_2            ==red_1_2 &&
                            objeto_reporte.red_7_publimax     ==red_7_publimax &&
                            objeto_reporte.id_actualizo       ==id_actualizo &&
                            objeto_reporte.estado_reporte     ==estado_reporte &&
                            objeto_reporte.via_notificacion   ==via_notificacion &&
                            objeto_reporte.notificado_por     ==notificado_por &&
                            objeto_reporte.radio_reportado    ==radio_reportado &&
                            objeto_reporte.radio_escalado     ==radio_escalado &&
                            objeto_reporte.reportado_a        ==reportado_a &&
                            objeto_reporte.escalado_con       ==escalado_con &&
                            objeto_reporte.texto_diagnostico  ==texto_diagnostico &&
                            objeto_reporte.texto_actividad    ==texto_actividad &&
                            objeto_reporte.texto_solucion     ==texto_solucion &&
                            objeto_reporte.asignado           ==asignado &&
                            objeto_reporte.revisado           ==revisado &&
                            objeto_reporte.idDiagnostico      ==idDiagnostico &&
                            objeto_reporte.idActividad        ==idActividad &&
                            objeto_reporte.idSolucion         ==idSolucion &&
                            objeto_reporte.idProblema         ==idProblema &&
                            objeto_reporte.idSubcategoria     ==idSubcategoria)
                        {
                            ret=1;
                        }
                    }
                   return ret;
          }
          
            
          function validacion() {
            if(obt_datos(0)==1)
            {
              alert("No se ha hecho ningun cambio");
              return 0;  
            }
              $.ajax({
                               
                                success: function()
                                {
                                    
                                    $('#modalValidarCambios').modal
                                    ({
                                     show:true,
                                     backdrop:'static'
                                    });
                                 
                                }
                                
                            });  
              
              
          } 
      
          function guardar()
          {
              
                   
                    var red_1=0;
                    var red_7 =0; 
                    var red_40 =0; 
                    var red_AL =0;
                    var red_1_1=0;
                    var red_1_2=0; 
                    var red_7_publimax=0;
                    var revisado=0;
                    
                    $('input[type=checkbox]').each(function()
                    {
                        if (this.checked) 
                        {
                            switch($(this).attr("id"))
                            {
                                case 'checkboxRed1':
                                    red_1=1;
                                break;
                                case 'checkboxRed7':
                                    red_7=1;
                                break;
                                case 'checkboxRed40':
                                    red_40=1;
                                break;
                                case 'checkboxRedAL':
                                    red_AL=1;
                                break;
                                case 'checkboxRed11':
                                    red_1_1=1;
                                break;
                                case 'checkboxRed12':
                                    red_1_2=1;
                                break;
                                case 'checkboxRedpublimax':
                                    red_7_publimax=1;
                                break;
                                case 'revisado':
                                    if($("#revisado").attr("disabled") == 'disabled'){
                                        revisado=0;
                                    }else{
                                        revisado=1;}
                                break;
                            }
                        }
                    }); 
                    
                    var id_user_creo=$('#reporteCreo').val();
                    var id_actualizo=$("#CboActualizo").val();
                    var estado_reporte=$("#CboEstado").val();
                    var via_notificacion = $("#CboViaNot").val();
                    var notificado_por = $("#notificadoPor").val();                    
                    var radio_reportado = ($("#radioRep").is(":checked"))?1:0;
                    var radio_escalado = ($("#radioEsc").is(":checked"))?1:0;
                    var reportado_a =$("#reportadoA").val();
                    var escalado_con = $("#escaladoA").val();
                    var texto_reporte =$("#textReporte").val();
                    texto_reporte=texto_reporte.trim();
                    if(texto_reporte=="")
                        texto_reporte="Sin Datos";
                    var texto_diagnostico = $("#textDiagnostico").val();
                    texto_diagnostico=texto_diagnostico.trim();
                    if(texto_diagnostico=="")
                        texto_diagnostico="Sin Datos";
                    var texto_actividad =$("#textActividad").val();
                    texto_actividad=texto_actividad.trim();
                    if(texto_actividad=="")
                        texto_actividad="Sin Datos";
                    var texto_solucion=$("#textSolucion").val();
                    texto_solucion=texto_solucion.trim();
                    if(texto_solucion=="")
                        texto_solucion="Sin Datos";
                    
                    var id_Reporte= $('#idReporte').text();
                    id_Reporte=id_Reporte.trim();
                    
                   var fecha_reporte = $('#FHSolicitud').text();
                   fecha_reporte = fecha_reporte.trim();

                   var idProb =  $("#CboProblema").val();
                   var idSubcat = $("#CboSubCat").val();
                   var idDiag = $("#CboDiagnostico").val();
                   var idActi = $("#CboActividad").val();
                   var idSolu = $("#CboSolucion").val();
                   
                   var sistema = document.getElementById('CboSistema').value;
                   var aplicacion = document.getElementById('CboApp').value;
                   var user_asignado = document.getElementById('CboAsignado').value;
                   var lugar = document.getElementById('CboLugar').value;
                   
                   if(estado_reporte ==3)
                   {
                     if(idDiag == 0 || idActi == 0 || idSolu== 0 )
                     {
                        alert("Verifica el combo [Diagnostico, Actividad o Solucion]");
                        return 0;
                     }  
                   }
                   if(id_actualizo==0){
                       alert("Campor Requerido, seleccione un usuario");
                       $("#notificadoPor").focus();
                       return 0;
                   } 
                   var total=document.getElementById('hTotal').value;    
                    
                    var dataString = "idReporte=" + id_Reporte 
                                                    + "&FHSolicitud=" + fecha_reporte
                                                    + "&CboSistema=" + sistema
                                                    + "&CboApp=" + aplicacion
                                                    + "&CboAsignado=" + user_asignado
                                                    + "&checkboxRed1=" + red_1 
                                                    + "&checkboxRed7=" + red_7
                                                    + "&checkboxRed40=" + red_40 
                                                    + "&checkboxRedAL=" + red_AL
                                                    + "&checkboxRed11=" + red_1_1
                                                    + "&checkboxRed12=" + red_1_2
                                                    + "&checkboxRedpublimax=" + red_7_publimax
                                                    + "&CboActualizo=" + id_actualizo
                                                    + "&CboEstado=" + estado_reporte 
                                                    + "&CboViaNot=" + via_notificacion 
                                                    + "&notificadoPor=" + notificado_por 
                                                    + "&creadopor="+ id_user_creo
                                                    + "&lugar="+ lugar
                                                    + "&total_h="+total
                                                    + "&radioRep=" + radio_reportado 
                                                    + "&reportadoA=" + reportado_a
                                                    + "&radioEsc=" + radio_escalado
                                                    + "&escaladoA=" + escalado_con
                                                    + "&textReporte=" + texto_reporte
                                                    + "&textDiagnostico=" + texto_diagnostico
                                                    + "&textActividad=" + texto_actividad
                                                    + "&textSolucion=" + texto_solucion
                                                    + "&revisado=" + revisado
                                                    + "&CboProblema=" + idProb
                                                    + "&CboSubCat=" + idSubcat
                                                    + "&CboDiagnostico=" + idDiag
                                                    + "&CboActividad=" + idActi
                                                    + "&CboSolucion=" +idSolu
                                                    ;
                                                    
                                                   console.log(dataString);
                    $.ajax({
                                type: "POST",
                                dataType: 'html',
                                url: "php/actualizarReporte.php",
                                data: dataString,
                                success: function(resp)
                                {
                                    $('#res_modif').html(resp);
                                    $('#modalModifReporte').modal
                                    ({
                                     show:true,
                                     backdrop:'static'
                                    });
                                
                                }
                                
                            });  
            }
            
            function regresar()
                 {
                    var ruta= "index.php";
                    location.href = ruta;
                 }
            
            function seleccion (id, fecha_modif,reporte, diagnostico,actividad,
                                solucion, user_modif,
                                cbo_diagnostico, cbo_actividad, cbo_solucion,
                                cbo_problema, cbo_subcat){
                                  
                
               
             
               $('#fechaModif_view').html(fecha_modif);
               
               var susti_reporte= reporte.replace(/\\t/g,"\n");
               $('#reporte_detalle').val(susti_reporte);
               
               var susti_diagnostico= diagnostico.replace(/\\t/g,"\n");
               $('#diagnostico_detalle').val(susti_diagnostico);
               
               var susti_actividad= actividad.replace(/\\t/g,"\n");
               $('#actividad_detalle').val(susti_actividad);
              
               var susti_solucion= solucion.replace(/\\t/g,"\n");
               $('#solucion_detalle').val(susti_solucion);
               
               $('#actualizadoPor_view option:selected').text(user_modif);
              
               
               $('#CboProb_detalle option:selected').text(cbo_problema);
               $('#CboSubcat_detalle option:selected').text(cbo_subcat);
               $('#CboDiag_detalle option:selected').text(cbo_diagnostico);
               $('#CboActividad_detalle option:selected').text(cbo_actividad);
               $('#CboSolucion_detalle option:selected').text(cbo_solucion);
              
          } 
          
          function seleccionModal (id, fecha_modif, nom_Reportado, nom_Escalado, 
                                notifi_por,user_modif, status_modif, notificacion, 
                                red1,red7,red40, redAL,
                                red1_1, red1_2, red7_publimax,
                                reportado,escalado, usuario_asignado, revisado
                                ){
                                  
                
               if(red1===1)
                 $('#red1_detalle').prop( "checked", true);
               else
                 $('#red1_detalle').prop( "checked", false);
               
               if(red7===1)
                 $('#red7_detalle').prop( "checked", true);
               else
                 $('#red7_detalle').prop( "checked", false);
               
               if(red40===1)
                 $('#red40_detalle').prop( "checked", true);
               else
                 $('#red40_detalle').prop( "checked", false);
             
               if(redAL===1)
                 $('#redAL_detalle').prop( "checked", true);
               else
                 $('#redAL_detalle').prop( "checked", false);
             
               if(red1_1===1)
                 $('#red11_detalle').prop( "checked", true);
               else
                 $('#red11_detalle').prop( "checked", false);
             
               if(red1_2===1)
                 $('#red12_detalle').prop( "checked", true);
               else
                 $('#red12_detalle').prop( "checked", false);
             
               if(red7_publimax===1)
                 $('#red7publimax_detalle').prop( "checked", true);
               else
                 $('#red7publimax_detalle').prop( "checked", false);
             
               if(revisado===1)
                 $('#revisado_detalle').prop( "checked", true);
               else
                 $('#revisado_detalle').prop( "checked", false);
             
               $('#FHModifDetalle').html(fecha_modif);
               
               $('#reportadoA_detalle').val(nom_Reportado);
               $('#escaladoA_detalle').val(nom_Escalado);
               $('#notificado_detalle').val(notifi_por); 
               
               $('#actualizo_detalle option:selected').text(user_modif);
              
               $('#estado_detalle option:selected').text(status_modif);
               $('#notifi_detalle option:selected').text(notificacion);
               $('#asignado_detalle option:selected').text(usuario_asignado);
               
              if(reportado===1)
                 $('#reportado_detalle').prop( "checked", true);
               else
                 $('#reportado_detalle').prop( "checked", false);
             
             if(escalado===1)
                 $('#escalado_detalle').prop( "checked", true);
               else
                 $('#escalado_detalle').prop( "checked", false);
             
             
             
             
              $('#detalle_reporte').modal
                 ({
                    show:true, 
                    keyboard: true,
                    backdrop: false
                    
                    
                 }); 
                 
              $('.modal-dialog').draggable({
                handle: ".modal-header"
                });
             
          } 
          function recarga()
          {
              location.reload(true);
          }
          
          function combo_notificacion()
        {
            var index=$('#CboViaNot').val();         
            $('#dvnot').empty();
            if(index==6 || index==7)
            {                
                $('#dvnot').append("<select id='notificadoPor' class='form-control input-sm'></select>");
                
                 $.ajax({
                                type: "POST",
                                dataType: 'html',
                                url: "php/getCombos.php",
                                data: "dvnot=1",
                                success: function(resp){
                                   console.log(resp); 
                                  $('#notificadoPor').append(resp);  
                                }
                                
                            });
            }else{
                $('#dvnot').append('<input type="text" id="notificadoPor" class="form-control input-sm  " id="notificadoPor" name="notificadoPor" autocomplete="off">');
            }
        }
        
        
       function mostrar ()
        {
          div = document.getElementById('formulario');
          div.style.display = '';
        }
        
        function limpia_combo(opc)
                { 
                  var elemento,texto;
                  
                  for(var i=0,j=opc.length ; i<j ; i++)
                  {
                    opcion=opc[i]; 
                    switch(opcion)
                    {
                      case 'problema':
                        elemento="CboProblema";
                        texto="--SELECCIONE PROBLEMA--";
                      break;
                      
                      case 'subcat':
                        elemento="CboSubCat";
                        texto="--SELECCIONE SUBCATEGORIA--";
                      break;
                      
                      case 'diagnostico':
                        elemento="CboDiagnostico";
                        texto="--SELECCIONE DIAGNOSTICO--";
                      break;
                      
                      case 'solucion':
                        elemento="CboSolucion";
                        texto="--SELECCIONE SOLUCION--";
                      break;
                      
                      case 'actividad':
                        elemento="CboActividad";
                        texto="--SELECCIONE ACTIVIDAD--";
                      break;  
                    
                  }
                   
                    $("#"+elemento).empty();
                    $("#"+elemento).append("<option value=-1>"+texto+"</option>");
                  
                  }
                 
                }
        
        </script>
        
        <!-- Encabezado - Barra de Titulo -->
        
</head>

<body style="background-color:#FFFFFF; color:#000000;" onload="obt_datos(1)"> 
    
    <nav class="navbar navbar-light bg-light navbar-fixed-top"  role ="navigation">
            
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-left">
                    <a class="navbar-brand" style="cursor:pointer;" href="index.php"><i class=" icono izquierda fa fa-home" ></i> Inicio </a>
                    <?php
                    
                    if($xPerfil ==0){
                        echo '<a class="navbar-brand" style="cursor:pointer;" href="#"><i class=" icono izquierda fa fa-edit" ></i> Crear Reporte</a> ';  
                    }else
                    {
                        echo'<a class="navbar-brand" style="cursor:pointer;" href="reporte.php"><i class=" icono izquierda fa fa-edit" ></i> Crear Reporte</a>';
                    }
                    ?>
                    
                </ul>
                <ul class="nav navbar-nav navbar-center">
                    <span class="navbar-text h3" id="titulo">
                                Control Sporte CABS
                    </span>  
                </ul>
                
                <ul class="nav navbar-nav navbar-right">
                    <div class="nav dropdown right ">
                        <button class="btn btn-xs dropdown-toggle " style="background: #0277bd" type="button" id="menudesplegable" data-toggle="dropdown">
                          <a class="navbar-brand " style="color: white" ><i class="icono izquierda fa fa-user" style="color: white"></i> <?php  echo $xUser; ?></a> 
                        </button>
                <ul class="  dropdown-menu">
                  <li><a class="navbar-brand" style="cursor:pointer;"href="manualcontrolcabs/manual.html" target="_blank" ><i class="fa fa-question-circle"></i> Manual CABS</a></li>
                     <li>
                        <?php
                           if(!$Super_Usario )
                              echo '<a class="navbar-brand" style="cursor:pointer;"href="login/cerrar.php" ><i class=" fa fa-lock"></i> Cerrar Sesión  </a>  ';
                        ?>  
                     </li>
                </ul>
	  
               
            </div>
            
            <script>
                $('.dropdown-toggle').dropdown();
            </script>
        </nav>
    
        <div class="col-md-7"> <!-- Formulario -->
            <br>
            <br>
            <br>
           <nav class="navbar navbar-light bg-light" id="nav" role ="navigation">
                    <span class="navbar-text">
                        <h4>Seguimiento de Reporte</h4>
                    </span>
                    
                    <div class="collapse navbar-collapse navbar-ex1-collapse">
                        <ul class="navbar-right" id="nav_botones">
                         <?php
                         $admin=$_SESSION['nxAdmin'];
                         
                         if(($idEstadoRep==3 && $admin==0) || ($xPerfil==0)){
                             echo '<button  onclick ="validacion();" id="boton" class="btn" type="submit" value="btnenviar" disabled><i class=" icono izquierda fa fa-save"></i>  Guardar</button>'; 
                         }
                         else
                          { 
                              echo'<button  onclick ="validacion();" id="boton" class="btn" type="submit" value="btnenviar"><i class=" icono izquierda fa fa-save"></i>  Guardar</button>';
                              
                          }
                                             
                         /* if($xPerfil ==0){
                               echo '<button  onclick ="validacion();" id="boton" class="btn" type="submit" value="btnenviar" disabled><i class=" icono izquierda fa fa-save"></i>  Guardar</button>'; 
                          }
                          else
                          { 
                              echo'<button  onclick ="validacion();" id="boton" class="btn" type="submit" value="btnenviar"><i class=" icono izquierda fa fa-save"></i>  Guardar</button>';
                              
                          }*/
                         
                         ?>
                                 
                        </ul>
                    </div>
          </nav>
            
           
            <!-- Inicio formulario -->
            <form id ="actualizarReporte" class="form-horizontal"  role="form"  method="POST" onsubmit="return false" action="return false">
            <div class="col-md-6"> <!--Izquierdo-->
                <br>
                <div class="form-group">
                    <label for=""  class="col-md-4">ID Reporte:</label>
                        <div class="col-md-7">
                            <label type="" class="form-control input-sm" id="idReporte" name="idReporte"autocomplete="off" disabled="true">  
                                    <?php
                                        echo $idReporte;
                                     ?>
                             </label> 
                        </div>
                </div>
                
                <div class="form-group">
                    <label for="" class="col-md-4 ">Sistema:</label>
                             <div class="col-md-7">
                                <select class="form-control input-sm" id="CboSistema" name="CboSistema" disabled="true">
                                        <?php    
                                            echo"<option value='$sistema' selected> $NomSistema</option>";
                                        ?>
                                </select>
                            </div>
                </div>
                
                <div class="form-group">
                    <label for="" class="col-md-4 ">Aplicación:</label>
                             <div class="col-md-7">
                                    <select required class="form-control input-sm" id="CboApp" name="CboApp" disabled="true">
                                            <?php    
                                                echo"<option value='$aplicacion' selected> $NomApp</option>";   
                                            ?>
                                     </select>
                            </div>
                </div>
                
                <div class="form-group">
                        <label for="" class="col-md-4 ">Lugar:</label>
                            <div class="col-md-7">
                                    <select class="form-control input-sm" id="CboLugar" name="CboLugar" disabled="true">
                                        <label type="" class="form-control" id="CboLugar" name="CboLugar" autocomplete="off" disabled="true">                                            
                                        <?php
                                                echo "<option value='".$id_lugar."-".$tipo_lugar."'>".$lugar_cad."</option>";
                                        ?>
                                        </label>
                                    </select>
                               
                            </div>       
                </div>
                
                <div class="form-group">
                        <label for="" class="col-md-4 ">Red:</label>
                            <div class="col-sm-8 form-check">
                                     <?php
                                            if ($idRed1 == 1)
                                                {
                                                
                                                  echo '<label class="checkbox-inline ">
                                                       <input type="checkbox" id="checkboxRed1" name="checkboxRed1" checked> 1 
                                                       </label>';
                                                                                            
                                                } else 
                                                { 
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed1" name="checkboxRed1"> 1 
                                                       </label>';
                                                
                                                }


                                            if ($idRed7 == 1)
                                                {
                                                
                                                  echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed7" name="checkboxRed7" checked> 7 
                                                       </label>';
                                                  
                                                } else 
                                                {
                                                  echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed7" name="checkboxRed7"> 7 
                                                       </label>';
                                                   
                                                }

                                            if ($idRed40==1)
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed40" name="checkboxRed40" checked> 40 
                                                       </label>';
                                                  
                                                } else 
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed40" name="checkboxRed40"> 40 
                                                       </label>';
                                                  
                                                }

                                            if($idRedAL == 1)
                                                {
                                                   echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRedAL" name="checkboxRedAL" checked> A+ 
                                                       </label>';
                                                  
                                                } else 
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRedAL" name="checkboxRedAL"> A+ 
                                                       </label>';
                                                  
                                                }
                                    ?>
                                
                            
                                <br>
                                <br>
                                    <?php
                                            if($idRed1_1 == 1)
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed11" name="checkboxRed11" checked> 1-1 Hr
                                                       </label>';
                                                 
                                                } else 
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed11" name="checkboxRed11"> 1-1 Hr
                                                       </label>';
                                                 
                                                }   
                                                
                                            if($idRed1_2 == 1)
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed12" name="checkboxRed12" checked> 1-2 Hr
                                                       </label>';
                                                 
                                                } else 
                                                {
                                                     echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRed12" name="checkboxRed12"> 1-2 Hr
                                                       </label>';
                                                  
                                                }       
                                            if($idRedpublimax == 1)
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRedpublimax" name="checkboxRedpublimax" checked> 7 Publimax
                                                       </label>';
                                                  
                                                } else 
                                                {
                                                    echo '<label class="checkbox-inline">
                                                       <input type="checkbox" id="checkboxRedpublimax" name="checkboxRedpublimax"> 7 Publimax 
                                                       </label>';
                                                 
                                                }       
                                    ?>
                            
                            </div>
                </div>        
                
                <div class="form-group">
                    <br>
                        <label for="" class="col-md-4 ">Vía de Noti:</label>
                            <div class="col-md-7">
                                
                                <select class="form-control input-sm" id="CboViaNot" name="CboViaNot" onchange="combo_notificacion();">
                                    <option value="0">--SELECCIONE--</option>
                                        <?php      
                                                $sql= ("SELECT * FROM ".$nom_bd.".CAT_VIA_NOTIFICACION");
                                                $resultado = oci_parse($conn, $sql);
                                                oci_execute($resultado);
                                                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                 {

                                                    if($idViaNoti == $row['ID_NOTIFICACION'])
                                                        {
                                                            $selected ="selected"; 
                                                                echo "<option value='".$idViaNoti."' ".$selected.">". 
                                                                     $row['NOMBRE_NOTIFICACION']."</option>";
                                                        } else
                                                        {
                                                                echo "<option value='".$row['ID_NOTIFICACION']."'>".$row['NOMBRE_NOTIFICACION']."</option>";
                                                        }   
                                                }  
                                        ?>
                                </select>
                                
                            </div>
                </div>
                
                <div class="form-group">
                    <label for="" class="col-md-4 ">Reportado a:</label><!--6-->
                         <div class="col-md-7"><!--6-->
                            <input type="" class="form-control input-sm" id="reportadoA" name="reportadoA" autocomplete="off" 
                                   value="<?php
                                     echo $reporA;
                                    ?>"/>
                         </div>
                </div>
               
               <div class="form-group">
                    <label for="" class="col-md-4 ">Escalado con:</label><!--6-->
                        <div class="col-md-7"><!--6-->
                                <input type="" class="form-control input-sm" id="escaladoA" name="escaladoA" autocomplete="off"
                                       value="<?php      
                                          echo $escaCon;
                                            ?>" />
                        </div>
                </div>
               
               <br>
               <br>
                
                
            </div> <!-- Fin izquierdo-->
            
            
            <div class="col-md-6"> <!-- Inicio Formulario derecho --->
                
                <div class="form-group">
                    <br>
                    <label for="" class="col-md-5"  >Fecha de solicitud:</label> <!--6-->
                            <div class="col-md-7"> <!--6-->
                                 <label type="" class="form-control input-sm" id="FHSolicitud" name="FHSolicitud" autocomplete="off" disabled="true" >
                                             <?php
                                                    echo $fecha_reporte;
                                             ?> 
                                 </label>
                            </div>
                </div>
                
                
                 <div class="form-group">
                                <label for="" class="col-md-5"  >Fecha de Modif:</label> <!--6-->
                                 <div class="col-md-7"> <!--6-->
                                     <label type="" class="form-control input-sm" id="FHmodif" name="FHmodif"
                                            autocomplete="off" disabled="true" >
                                         <?php
                                             echo $fecha_modificacion;
                                         ?>
                                         
                                     </label>
                                </div>
                </div>
                
                <div class="form-group">
                    <label for="" class="col-md-5 ">Creó el reporte:</label><!--6-->
                            <div class="col-md-7"><!--6-->
                                <select class="form-control input-sm" id="reporteCreo" name="reporteCreo" disabled="true">
                                    <?php    
                                            echo"<option value='".$id_user_creo."' selected> $user_registro</option>";
                                    ?>
                                </select>
                            </div>
                </div>
                
                <div class="form-group">
                    <label for="" class="col-md-5 ">Asignado a:</label><!--6-->
                            <div class="col-md-7"><!--6-->
                              <select class="form-control input-sm" id="CboAsignado" name="CboAsignado">
                                   <option value="0">--SELECCIONE--</option>
                                <option value="<?php echo $_SESSION['xid_valido']; ?>"><?php echo ($_SESSION['nxUsuario']); ?></option>
                                <?php   
                                    $sql= ("SELECT ID, NOMBRE FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS
                                            WHERE SOPORTE =1
                                            ORDER BY NOMBRE ASC");
                                    $resultado = oci_parse($conn, $sql);
                                    oci_execute($resultado);
                                    while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                    {
                                      if($id_user_asignado == $row['ID'])
                                      {
                                        $selected ="selected"; 
                                        echo "<option value='".$id_user_asignado."' ".$selected.">
                                             ".$row['NOMBRE']."</option>";
                                      } 
                                      else
                                      {
                                        echo "<option value='".$row['ID']."'>".$row['NOMBRE']."</option>";

                                      }    
                                    }
                                 ?>
                                </select>
                                  
                                

                            </div>
                </div>
                
                <div class="form-group">
                    <label for="" class="col-md-5 ">Modificado por:</label><!--6-->
                        <div class="col-md-7"><!--6-->
                            <select class="form-control input-sm" id="CboActualizo" name="CboActualizo"  disabled="true">
                                <option value="<?php echo $_SESSION['xid_valido']; ?>"><?php echo strtoupper(($_SESSION['nxUsuario']));?></option>
                                              
                            </select>
                        </div>
                </div>
                
                 <div class="form-group">
                    <label for="" class="col-md-5 ">Estado del Reporte:</label><!--6-->
                            <div class="col-md-7"><!--6-->
                                <select class="form-control input-sm" id="CboEstado" nom="CboEstado">
                                    <option value="0">--SELECCIONE--</option>
                                            <?php 

                                                    $sql= ("SELECT * FROM ".$nom_bd.".CAT_ESTADOS_REPORTE");
                                                    $resultado = oci_parse($conn, $sql);
                                                    oci_execute($resultado);
                                                    while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                        {
                                                            if($idEstadoRep == $row['ID_ESTADO_REPORTE'])
                                                            {
                                                                $selected ="selected"; 
                                                                echo "<option value='".$idEstadoRep."' ".$selected.">". 
                                                                    $row['ESTADO_REPORTE']."</option>";
                                                            }
                                                            else
                                                            {
                                                                echo "<option value='".$row['ID_ESTADO_REPORTE']."'>".$row['ESTADO_REPORTE']."</option>";
                                                            }   
                                                        }
                                            ?>
                                </select>
                            </div>
                </div>
                
                <div class="form-group">
                    <br>
                    <label for="" class="col-md-5 ">Notificado Por:</label><!--6-->
                        <div id="dvnot" class="col-md-7"><!--6-->
                            <?php
                              if($idViaNoti !=6 || $idViaNoti !=7){
                            ?>
                            <input type="text" class="form-control input-sm" id="notificadoPor" name="notificadoPor" autocomplete="off" style="text-transform: uppercase;"
                                    value="<?php 
                                      echo $notificado;
                              ?>" />
                            <?php                               
                            }
                              else
                            {
                                  $sql_notifi="SELECT ID, NOMBRE FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS
                                               WHERE PERFIL = 1
                                               ORDER BY NOMBRE ASC";
    
    
                                 $resultado = oci_parse($conn, $sql_notifi);
                                 oci_execute($resultado);
                                 
                                 echo "<select id='notificadoPor' class='form-control'>";
                                 echo "<option value='0'>--SELECCIONE--</option>";
   
                                while ($row = oci_fetch_array($resultado, OCI_ASSOC + OCI_RETURN_NULLS)) 
                                {
        
                                  if($notificado==$row['NOMBRE'])
                                    echo "<option value='".$row['NOMBRE']."' selected>".$row['NOMBRE']."</option>";
                                  else
                                    echo "<option value='".$row['NOMBRE']."'>".$row['NOMBRE']."</option>";
        
                                  
                                }
                                echo "</select>";
                            }
                            ?>
                        </div>
                </div>
                
              
            <div class="form-group ">
                <?php $admin=$_SESSION['nxAdmin']; if($admin == 1){
                    if($revisar == 1)
                    {
                        echo '<label for="" class="col-md-5 ">Revisado por supervisor:</label>';
                        echo '<div class="col-md-7">';
                        echo '<input type="checkbox" id="revisado" name="revisado" checked="TRUE" >';
                        echo '</div>';
                    }
                    else
                    {
                        echo '<label for="" class="col-md-5 ">Revisado por supervisor:</label>';
                        echo '<div class="col-md-7">';
                        echo '<input type="checkbox" id="revisado" name="revisado">';
                        echo '</div>';
                    
                    }
                    
              }
              else
              {
                  if($revisar == 1)
                    {
                        echo '<label for="" class="col-md-5 ">Revisado por supervisor:</label>';
                        echo '<div class="col-md-7">';
                        echo '<input type="checkbox" id="revisado" name="revisado" checked="TRUE"  disabled="TRUE">';
                        echo '</div>';
                    }
                    else
                    {
                        echo '<label for="" class="col-md-5 ">Revisado por supervisor:</label>';
                        echo '<div class="col-md-7">';
                        echo '<input type="checkbox" id="revisado" name="revisado" disabled="TRUE">';
                        echo '</div>';
                    
                    }
                  
                 
              }
                  ?> 
            </div>
            
                
            </div> <!--Fin formulario derecho -->
            
<!--Inico Formulario inferior-->
    
    <!--Inico  Reporte-->
    <div class="col-md-12">  <!--Cajas texto--->
      <br>
      <div class="col-md-2">
      <label class="">*Problema:</label>
      </div>
      <div class="col-md-4">
        <?php  
          $admin=$_SESSION['nxAdmin'];
             if($admin)
            {
                echo '<select class="form-control input-sm" id="CboProblema" name="CboProblema">';
                echo '<option value="0">--SELECCIONE PROBLEMA--</option>';

           
           
                $sql= ("SELECT B.PROBLEMA, B.ID_PROBLEMA
                        FROM  ".$nom_bd.".CAT_APP_CABS A, ".$nom_bd.".CAT_PROBLEMAS_CABS B, ".$nom_bd.".CAT_REL_APP_PROBLEMAS C
                        WHERE C.ID_APP = A.ID_APP AND 
                              C.ID_PROBLEMA = B.ID_PROBLEMA AND 
                              A.ID_APP = $aplicacion
                        ORDER BY B.PROBLEMA ASC");
                
                $resultado = oci_parse($conn, $sql);
                oci_execute($resultado);
                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                    {
                        if($id_Prob == $row['ID_PROBLEMA'])
                     {
                       $selected ="selected"; 
                       echo "<option value='".$id_Prob."' ".$selected.">". 
                            $row['PROBLEMA']."</option>";
                     }
                     else
                     {
                        echo "<option value='".$row['ID_PROBLEMA']."'>".$row['PROBLEMA']."</option>";
                     }   
                  }
                 echo '</select>';   
            } 
            else
            {
               echo '<select class="form-control input-sm" id="CboProblema" name="CboProblema" disabled>';
               echo "<option value='$id_Prob' selected> $nom_problema </option>";  
               echo '</select> ';
            }
          
            ?>
      </div>
      
       <div class="col-md-2">
      <label class="">*Subcategoría:</label>
      </div>
      <div class="col-md-4">
         <?php  
           $admin=$_SESSION['nxAdmin'];
             if($admin)
            {
                echo '<select class="form-control input-sm" id="CboSubCat" name="CboSubCat">';
                echo '<option value="0">--SELECCIONE SUBCATEGORIA--</option>';
             
                $sql= ("SELECT A.ID_SUBCATEGORIA , A.SUBCATEGORIA 
                        FROM CAT_SUBCAT_PROBLEMAS_CABS A, CAT_REL_PROB_SUBCAT B
                        WHERE A.ID_SUBCATEGORIA = B.ID_SUBCATEGORIA AND B.ID_PROBLEMA = $id_Prob
                        ORDER BY A.SUBCATEGORIA ASC");
                
                $resultado = oci_parse($conn, $sql);
                oci_execute($resultado);
                while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                    {
                        if($id_subCat == $row['ID_SUBCATEGORIA'])
                     {
                       $selected ="selected"; 
                       echo "<option value='".$id_subCat."' ".$selected.">". 
                            $row['SUBCATEGORIA']."</option>";
                     }
                     else
                     {
                        echo "<option value='".$row['ID_SUBCATEGORIA']."'>".$row['SUBCATEGORIA']."</option>";
                     }   
                  }
                  
                echo '</select> ';
            }
            else
            {
                 echo '<select class="form-control input-sm" id="CboSubCat" name="CboSubCat" disabled>';
                 echo "<option value='$id_subCat' selected> $nom_subcat </option>";  
                 echo '</select> ';
            }
          ?>
      </div>
    </div>
    
    <div class="col-md-12">
      <br>
      <textarea id="textReporte" name="textReporte" class="form-control input-sm" rows="4" disabled><?php  
        echo $textoReporte;?>
      </textarea>
      <br>
    </div>
    <!--Fin Reporte-->
    
    <!--Inico Diagnostico-->
    <div class="col-md-12">
     
      <div class="col-md-1">
        <label class="">Diagnóstico:</label>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-4">
          <select class="form-control input-sm" id="CboDiagnostico" name="CboDiagnostico" onchange="ejecuta_cambio_diag()" >
          <option value='0'>--SELECCIONE DIAGNOSTICO--</option>
                                            <?php 

                                                    $sql= ("SELECT B.DIAGNOSTICO, B.ID_DIAGNSTICO 
                                                            FROM ".$nom_bd.".CAT_REL_SUBCAT_DIAG A, ".$nom_bd.".CAT_DIAGNOSTICOS_CABS B
                                                            WHERE A.ID_SUBCATEGORIA=".$id_subcat." 
                                                            AND B.ID_DIAGNSTICO=A.ID_DIAGNOSTICO 
                                                            ORDER BY B.DIAGNOSTICO");
                                                    $resultado = oci_parse($conn, $sql);
                                                    oci_execute($resultado);
                                                    while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                        {
                                                            if($id_diag == $row['ID_DIAGNSTICO'])
                                                            {
                                                                $selected ="selected"; 
                                                                echo "<option value='".$id_diag."' ".$selected.">". 
                                                                    $row['DIAGNOSTICO']."</option>";
                                                            }
                                                            else
                                                            {
                                                                echo "<option value='".$row['ID_DIAGNSTICO']."'>".$row['DIAGNOSTICO']."</option>";
                                                            }   
                                                        }
                                            ?>
        </select>
      </div>
    </div>
  
    <div class="col-md-12">
      <br>  
      <textarea id="textDiagnostico" name="textDiagnostico" class="form-control input-sm" rows="4"><?php echo $textoDiagnostico;?></textarea> 
    </div>
    
    <!--Fin Diagnostico--->
    
    <!--Inicio Actividad--->
    <div class="col-md-12">
      <br>
      <div class="col-md-1">
        <label class="">Actividad:</label>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-4">
        <select class="form-control input-sm" id="CboActividad" name="CboActividad" >
           <option value='0'>--SELECCIONE ACTIVIDAD--</option>
             <?php 
               if($id_diag != 0)
               {
                 $sql= ("SELECT B.ACTIVIDAD, B.ID_ACTIVIDAD 
                         FROM ".$nom_bd.".CAT_REL_DIAG_ACTIVIDAD A, ".$nom_bd.".CAT_ACTIVIDADES_CABS B
                         WHERE A.ID_DIAGNOSTICO=".$id_diag." 
                         AND B.ID_ACTIVIDAD=A.ID_ACTIVIDAD
                         ORDER BY B.ACTIVIDAD");
                 $resultado = oci_parse($conn, $sql);
                 oci_execute($resultado);
                 while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                 {
                   if($id_acti == $row['ID_ACTIVIDAD'])
                   {
                     $selected ="selected"; 
                     echo "<option value='".$id_acti."' ".$selected.">". 
                     $row['ACTIVIDAD']."</option>";
                   }
                   else
                   {
                     echo "<option value='".$row['ID_ACTIVIDAD']."'>".$row['ACTIVIDAD']."</option>";
                   }   
                 }
               } 
               else 
               {
                                                    
                  $sql2= ("SELECT UNIQUE(A.ID_ACTIVIDAD), B.ACTIVIDAD
                           FROM ".$nom_bd.".CAT_REL_DIAG_ACTIVIDAD A, ".$nom_bd.".CAT_ACTIVIDADES_CABS B, ".$nom_bd.".CAT_REL_SUBCAT_DIAG C, 
                           ".$nom_bd.".CAT_DIAGNOSTICOS_CABS D
                           WHERE 
                           C.ID_SUBCATEGORIA=".$id_subcat."
                           AND D.ID_DIAGNSTICO=C.ID_DIAGNOSTICO
                           AND A.ID_DIAGNOSTICO= D.ID_DIAGNSTICO 
                           AND B.ID_ACTIVIDAD = A.ID_ACTIVIDAD
                          ORDER BY B.ACTIVIDAD");
                                                   
                  $resultado = oci_parse($conn, $sql2);
                  oci_execute($resultado);
                                                    
                  while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                  {
                     if($id_acti == $row['ID_ACTIVIDAD'])
                     {
                       $selected ="selected"; 
                       echo "<option value='".$id_acti."' ".$selected.">". 
                            $row['ACTIVIDAD']."</option>";
                     }
                     else
                     {
                       echo "<option value='".$row['ID_ACTIVIDAD']."'>".$row['ACTIVIDAD']."</option>";
                     }   
                  }
               }
             ?>    
        </select>
      </div>
    </div>
    
    <div class="col-md-12">
      <br>  
      <textarea id="textActividad" name="textActividad" class="form-control input-sm" rows="4"><?php echo $textoActividad;?></textarea>
    </div>
    <!--Fin Actividad--->
    
    <!--Inicio Solucion--->
    <div class="col-md-12">
      <br>  
      <div class="col-md-1">
        <label class="">Solución:</label>
      </div>
      <div class="col-md-1"></div>
      <div class="col-md-4">
        <select class="form-control input-sm" id="CboSolucion" name="CboSolucion" >
          <option value='0'>--SELECCIONE SOLUCION--</option>
                                            <?php 
                                                if($id_diag != 0)
                                                {
                                                    $sql= ("SELECT B.SOLUCION, B.ID_SOLUCION 
                                                            FROM ".$nom_bd.".CAT_REL_DIAG_SOLUCION A, ".$nom_bd.".CAT_SOLUCIONES_CABS B
                                                            WHERE A.ID_DIAGNOSTICO=".$id_diag." AND B.ID_SOLUCION=A.ID_SOLUCION
                                                            ORDER BY B.SOLUCION");
                                                    
                                                    $resultado = oci_parse($conn, $sql);
                                                    oci_execute($resultado);
                                                    
                                                    while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                        {
                                                            if($id_solu == $row['ID_SOLUCION'])
                                                            {
                                                                $selected ="selected"; 
                                                                echo "<option value='".$id_solu."' ".$selected.">". 
                                                                    $row['SOLUCION']."</option>";
                                                            }
                                                            else
                                                            {
                                                                echo "<option value='".$row['ID_SOLUCION']."'>".$row['SOLUCION']."</option>";
                                                            }   
                                                       }
                                                } else {
                                                    $sql2= ("SELECT UNIQUE(A.ID_SOLUCION), B.SOLUCION
                                                            FROM ".$nom_bd.".CAT_REL_DIAG_SOLUCION A, ".$nom_bd.".CAT_SOLUCIONES_CABS B, 
                                                            ".$nom_bd.".CAT_REL_SUBCAT_DIAG C, ".$nom_bd.".CAT_DIAGNOSTICOS_CABS D
                                                            WHERE
                                                            C.ID_SUBCATEGORIA=".$id_subcat." 
                                                            AND D.ID_DIAGNSTICO =C.ID_DIAGNOSTICO
                                                            AND A.ID_DIAGNOSTICO=D.ID_DIAGNSTICO
                                                            AND A.ID_SOLUCION =B.ID_SOLUCION
                                                            ORDER BY B.SOLUCION");
                                                    
                                                    $resultado = oci_parse($conn, $sql2);
                                                    oci_execute($resultado);
                                                    
                                                    while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                                        {
                                                            if($id_solu == $row['ID_SOLUCION'])
                                                            {
                                                                $selected ="selected"; 
                                                                echo "<option value='".$id_solu."' ".$selected.">". 
                                                                    $row['SOLUCION']."</option>";
                                                            }
                                                            else
                                                            {
                                                                echo "<option value='".$row['ID_SOLUCION']."'>".$row['SOLUCION']."</option>";
                                                            }   
                                                       }
                                                    
                                                }
                                            ?>
        </select>
    </div>
    </div>
   
    <div class="col-md-12">
      <br>  
      <textarea id="textSolucion" name="textSolucion" class="form-control input-sm" rows="4"><?php echo $textoSolucion;?></textarea>
      <br>
      <br>
    </div>
    <!--Fin Solucion--->
     
    </div> 
    </form>  
            
<!-- Inicio historico-->
  <div class="col-md-5"> 
      <br>
      <br>
      <br>
    <nav class="navbar navbar-light bg-light" id="nav">
      <span class="navbar-text">
        <h4>Historial</h4>
      </span>
    </nav>
            
            
    <div  id="scroll_tabla" class="col-md-12">    <!-- Tabla -->
            <?php

                    include ("php/conexion.php");   

                    $query="SELECT A.ID_REPORTE,
                            TO_CHAR(A.FECHA_HORA_MODIF,'DD/MM/YYYY HH24:MI:SS') AS FECHA_HORA_MODIF, 
                            A.ID_USUARIO_MODIFICO, B.NOMBRE, A.ID_ESTADO_REPORTE, 
                            A.ID_USUARIO_ASIGNADO, 
                           (SELECT B.NOMBRE FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS B WHERE B.ID=A.ID_USUARIO_ASIGNADO) USER_ASIGNADO,
                            C.ESTADO_REPORTE,A.REPORTADO_A, A.ESCALADO_A, A.NOTIFICADO_POR,
                            A.REPORTE, A.DIAGNOSTICO AS TEXT_DIAG, A.ACTIVIDAD AS TEXT_ACT, 
                            A.SOLUCION AS TEXT_SOLU,
                            A.ID_NOTIFICACION, D.NOMBRE_NOTIFICACION,
                            A.RED_1, A.RED_7, A.RED_40, A.RED_AL,
                            A.RED_1_1, A.RED_1_2, A.RED_7_PUBLIMAX,
                            A.REPORTADO, A.ESCALADO, A.REVISADO, E.PROBLEMA, F.SUBCATEGORIA,
                            G.DIAGNOSTICO, A.ID_DIAGNOSTICO AS ID_DIAG, H.ACTIVIDAD, I.SOLUCION
                            
                            
                            FROM ".$nom_bd.".REPORTES_CABS_HISTORICO A, ".$nom_bd.".USUARIOS_SOPORTE_CABS B, ".$nom_bd.".CAT_ESTADOS_REPORTE C,
                            ".$nom_bd.".CAT_VIA_NOTIFICACION D, ".$nom_bd.".CAT_PROBLEMAS_CABS E, ".$nom_bd.".CAT_SUBCAT_PROBLEMAS_CABS F,
                            ".$nom_bd.".CAT_DIAGNOSTICOS_CABS G, ".$nom_bd.".CAT_ACTIVIDADES_CABS H, ".$nom_bd.".CAT_SOLUCIONES_CABS I
                            
                         
                            WHERE A.ID_USUARIO_MODIFICO = B.ID AND
                            A.ID_ESTADO_REPORTE = C.ID_ESTADO_REPORTE  AND
                            A.ID_NOTIFICACION = D.ID_NOTIFICACION AND
                            A.ID_PROBLEMA = E.ID_PROBLEMA AND
                            A.ID_SUBCATEGORIA = F.ID_SUBCATEGORIA AND
                            A.ID_DIAGNOSTICO = G.ID_DIAGNSTICO AND
                            A.ID_ACTIVIDAD = H.ID_ACTIVIDAD AND
                            A.ID_SOLUCION = I.ID_SOLUCION AND
                            A.ID_REPORTE = ".$idReporte."
                            ORDER BY TO_DATE(TO_CHAR(A.FECHA_HORA_MODIF,'DD/MM/YYYY HH24:MI:SS'),'DD/MM/YYYY HH24:MI:SS') DESC";

                    Bitacora("Checa esta consulta lizz: ".$query, 0);
                    $resultado = oci_parse($conn, $query);

                    oci_execute($resultado);

                            echo "<table id='tabla_historial' border='1' class='table table-hover'>
                                  <thead>

                                         <tr>
                                                <th>FECHA MODIFICACION</th>
                                                <th>MODIFICADO POR</th>
                                                <th>ESTADO REPORTE</th>
                                                <th>DETALLE </th>
                                        </tr> 
                                   </thead>";
                            $continua=FALSE;
                    while ($tabla_historial= oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                        {
                            if($continua){
                            $fecha_modif = $tabla_historial['FECHA_HORA_MODIF'];
                            $user_modif = $tabla_historial['NOMBRE'];
                            $id_usuario_asignado =$tabla_historial['ID_USUARIO_ASIGNADO'];
                            $status_modif =$tabla_historial['ESTADO_REPORTE'];
                            $nom_Reportado = $tabla_historial['REPORTADO_A'];
                                
                            $nom_Escalado = $tabla_historial['ESCALADO_A'];
                                
                            
                            $notifi_por = $tabla_historial['NOTIFICADO_POR'];
                            $reporte =$tabla_historial['REPORTE'];
                                 $reporte = str_replace("\n", '\t', $reporte);
                                 
                                 $reporte = addslashes($reporte);
                            
                            $diagnostico = $tabla_historial['TEXT_DIAG'];
                                 $diagnostico = str_replace("\n", '\t', $diagnostico);
                                 
                                 $diagnostico = addslashes($diagnostico);
                                 
                            $actividad = ($tabla_historial['TEXT_ACT']);
                                $actividad = str_replace("\n", '\t', $actividad);
                                $actividad = addslashes($actividad);
                                
                                
                            $solucion = $tabla_historial['TEXT_SOLU'];
                                $solucion = str_replace("\n", '\t',  $solucion);   
                                
                                $solucion = addslashes($solucion);
                            
                            $notificacion = $tabla_historial['NOMBRE_NOTIFICACION'];
                            $red1 =$tabla_historial['RED_1'];
                            $red7 = $tabla_historial['RED_7'];
                            $red40 = $tabla_historial['RED_40'];
                            $redAL = $tabla_historial['RED_AL'];
                            $red1_1 =$tabla_historial['RED_1_1'];
                            $red1_2 = $tabla_historial['RED_1_2'];
                            $red7_publimax = $tabla_historial['RED_7_PUBLIMAX'];
                            $reportado =$tabla_historial['REPORTADO'];
                            $escalado =$tabla_historial['ESCALADO'];
                            $usuario_asignado =$tabla_historial['USER_ASIGNADO'];
                            $revisado_detalle =$tabla_historial['REVISADO'];
                            $nomprob_detalle =$tabla_historial['PROBLEMA'];
                            $nomsubcat_detalle = $tabla_historial['SUBCATEGORIA'];
                            $nomdiag_detalle = $tabla_historial['DIAGNOSTICO'];
                            $nomacti_detalle = $tabla_historial['ACTIVIDAD'];
                            $nomsol_detalle = $tabla_historial['SOLUCION'];

                            echo  "<tr id='".$tabla_historial['ID_REPORTE']."' class='selectable input-sm'                         
                                     onclick='mostrar(),seleccion(id, \"".$fecha_modif."\",
                                    \"".$reporte."\",\"".$diagnostico."\", \"".$actividad."\", 
                                    \"".$solucion."\", \"".$user_modif."\", \"".$nomdiag_detalle."\",
                                    \"".$nomacti_detalle."\", \"".$nomsol_detalle."\", 
                                    \"".$nomprob_detalle."\",  \"".$nomsubcat_detalle."\")'>";

                            echo"   <td>".$tabla_historial['FECHA_HORA_MODIF']."</td>
                                    <td>".$tabla_historial['NOMBRE']."</td>
                                    <td>".$tabla_historial['ESTADO_REPORTE']."</td>
                                    <td align='center'> <button onclick ='seleccionModal(id, 
                                    \"".$fecha_modif."\", \"".$nom_Reportado."\",
                                    \"".$nom_Escalado."\", \"".$notifi_por."\",
                                    \"".$user_modif."\", 
                                    \"".$status_modif."\", \"".$notificacion."\",
                                    $red1, $red7, $red40, $redAL, $red1_1,$red1_2,$red7_publimax,
                                    $reportado,$escalado, \"".$usuario_asignado."\", $revisado_detalle)' 
                                    id='boton_masdetalle'
                                    title='Ver detalle faltante'
                                    class='btn'><i class='fa fa-plus-circle fa-lg'></i> 
                                    </button>
                                    </td>
                                 </tr>"; 
                            
                          

                                  
                            }else{
                                $continua=true;
                            }
                        }

                           $total = oci_num_rows($resultado);
                           echo "<input type='hidden' id='hTotal' value='".$total."'>";
                           $total=$total-1;
                           if($total<0)
                               $total=0;
                            
                            echo " <label>Actualizaciones: ".$total."</label> </br></br>";     
                            echo "</table>\n";
            ?>
    </div> <!--Fin Historico -->
  </div> <!--Fin Tabla -->
 
  
 <!-- INICIO DIV´S PROBLEMA, SUBCAT, DIAGNOSTICO, ACTIVIDAD Y SOLUCION-->
 
  <div  id="formulario" class="col-md-5"style="display:none;">
 
      <div id ="textarea" class="col-md-12">
          <br>
          <br>
          <br>
          <br>
          <br>
       </div>
      
      <div class="col-md-12">
        <br>
          <label class="col-md-2">Problema:</label>
          <div class="col-md-4">
             <select class="form-control input-sm" id="CboProb_detalle" name="CboProb_detalle" disabled="true" >
              <?php
                    echo  "<option value='' selected>$nomprob_detalle</option>";   
             ?>
             </select> 
          </div>
          
           <label class="col-md-2">Subcat:</label>
          <div class="col-md-4">
             <select class="form-control input-sm" id="CboSubcat_detalle" name="CboSubcat_detalle" disabled="true" >
              <?php
                    echo  "<option value='' selected>$nomsubcat_detalle</option>";   
             ?>
             </select> 
          </div>
      </div>
 
    <div id ="textarea" class="col-md-12"> 
        <br>
      <label class="col-md-2">Fecha Modif:</label>
      <div class="col-md-6">
        <label type="" class="form-control input-sm" id="fechaModif_view" name="fechaModif_view"
               accesskey=""autocomplete="off" disabled="true"></label>
      </div>
    </div>
 
    <div class="col-md-12">
       <label class="col-md-2">Modificó:</label>  
       <div class="col-md-6">
         <select class="form-control input-sm" id="actualizadoPor_view" name="actualizadoPor_view" disabled="true" >
        <option value=""></option>
        </select>  
       </div> 

    </div>
    <!-- Inicio Diagnostico -->
    <div class="col-md-12">
        <br>
       
      <div class="col-md-2">
        <label class="">Diagnóstico: </label>
      </div>
     
      <div class="col-md-6">
        <select class="form-control input-sm" id="CboDiag_detalle" name="CboDiag_detalle" disabled="true">
          <?php 
          
            echo  "<option value='' selected> $nomdiag_detalle</option>";  
            Bitacora("id diagnostico".$idDiag_detalle."nom diagnostico". $nomdiag_detalle,0);
           
          ?>
        </select>  
      </div>
    </div>
    
    <div class="col-md-12">
      <br>  
      <textarea id="diagnostico_detalle" name="diagnostico_detalle" class="form-control input-sm" rows="4" disabled="true"></textarea>  
    </div>
    <!-- Fin Diagnostico -->
    
    <!-- Inicio Actividad -->
    <div class="col-md-12">
      <br>
      <div class="col-md-2">
        <label class="">Actividad:</label>
      </div>
     
      <div class="col-md-6">
        <select class="form-control input-sm" id="CboActividad_detalle" name="CboActividad_detalle" disabled="true">
          <?php    
            echo"<option value='' selected>$nomacti_detalle</option>";   
          ?>
        </select>    
      </div>
    </div>
    
    <div class="col-md-12">
      <br>  
      <textarea id="actividad_detalle" name="actividad_detalle" class="form-control input-sm" rows="4" disabled="true"></textarea>
    </div>
    <!-- Fin Actividad -->
    
    <!-- Inicio Solucion -->
    <div class="col-md-12">
      <br>  
      <div class="col-md-2">
        <label class="">Solución:</label>
      </div>
      
      <div class="col-md-6">
        <select class="form-control input-sm" id="CboSolucion_detalle" name="CboSolucion_detalle" disabled="true">
           <?php    
            echo"<option value='' selected>$nomsol_detalle</option>";   
          ?>
        </select>       
      </div>
    </div>
    
    <div class="col-md-12">
      <br>  
      <textarea id="solucion_detalle" name="solucion_detalle" class="form-control input-sm" rows="4" disabled="true">
      </textarea>
      <br>
      <br>
    </div>
    
    <!-- Fin Solucion -->
 </div>
 
 <div class="modal fade bd-example-modal-sm" id="modalModifReporte" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header" id="modal-header">
        <h4 class="modal-title" id="myModalLabel">Confirmación</h4>
      </div>
      <div class="modal-body" id="res_modif">
      </div>
      <div class="modal-footer">
        <button type="button" id="boton" class="btn btn-light" data-dismiss="modal" onclick="recarga();">Aceptar</button>    
      </div>
    </div>
  </div>
</div> 
    
<div class="modal fade bd-example-modal-sm" id="modalValidarCambios" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header" id="modal-header">
        <h4 class="modal-title" id="myModalLabel">Guardar cambios</h4>
      </div>
      <div class="modal-body">
        <label> ¿Desea guardar los cambios?  </label>
      </div>
      <div class="modal-footer">
        <button  onclick="guardar();" type="button" id="boton" class="btn" data-dismiss="modal"> Si </button> 
        <button type="button" id="boton" class="btn " data-dismiss="modal"> No </button>
      </div>
    </div>
  </div>
</div> 

<div class="modal fade"  tabindex="-1" role="dialog" id="detalle_reporte">
  <div class="modal-dialog modal-lg" >
    <div class="modal-content" >
      <div class="modal-header" >
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>  
        <br>
        <nav class="navbar navbar-light bg-light" id="nav">
          <span class="navbar-text">
            <h4>Detalle del Reporte </h4>
          </span>
        </nav>   
      </div>
    
        <!-- MODAL HISTORICO -->
      <div class="modal-body" style="width: 898px; height: 450px; color:#000000;">
        <div class="col-md-12"> <!-- Inicio -->
          <form id ="verdetalle_reporte" class="form-horizontal"  role="form"  method="POST" onsubmit="return false" action="return false">
            <div class="col-md-6"> <!--izquierdo-->
              <div class="form-group">
                <label for=""  class="col-md-4">ID Reporte:</label>
                  <div class="col-md-7">
                    <label type="" class="form-control input-sm" id="idReporteDetalle" name="idReporteDetalle"
                     autocomplete="off" disabled="true" >  
                     <?php
                       echo $idReporte;
                     ?>
                    </label> 
                  </div>
              </div>
                        
    <div class="form-group">
      <label for="" class="col-md-4 ">Sistema:</label>
      <div class="col-md-7">
        <select class="form-control input-sm" id="CboSistemaDetalle" name="CboSistemaDetalle" disabled="true" >
          <?php    
            echo"<option value='$sistema' selected> $NomSistema</option>";
          ?> 
        </select>
      </div>
    </div>
                        
    <div class="form-group">
      <label for="" class="col-md-4 ">Aplicación:</label>
      <div class="col-md-7">
        <select required class="form-control input-sm" id="CboAppDetalle" name="CboAppDetalle" disabled="true">
          <?php    
            echo"<option value='$aplicacion' selected> $NomApp</option>";   
          ?> 
        </select>
      </div>
    </div>
                        
    <div class="form-group">
      <label for="" class="col-md-4 ">Lugar:</label>
        <div class="col-md-7">
          <select class="form-control input-sm" id="CboLugarDetalle" name="CboLugarDetalle" disabled="true">
            <?php
              echo "<option value='".$id_lugar."'>".$lugar_cad."</option>";
            ?> 
          </select>
        </div>
    </div>
                        
    <div class="form-group">
      <label for="" class="col-md-4 ">Red:</label>
      <div class="col-md-8">
        <label class="checkbox-inline">
          <input type="checkbox"  disabled="true"  id="red1_detalle" name="red1_detalle"> 1
        </label>
                                    
        <label class="checkbox-inline">
          <input type="checkbox" disabled="true"  id="red7_detalle" name="red7_detalle"> 7
        </label>
                                    
        <label class="checkbox-inline">
          <input type="checkbox"  disabled="true"  id="red40_detalle" name="red40_detalle"> 40
        </label>
                                    
        <label class="checkbox-inline">
          <input type="checkbox" disabled="true"  id="redAL_detalle" name="redAL_detalle"> A+
        </label>                        
        <br>
                                 
        <label class="checkbox-inline">
          <input type="checkbox" disabled="true" id="red11_detalle" name="red11_detalle"> 1-1 Hr
        </label>
                                    
        <label class="checkbox-inline">
          <input type="checkbox" disabled="true" id="red12_detalle" name="red12_detalle"> 1-2 Hr
        </label>
                                    
        <label class="checkbox-inline">
          <input type="checkbox" disabled="true" id="red7publimax_detalle" name="red7publimax_detalle"> 7 Publimax
        </label>
                                    
                                    
       </div>
   </div>
                        
   <div class="form-group">
   <br>
   <label for="" class="col-md-4 ">Vía de Noti:</label>
   <div class="col-md-7">
     <select class="form-control input-sm" id="notifi_detalle" name="notifi_detalle" disabled="true">
       <option value="0">--SELECCIONE--</option>
     </select>
                                    
   </div>
   </div>
   
    <div class="form-group">
     <label for="" class="col-md-4 ">Reportado a:</label><!--6-->
     <div class="col-md-7"><!--6-->
      <input type="" class="form-control input-sm" id="reportadoA_detalle" name="reportadoA_detalle"
       autocomplete="off" disabled="true">
      </input>
     </div>
    </div>
                        
    <div class="form-group">
    <label for="" class="col-md-4 "> Escalado con:</label><!--6-->
    <div class="col-md-7"><!--6-->
      <input type="" class="form-control input-sm" id="escaladoA_detalle" name="escaladoA_detalle"
       autocomplete="off" disabled="true"/>
    </div>
    </div>            
    
    </div>  
    <!--Fin izquierdo-->
                    
    <div class="col-md-6"> <!--derecho-->
    <div class="form-group">
      <label for="" class="col-md-5"  >Fecha de solicitud:</label> <!--6-->
    <div class="col-md-7"> <!--6-->
      <label type="" class="form-control input-sm" id="FHSolicitudDetalle" name="FHSolicitudDetalle"
       autocomplete="off" disabled="true" >
         <?php
           echo $fecha_reporte;
         ?>
      </label>
    </div>
    </div>
                        
    <div class="form-group">
    <label for="" class="col-md-5">Fecha de Modif:</label> <!--6-->
    <div class="col-md-7"> <!--6-->
    <label type="" class="form-control input-sm" id="FHModifDetalle" name="FHModifDetalle"
     autocomplete="off" disabled="true" >
    </label>
    </div>
    </div>
                        
    <div class="form-group">
    <label for="" class="col-md-5 ">Creó el reporte:</label><!--6-->
    <div class="col-md-7"><!--6-->
      <select class="form-control input-sm" id="reporteCreodetalle" name="reporteCreodetalle" disabled="true">
        <?php    
          echo"<option value='' selected> $user_registro</option>";
        ?>
      </select>  
    </div>
    </div>
                        
    <div class="form-group">
    <label for="" class="col-md-5 ">Asignado a:</label><!--6-->
    <div class="col-md-7"><!--6-->
      <select class="form-control input-sm" id="asignado_detalle" name="asignado_detalle" disabled="true">
        <?php
          echo"<option value='$id_usuario_asignado' selected> $usuario_asignado</option>";
        ?>  
      </select>
    </div>
    </div>
                        
    <div class="form-group">
    <label for="" class="col-md-5 ">Actualizó:</label><!--6-->
    <div class="col-md-7"><!--6-->
      <select class="form-control input-sm" id="actualizo_detalle" name="actualizo_detalle" disabled="true" >
        <option value="">--SELECCIONE--</option>
      </select>
    </div>
    </div>
    
    <div class="form-group">
    <label for="" class="col-md-5">Estado del Reporte:</label><!--6-->
    <div class="col-md-7"><!--6-->
      <select class="form-control input-sm" id="estado_detalle" nom="estado_detalle" disabled="true">
        <option value="0">--SELECCIONE--</option>
      </select>
    </div>
    </div>
                        
    <div class="form-group">
    <label for="" class="col-md-5">Notificado Por:</label><!--6-->
    <div class="col-md-7"><!--6-->
      <input type="text" class="form-control input-sm" id="notificado_detalle" name="notificado_detalle"
       autocomplete="off" disabled="true" style="text-transform: uppercase;">
    </div>
    </div>
                       
    <div class="form-group ">
    <label for="" class="col-md-5 ">Revisado por supervisor</label>
    <div class="col-md-7">
      <input type="checkbox" id="revisado_detalle" name="revisado_detalle" disabled="true">
    </div>
    </div>
    </div> <!--Fin derecho-->
    
</body>
</html>
<?php
}
else 
{
  header('Location: login/loginind.php');
}
?>

