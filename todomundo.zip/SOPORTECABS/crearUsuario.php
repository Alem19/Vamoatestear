<?php
include ("php/conexion.php");
date_default_timezone_set('America/Mexico_City');
session_start();
if (isset($_SESSION['xusuario_valido'])) 
{  
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Agregar usuario</title>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href="css/estilos.css" rel="stylesheet">
        <link href='//fonts.googleapis.com/css?family=Raleway:400,300' rel='stylesheet' type='text/css'>
	    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"

        <!--JS-->
        <script src="js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/index.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="bootstrap/js/bootstrap.js"></script>
        
    </head>
    <body style="background-color:#FFFFFF; color:#000000;">
        <!-- Encabezado - Barra de Titulo -->
        <div class="col-md-8">
            <div class="col-md-13">
            <!--Barra-->
                <nav class="navbar navbar-light bg-light" id="nav" role ="navigation">
                    <span class="navbar-text">
                        <h4> Nuevo Usuario</h4>
                    </span>       
                    <div class="collapse navbar-collapse navbar-ex1-collapse">
                        <ul class="navbar-right" id="nav_botones">
                            <button  onclick ="Limpiar();" class="btn" id="boton" type="button" value="btncancelar"><i class=" icono izquierda fa fa-eraser"></i> Limpiar</button>
                            <button  onclick ="validar();" class="btn" id="boton" type="submit" value="btnenviar"><i class=" icono izquierda fa fa-save"></i> Guardar</button>            
                            </ul>
                        </div>
                </nav>
        </div> <!-- Fin Encabezado -->

        <form id ="crearReporte" class="form-horizontal"  role="form"  method="POST" onsubmit="return false" action="return false">
            <!-- Inicio 1ra Sección - Formulario -->   
            <div class="col-md-13" id="formulario">
                <!-- Inicio Formulario izquierdo -->
                <div class="col-md-6" id="seccion">
                    <div class="form-group">
                        <label for="" id="IdReporte" class="col-md-5">ID Reporte:</label>
                        <div class="col-md-7">
                            <input type="" class="form-control input-sm" id="idReporte" name="idReporte" autocomplete="off" disabled="true" >
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Sistema: *</label>
                        <div class="col-md-7">
                            <select class="form-control input-sm" id="CboSistema" name="CboSistema" required>
                                <option value="0">--SELECCIONE--</option>
                                    <?php      
                                        $sql= ("SELECT ID_SISTEMA, NOMBRE_SISTEMA FROM ".$nom_bd.".CAT_SISTEMAS_CABS ORDER BY NOMBRE_SISTEMA ASC");
                                        $resultado = oci_parse($conn, $sql);
                                        oci_execute($resultado);
                                        while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS))
                                        {
                                            echo"<option value='$row[ID_SISTEMA]'>$row[NOMBRE_SISTEMA]</option>";
                                        }
                                    ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Aplicación: *</label>
                        <div class="col-md-7">
                            <select required class="form-control input-sm" id="CboApp" name="CboApp">
                                <option value='0'>--SELECCIONE--</option>";
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Lugar: *</label>
                        <div class="col-md-7">
                            <select class="form-control input-sm" id="CboLugar" name="CboLugar">
                                <option value="0">--SELECCIONE--</option>            
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="" class="col-md-5">Red: * </label>
                        <div class="col-md-7 form-check">
                            <label class="checkbox-inline">
                                <input type="checkbox" id="checkboxRed1" name="checkboxRed1"> 1
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="checkboxRed7" name="checkboxRed7"> 7
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="checkboxRed40" name="checkboxRed40"> 40
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="checkboxRedAL" name="checkboxRedAL"> A+
                            </label><br>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="checkboxRed1-1" name="checkboxRed1-1"> 1-1 Hr
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="checkboxRed1-2" name="checkboxRed1-2"> 1-2 Hr 
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" id="Red7Publimax" name="Red7Publimax"> 7 Publimax 
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                    </div>

                    <div class="form-group">
                        <label for="" class="col-md-5 ">Vía de Notificación: *</label>
                        <div class="col-md-7">
                            <select class="form-control input-sm" id="CboViaNot" name="CboViaNot" onchange="combo_notificacion()">
                                <option value="0">--SELECCIONE--</option>
                                <?php
                                    $sql= ("SELECT * FROM ".$nom_bd.".CAT_VIA_NOTIFICACION ORDER BY NOMBRE_NOTIFICACION ASC");
                                    $resultado = oci_parse($conn, $sql);
                                    oci_execute($resultado);
                                    while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                    {
                                        echo"<option value='$row[ID_NOTIFICACION]'>$row[NOMBRE_NOTIFICACION]</option>";
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Reportado a:</label><!--6-->
                        <div class="col-md-7"><!--6-->
                            <input type="" class="form-control input-sm" id="reportadoA" name="reportadoA" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="form-group">
                                    <label for="" class="col-md-5 "> Escalado con:</label><!--6-->
                                    <div class="col-md-7"><!--6-->
                                        <input type="" class="form-control input-sm" id="escaladoA" name="escaladoA" autocomplete="off">
                                    </div>
                    </div>
                        
                </div><!-- Fin Formulario izquierdo -->
    
                <!-- Inicio Formulario derecho--->
                <div class="col-md-6" id="seccion2"> 
                    <div class="form-group">
                        <label for="" class="col-md-5">Fecha de solicitud:</label> <!--6-->
                        <div class="col-md-7"> <!--6-->              
                            <?php 
                                $admin=$_SESSION['nxAdmin'];
                                if($admin)
                                {
                                    echo  '<input class="form-control input-sm" type="datetime-local" name="FHSolicitud" id="FHSolicitud" value="'.date("Y-m-d")."T".date("H:i").'">';
                                }
                                else
                                {
                                    echo  '<input class="form-control input-sm" type="datetime-local" name="FHSolicitud" id="FHSolicitud" disabled="TRUE" value="'.date("Y-m-d")."T".date("H:i").'" >';
                                }
                            ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Creó el reporte:</label><!--6-->
                        <div class="col-md-7"><!--6-->
                            <select class="form-control input-sm" id="CboUserCreo" name="CboUserCreo" disabled="true">
                                <option value="<?php echo $_SESSION['xid_valido']; ?>"><?php echo strtoupper(($_SESSION['nxUsuario'])); ?></option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Asignado a: *</label><!--6-->
                        <div class="col-md-7"><!--6-->
                            <?php
                                $admin=$_SESSION['nxAdmin'];
                                if($admin == 1)
                                {
                                    echo '<select class="form-control input-sm" id="CboAsignado" name="CboAsignado" required >';
                                        echo '<option value="0">--SELECCIONE--</option>';
                                            $sql= ("SELECT ID, NOMBRE FROM ".$nom_bd.".USUARIOS_SOPORTE_CABS
                                                    WHERE SOPORTE = 1
                                                    ORDER BY NOMBRE ASC");
                                            $resultado = oci_parse($conn, $sql);
                                            oci_execute($resultado);
                                            while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                            {
                                                echo"<option value='$row[ID]'>$row[NOMBRE]</option>";
                                            }
                                }
                                else
                                {
                                    echo '<select class="form-control input-sm" id="CboAsignado" name="CboAsignado" disabled="true">';
                                    echo '<option value="'.$_SESSION['xid_valido'].'">'.($_SESSION['nxUsuario']).'</option>';
                                }
                            ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="col-md-5 ">Modificado por:</label><!--6-->
                        <div class="col-md-7"><!--6-->
                            <select class="form-control input-sm" id="CboActualizo" name="CboActualizo" disabled="true">
                                <option value="<?php echo $_SESSION['xid_valido']; ?>">
                                    <?php echo strtoupper(($_SESSION['nxUsuario'])); ?></option>       
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Estado del Reporte:</label><!--6-->
                        <div class="col-md-7"><!--6-->
                            <select class="form-control input-sm" id="CboEstado" nom="CboEstado">
                                <?php
                                    $sql= ("SELECT * FROM ".$nom_bd.".CAT_ESTADOS_REPORTE");
                                    $resultado = oci_parse($conn, $sql);
                                    oci_execute($resultado);
                                    while ($row = oci_fetch_array($resultado, OCI_ASSOC+OCI_RETURN_NULLS)) 
                                    {
                                        echo"<option value='$row[ID_ESTADO_REPORTE]'>$row[ESTADO_REPORTE]</option>";
                                    }
                                ?>
                            </select>
                            <br>
                            <br>            
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="" class="col-md-5 ">Notificado Por:</label><!--6-->
                        <div id="dvnot" class="col-md-7"><!--6-->
                            <input type="" class="form-control input-sm" id="notificadoPor" name="notificadoPor" autocomplete="off">
                        </div>
                    </div>
                    
                    <div class="form-group ">
                        <?php 
                            $admin=$_SESSION['nxAdmin']; 
                            if($admin == 1)
                            {
                                echo '<label for="" class="col-md-5 ">Revisado por supervisor</label>';
                                echo '<div class="col-md-7">';
                                echo '<input type="checkbox" id="revisado" name="revisado" >';
                                echo '</div>';    
                            }
                            else
                            {
                                echo '<label for="" class="col-md-5 ">Revisado por supervisor</label>';
                                echo '<div class="col-md-7">';
                                echo '<input type="checkbox" id="revisado" name="revisado" disabled="TRUE">';
                                echo '</div>';
                            }
                        ?>
                    </div>
                </div> <!--Fin Formulario derecho-->   
            </div>  <!-- Fin 1ra Sección -->
            
            <!-- Aqui empieza  Problemas -->
            <div id ="textarea" class="col-md-12"> <!--12-->
                <br>
                <br>
                <div class="col-md-2">  
                    <label id="reporte">*Problema:</label>
                </div>
                
                <div class="col-md-4">
                    <select class="form-control input-sm" id="CboProblema" name="CboProblema">
                        <option value="0">--SELECCIONE PROBLEMA--</option>
                    </select>
                </div>
                
                <div class="col-md-2">
                    <label id="subcat">*Subcategoría:</label>
                </div>
                <div class="col-md-4">
                    <select class="form-control input-sm" id="CboSubCat" name="CboSubCat">
                        <option value="0">--SELECCIONE SUBCATEGORIA--</option>
                    </select>
                </div>
            </div>
           
            <div class="col-md-12">
                <br>
                <textarea id="textReporte" name="textReporte" class="form-control input-sm" rows="4" placeholder="Notas Reporte"></textarea>
            </div><!-- Aqui termina  Problemas -->
            
            <!-- Aqui empieza  Diagnostico -->
            <div id ="textarea" class="col-md-12"> <!--12-->
                <br>
                <div class="col-md-1">
                    <label class="">Diagnóstico:</label>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-4">
                    <select class="form-control input-sm" id="CboDiagnostico" name="CboDiagnostico">
                        <option value="0">--SELECCIONE DIAGNOSTICO--</option>
                    </select>
                    <br>    
                </div>
                <div class="col-md-4"></div>
            </div>
            
            <div class="col-md-12">
                <textarea id="textDiagnostico" name="textDiagnostico" class="form-control input-sm" rows="4" placeholder="Notas Diagnostico"></textarea>
            </div> <!-- Aqui termina Diagnostico -->
            
            <!-- Aqui empieza Actividad -->
            <div id ="textarea" class="col-md-12"> 
                <br>
                <div class="col-md-1">
                    <label class="">Actividad:</label>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-4">
                    <select class="form-control input-sm" id="CboActividad" name="CboActividad">
                        <option value="0">--SELECCIONE ACTIVIDAD--</option>
                    </select>
                </div>
            </div>
            <div class="col-md-12">
                <br>  
                <textarea id="textActividad" name="textActividad" class="form-control input-sm" rows="4" placeholder="Notas Actividad"></textarea>
            </div><!-- Aqui termina Actividad -->

            <!-- Aqui empieza  Solucion -->
            <div id ="textarea" class="col-md-12"> 
            <br>
            <div class="col-md-1">
                <label class="">Solucion:</label>
            </div>
            <div class="col-md-1"></div>
                <div class="col-md-4">
                    <select class="form-control input-sm" id="CboSolucion" name="CboSolucion">
                        <option value="0">--SELECCIONE SOLUCION--</option>
                    </select>
                </div>
            </div>

            <div class="col-md-12">
                <br>
                <textarea id="textSolucion" name="textSolucion" class="form-control input-sm" rows="4" placeholder="NotaS Solucion"></textarea>
            </div>
            
            <div id ="textarea" class="col-md-12">
                <br>
                <br>
           </div><!-- Fin Solucion -->
        </form>

        <div class="modal fade bd-example-modal-sm" id="modalNuevoReporte" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm">
                <div class="modal-content">
                    <div class="modal-header" id="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Confirmación</h4>
                    </div>
                    <div class="modal-body" id="respuesta">
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="boton" class="btn btn-light" data-dismiss="modal" onclick="regresa();">Aceptar</button>    
                    </div>
                </div>
            </div>
        </div>  
    </body>
</html>
<?php
} else 
{
  header('Location: login/loginind.php');
}
?>