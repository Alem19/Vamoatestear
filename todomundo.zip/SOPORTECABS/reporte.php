﻿<?php
/*ni_set("session.cookie_lifetime","60");
ini_set("session.gc_maxlifetime","60");*/
session_start();
require_once'login/bitacora.php'; 
require 'php/superusuarios.php';
include ("php/conexion.php");

$Super_Usario =$Super_Usario;

if (isset($_SESSION['xusuario_valido'])) 
{
 $xUser= ucwords(strtolower(($_SESSION['nxUsuario']))); 
 $xUser= convierte_carcter($xUser);
?>   
<!DOCTYPE html>
<html>
    <head>       

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!--<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1' />-->
        <title>CABS Help Desk</title>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet">
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href='//fonts.googleapis.com/css?family=Raleway:400,300' rel='stylesheet' type='text/css'>
	    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
        <link href="css/estilos.css" rel="stylesheet"> 
        
        <!--alertify  css-->
        <link rel="stylesheet" href="Alertify/css/alertify.min.css"/>
        <link rel="stylesheet" href="Alertify/css/themes/default.min.css"/>
        <link rel="stylesheet" href="Alertify/css/themes/semantic.min.css"/>
        <link rel="stylesheet" href="Alertify/css/themes/bootstrap.min.css"/>
        <link href="css/estilos.css" rel="stylesheet">  

        <!--JS -->
        <script src="js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/index.js"></script> 
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="bootstrap/js/bootstrap.js"></script> 
        <script src="Alertify/alertify.min.js"></script>
        <script languaje ="javascript">
             
        var revisa,revisa2;   
        
        function inicio()
        {
            clearTimeout(revisa); 
            //document.window.location="index.php";
            $( "#resultado_index" ).load( "principal.php" );
            revisa=setTimeout(sesionCaduca,18000000); //La sesion caducara en  5hrs
        }
        
        function crear()
        {
            clearTimeout(revisa);
            $( "#resultado_index" ).load( "crearReporte.php" ); 
            revisa = setTimeout(sesionCaduca,18000000); //La sesion caducara en 5hrs    
        }
        
        function sesionCaduca()
        { 
            clearTimeout(revisa2);
            if($(".fa-lock").length)
            {
              alertify.set('notifier','position', 'top-right');
              alertify.error("El sistema finalizará en 60 segundos \n Si no deseas Cerrar la pagina oprime Inico ");
              //en  1 min la sesion se cerrara automaticamente
              revisa2 = setTimeout(function(){window.location = " login/cerrar.php"},60000);
            }
        }
        </script>
    </head>

    <body onload="crear()" style="background-color:#FFFFFF; color:#000000;">
        <nav class="navbar navbar-light bg-light navbar-fixed-top"  role ="navigation">
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-left">
                    <a class="navbar-brand" style="cursor:pointer;" href="index.php"><i class=" icono izquierda fa fa-home" ></i> Inicio </a>
                    <a class="navbar-brand" style="cursor:pointer;" href="reporte.php"><i class=" icono izquierda fa fa-edit" ></i> Crear Reporte</a>        
                </ul>
                <ul class="nav navbar-nav navbar-center">
                    <span class="navbar-text h3" id="titulo">
                                Control Sporte CABS
                    </span>  
                </ul>
                 <ul class="nav navbar-nav navbar-right">
                    <div class="nav dropdown right ">
                        <button class="btn btn-xs dropdown-toggle " style="background: #0277bd" type="button" id="menudesplegable" data-toggle="dropdown">
                          <a class="navbar-brand " style="color: white" ><i class="icono izquierda fa fa-user" style="color: white"></i> <?php  echo $xUser; ?></a> 
                        </button>
                <ul class="  dropdown-menu">
                    <li><a class="navbar-brand" style="cursor:pointer;"href="manualcontrolcabs/manual.html" target="_blank" ><i class=" fa fa-question-circle" ></i> Manual CABS</a></li>
                    <li>
                        <?php
                        if(!$Super_Usario )
                            echo '<a class="navbar-brand" style="cursor:pointer;"href="login/cerrar.php" ><i class=" fa fa-lock"></i> Cerrar Sesión  </a>  ';
                        ?>  
                    </li>
                </ul>
                <!--<ul class="nav navbar-nav navbar-right">
                    <a class="navbar-brand" style="cursor:pointer;"><i class="icono izquierda fa fa-user" ></i> <?php  echo $xUser; ?> </a>
                    
                      if(!$Super_Usario )
                        echo '<a class="navbar-brand" style="cursor:pointer;"href="login/cerrar.php" ><i class=" fa fa-lock"></i> Cerrar Sesión</a>  ';
                    ?>    
                </ul>-->
            </div>
        </nav>
        <br>
        <br>
        <br>
        <br>
        <div id="resultado_index">    
        </div>
        <script>
            $('.dropdown-toggle').dropdown();
        </script> 
    </body>
</html>
<?php
}
else 
{
  header('Location: login/loginind.php');  
}
?>